"""Step 13 - sensitivity of the longitudinal inference to the assumed
zero-interval reliability, and the manuscript's summary tables.

The ceiling, the Subtype Stability Index, the decorrelation time and the
trait-null test all depend on one quantity that has to be estimated rather than
assumed: the reliability of the subtype score at zero interval.  Because that
estimate differs depending on how the within-session split is taken and in which
sample it is measured, every downstream quantity is recomputed across the full
plausible range instead of being reported at a single value.
"""
from __future__ import annotations

import importlib.util
import json
import os
import sys

import numpy as np
import pandas as pd

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
_spec = importlib.util.spec_from_file_location("theory", os.path.join(HERE, "03_theory.py"))
th = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(th)
sys.path.insert(0, HERE)
import importlib
long_mod = importlib.util.spec_from_file_location(
    "long7", os.path.join(HERE, "07_longitudinal.py"))
L = importlib.util.module_from_spec(long_mod)

ROOT = os.path.dirname(HERE)
RESULTS = os.path.join(ROOT, "results")
SEED = 20261024


def main() -> None:
    s6 = json.load(open(os.path.join(RESULTS, "06_subtyping.json")))
    s7 = json.load(open(os.path.join(RESULTS, "07_longitudinal.json")))
    s10 = json.load(open(os.path.join(RESULTS, "10_identifiability.json")))
    s11 = json.load(open(os.path.join(RESULTS, "11_abide1_replication.json")))
    p = s7["primary"]
    omega = float(s7["omega_used"])
    n = int(p["n_pairs"])
    dt = float(p["interval_mean_y"])
    kap = float(p["kappa_between_waves"])
    r_obs = float(p["r_score_between_waves"])

    sources = {
        "within-site pooled, longitudinal collection, contiguous halves":
            float(p["rho_within_site_pooled_full"]),
        "longitudinal collection, pooled, contiguous halves":
            float(p["rho_local_full"]),
        "discovery sample, within-site pooled, contiguous halves":
            float(p["rho_discovery_full"]),
        "discovery sample, interleaved halves":
            float(s6["score_reliability"]["interleaved"]["rho_full_sb"]),
    }
    rows = []
    for name, rho in sources.items():
        cs = {
            "kappa_max_continuum": float(th.kappa_max_continuum(rho)),
            "kappa_max_omega": th.kappa_max(rho, omega),
            "kappa_max_categorical": float(th.kappa_max_categorical(rho))}
        tau = dt / np.log(rho / r_obs) if rho > r_obs else np.inf
        tn = L_trait_null(rho, omega, n, kap, r_obs)
        rows.append(dict(reliability_source=name, rho_zero_interval=rho,
                         **cs,
                         SSI_continuum=kap / cs["kappa_max_continuum"],
                         SSI_omega=kap / cs["kappa_max_omega"],
                         tau_years=tau, half_life_years=th.half_life(tau),
                         p_kappa_below_trait_null=tn["p_kappa"],
                         p_r_below_trait_null=tn["p_r"],
                         kappa_null_ci_low=tn["kappa_ci"][0],
                         kappa_null_ci_high=tn["kappa_ci"][1],
                         r_null_ci_low=tn["r_ci"][0], r_null_ci_high=tn["r_ci"][1]))
    sens = pd.DataFrame(rows)
    sens.to_csv(os.path.join(RESULTS, "longitudinal_reliability_sensitivity.csv"),
                index=False)
    print(sens[["rho_zero_interval", "kappa_max_continuum", "SSI_continuum",
                "half_life_years", "p_r_below_trait_null"]].to_string(index=False))

    # ---- manuscript table 2: ceiling test across pipelines and parcellations
    t2 = []
    for nm, rec in s6["within_session_ceiling_test"].items():
        t2.append(dict(dataset="ABIDE II (DCAN)", parcellation="Gordon 352",
                       split=nm, n=s6["n_discovery"],
                       r_halfhalf=rec["reliability_at_half_length"],
                       kappa_observed=rec["kappa_observed"],
                       ci_low=rec["kappa_ci"][0], ci_high=rec["kappa_ci"][1],
                       kappa_pred_continuum=rec["kappa_max_continuum"],
                       kappa_pred_categorical=rec["kappa_max_categorical"],
                       omega_moment=rec["omega_moment_prevalence"]))
    for strat, rec in s11.items():
        t2.append(dict(dataset="ABIDE I (C-PAC)", parcellation="CC200",
                       split=("contiguous, no GSR" if strat == "filt_noglobal"
                              else "contiguous, with GSR"),
                       n=rec["n_discovery_asd"],
                       r_halfhalf=rec["score_r_halfhalf_within_site"],
                       kappa_observed=rec["kappa_within_session"],
                       ci_low=rec["kappa_ci"][0], ci_high=rec["kappa_ci"][1],
                       kappa_pred_continuum=rec["kappa_max_continuum"],
                       kappa_pred_categorical=rec["kappa_max_categorical"],
                       omega_moment=rec["omega_moment"]))
    at = pd.read_csv(os.path.join(RESULTS, "sensitivity_atlas.csv"))
    pd.DataFrame(t2).to_csv(os.path.join(RESULTS, "table2_ceiling_test.csv"), index=False)

    # ---- manuscript table 3: longitudinal results and sensitivity
    sd = pd.read_csv(os.path.join(RESULTS, "sensitivity_duration.csv"))
    t3 = sd[["T", "n_pairs", "rho_local", "kappa", "r_long", "ceiling", "ssi",
             "half_life"]].copy()
    t3.to_csv(os.path.join(RESULTS, "table3_longitudinal.csv"), index=False)

    out = {"reliability_sensitivity": rows,
           "identifiability_primary": s10["T150"],
           "atlas_sensitivity": at.to_dict("records"),
           "n_pairs": n, "interval_mean_y": dt,
           "kappa_between_waves": kap, "r_between_waves": r_obs,
           "omega_moment_primary": omega}
    with open(os.path.join(RESULTS, "13_addenda.json"), "w") as f:
        json.dump(out, f, indent=1, default=float)
    print("written results/13_addenda.json")


def L_trait_null(rho, omega, n, kappa_obs, r_obs, n_sim=20000, seed=SEED):
    rng = np.random.default_rng(seed)
    kaps = np.empty(n_sim)
    rs = np.empty(n_sim)
    for i in range(n_sim):
        c = rng.choice([-1.0, 1.0], size=n)
        theta = c * np.sqrt(omega * rho) + rng.standard_normal(n) * np.sqrt((1 - omega) * rho)
        s1 = theta + rng.standard_normal(n) * np.sqrt(1 - rho)
        s2 = theta + rng.standard_normal(n) * np.sqrt(1 - rho)
        kaps[i] = th.cohen_kappa(s1 > 0, s2 > 0)
        rs[i] = np.corrcoef(s1, s2)[0, 1]
    kaps = kaps[np.isfinite(kaps)]
    return {"p_kappa": float((kaps <= kappa_obs).mean()),
            "p_r": float((rs <= r_obs).mean()),
            "kappa_ci": [float(np.percentile(kaps, 2.5)), float(np.percentile(kaps, 97.5))],
            "r_ci": [float(np.percentile(rs, 2.5)), float(np.percentile(rs, 97.5))]}


if __name__ == "__main__":
    main()
