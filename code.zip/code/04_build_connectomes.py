"""Step 4 - duration-matched connectomes and within-session split halves.

Scan duration is the strongest determinant of connectome reliability and varies
more than three-fold across ABIDE II sites, so every session is reduced to a
common amount of retained (FD < 0.3 mm) data before any connectome is computed.
Several matched durations are produced, which turns the acquisition-length
heterogeneity of the sample into an empirical test of the Spearman-Brown scaling
used by the design calculator.

For each matched duration T and parcellation the script writes
  * ``matched``          - Fisher-z connectome from the first T seconds of
                           retained frames;
  * ``conA`` / ``conB``  - contiguous first/second half of that segment;
  * ``intA`` / ``intB``  - interleaved halves (blocks of BLOCK_S seconds).

Contiguous halves are the primary reliability estimator because interleaved
halves share the low-frequency autocorrelation of the band-passed signal and
therefore overestimate reliability; interleaved halves are retained as a
sensitivity analysis because they are immune to within-run non-stationarity.
Matrices are stored as float16 (precision ~1e-3 on Fisher-z values) to keep the
derivative set small; they are promoted to float32 on load.
"""
from __future__ import annotations

import glob
import os
import sys

import numpy as np
import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import nibabel as nib  # noqa: E402

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA = os.path.join(ROOT, "data")
RAW = os.path.join(DATA, "raw")
RESULTS = os.path.join(ROOT, "results")

PRIMARY_ATLAS = "Gordon2014FreeSurferSubcortical"
OTHER_ATLASES = ["HCP2016FreeSurferSubcortical",
                 "Power2011FreeSurferSubcortical",
                 "Markov2012FreeSurferSubcortical"]
DURATIONS = [90.0, 120.0, 150.0, 180.0, 240.0]
PRIMARY_T = 150.0
BLOCK_S = 20.0
MIN_PARCEL_SD = 1e-8


def fisher_z_vec(ts: np.ndarray, iu) -> np.ndarray:
    x = ts - ts.mean(0, keepdims=True)
    sd = x.std(0)
    sd[sd < MIN_PARCEL_SD] = np.nan
    x = x / sd
    c = (x.T @ x) / x.shape[0]
    np.fill_diagonal(c, 0.0)
    c = np.clip(c, -0.999999, 0.999999)
    return np.arctanh(c)[iu].astype(np.float16)


def interleave(n: int, block: int):
    idx = np.arange(n)
    blk = idx // max(block, 1)
    a, b = idx[(blk % 2) == 0], idx[(blk % 2) == 1]
    k = min(a.size, b.size)
    return a[:k], b[:k]


def load_ts(sub: str, ses: str, atlas: str):
    if atlas == PRIMARY_ATLAS:
        p = os.path.join(DATA, f"ts_{atlas}", f"{sub}_{ses}.npy")
        if not os.path.exists(p):
            return None
        ts = np.load(p)
    else:
        f = glob.glob(os.path.join(RAW, sub, ses, f"*atlas-{atlas}_*.ptseries.nii"))
        if not f:
            return None
        try:
            ts = np.asarray(nib.load(f[0]).get_fdata(), dtype=np.float32)
        except Exception as exc:          # unreadable CIFTI header -> skip session
            print(f"  SKIP unreadable {os.path.basename(f[0])}: {exc}", flush=True)
            return None
    keep = np.load(os.path.join(DATA, f"ts_{PRIMARY_ATLAS}", f"{sub}_{ses}_keep.npy"))
    if keep.size != ts.shape[0]:
        m = min(keep.size, ts.shape[0])
        keep, ts = keep[:m], ts[:m]
    return ts[keep]


def build(atlas: str, durations, qc: pd.DataFrame) -> None:
    npar = iu = None
    for T in durations:
        sel = qc[(qc.keep_s >= T) & (qc.n_bad_parcels == 0)]
        out = {k: [] for k in ("matched", "conA", "conB", "intA", "intB")}
        rows = []
        for n, (_, r) in enumerate(sel.iterrows(), 1):
            sub, ses, tr = r.subject, r.session, float(r.tr)
            ts = load_ts(sub, ses, atlas)
            if ts is None or ts.shape[0] * tr < T:
                continue
            if npar is None:
                npar = ts.shape[1]
                iu = np.triu_indices(npar, 1)
            if ts.shape[1] != npar or not np.isfinite(ts).all() or (ts.std(0) < MIN_PARCEL_SD).any():
                continue
            nm = int(round(T / tr))
            seg = ts[:nm]
            h = nm // 2
            ia, ib = interleave(nm, int(round(BLOCK_S / tr)))
            out["matched"].append(fisher_z_vec(seg, iu))
            out["conA"].append(fisher_z_vec(seg[:h], iu))
            out["conB"].append(fisher_z_vec(seg[h:2 * h], iu))
            out["intA"].append(fisher_z_vec(seg[ia], iu))
            out["intB"].append(fisher_z_vec(seg[ib], iu))
            rows.append(dict(subject=sub, session=ses, tr=tr, T=T,
                             n_matched=nm, n_half=h, n_half_int=int(ia.size)))
            if n % 250 == 0:
                print(f"  {atlas} T={T:.0f}s {n}/{len(sel)}", flush=True)
        meta = pd.DataFrame(rows)
        tag = f"{atlas}_T{int(T)}"
        meta.to_csv(os.path.join(RESULTS, f"conn_meta_{tag}.csv"), index=False)
        for k, v in out.items():
            arr = np.vstack(v)
            np.save(os.path.join(DATA, f"conn_{tag}_{k}.npy"), arr)
        print(f"{tag}: {len(meta)} sessions, {npar} parcels, {iu[0].size} edges",
              flush=True)


def main() -> None:
    qc = pd.read_csv(os.path.join(RESULTS, "qc_sessions.csv"))
    qc[(qc.keep_s >= min(DURATIONS)) & (qc.n_bad_parcels == 0)].to_csv(
        os.path.join(RESULTS, "sessions_included.csv"), index=False)
    build(PRIMARY_ATLAS, DURATIONS, qc)
    for a in OTHER_ATLASES:
        build(a, [PRIMARY_T], qc)


if __name__ == "__main__":
    main()
