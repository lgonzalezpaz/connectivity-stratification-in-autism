"""Step 2 - read the DCAN derivatives, reconstruct motion QC, cache time series.

For every session the script
  * loads the parcellated CIFTI time series and stores it as float32 ``.npy``
    (primary atlas only; the other parcellations are read on demand in step 5);
  * reconstructs a per-frame framewise-displacement (FD) trace from the DCAN
    ``*_motion_mask.mat`` file.  That file stores, for 51 FD thresholds
    (0.00-0.50 mm in 0.01 mm steps), the binary frame-removal vector used by the
    DCAN pipeline.  A frame's FD is therefore recovered, at 0.01 mm resolution,
    as the lowest threshold at which the frame is retained;
  * writes a session-level quality-control table (TR, frames, retained frames
    and retained seconds at FD < 0.3 mm, mean FD of retained frames).

Outputs
-------
data/ts_<ATLAS>/<sub>_<ses>.npy   parcel x time matrices (float32)
results/qc_sessions.csv           one row per session
results/parcels_<ATLAS>.csv       parcel names and network labels
"""
from __future__ import annotations

import glob
import os
import re
import sys

import numpy as np
import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import s3util  # noqa: E402

import nibabel as nib  # noqa: E402
import scipy.io as sio  # noqa: E402

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA = os.path.join(ROOT, "data")
RAW = os.path.join(DATA, "raw")
RESULTS = os.path.join(ROOT, "results")
PRIMARY = "Gordon2014FreeSurferSubcortical"
FD_THRESH = 0.30


def per_frame_fd(mat_path: str, n_frames: int):
    """Recover a per-frame FD trace and the DCAN frame-removal mask."""
    m = sio.loadmat(mat_path, squeeze_me=True, struct_as_record=False)
    md = m["motion_data"]
    thresholds = np.array([float(e.FD_threshold) for e in md])
    order = np.argsort(thresholds)
    thresholds = thresholds[order]
    md = [md[i] for i in order]
    removal = np.vstack([np.asarray(e.frame_removal, dtype=bool).ravel() for e in md])
    if removal.shape[1] != n_frames:
        n = min(removal.shape[1], n_frames)
        removal = removal[:, :n]
    fd = np.full(removal.shape[1], np.nan)
    for j in range(removal.shape[1]):
        kept = np.where(~removal[:, j])[0]
        fd[j] = thresholds[kept[0]] if kept.size else np.nan
    k = int(np.argmin(np.abs(thresholds - FD_THRESH)))
    keep = ~removal[k]
    extra = {
        "fd_threshold_used": float(thresholds[k]),
        "dcan_remaining_frames": float(getattr(md[k], "remaining_frame_count", np.nan)),
        "dcan_remaining_mean_fd": float(getattr(md[k], "remaining_frame_mean_FD", np.nan)),
        "epi_TR": float(getattr(md[k], "epi_TR", np.nan)),
    }
    return fd, keep, extra


def parcel_table(img) -> pd.DataFrame:
    ax = img.header.get_axis(1)
    names = list(ax.name)
    rows = []
    for i, nm in enumerate(names):
        m = re.match(r"^(\d+)_([LR])_(.+)$", nm)
        if m:
            rows.append(dict(index=i, name=nm, hemi=m.group(2), network=m.group(3), kind="cortex"))
        else:
            hemi = "L" if nm.endswith("_LEFT") else ("R" if nm.endswith("_RIGHT") else "NA")
            rows.append(dict(index=i, name=nm, hemi=hemi,
                             network=re.sub(r"_(LEFT|RIGHT)$", "", nm), kind="subcortex"))
    return pd.DataFrame(rows)


def main() -> None:
    out_ts = os.path.join(DATA, f"ts_{PRIMARY}")
    os.makedirs(out_ts, exist_ok=True)
    os.makedirs(RESULTS, exist_ok=True)

    files = sorted(glob.glob(os.path.join(RAW, "sub-*", "ses-*", f"*atlas-{PRIMARY}_*.ptseries.nii")))
    print(f"{len(files)} primary-atlas time series found", flush=True)

    rows, ptab = [], None
    for n, f in enumerate(files, 1):
        sub = re.search(r"(sub-\d+)", f).group(1)
        ses = re.search(r"(ses-[A-Za-z0-9]+)", f).group(1)
        img = nib.load(f)
        ts = np.asarray(img.get_fdata(), dtype=np.float32)          # (time, parcels)
        tr = float(img.header.get_axis(0).step)
        if ptab is None:
            ptab = parcel_table(img)
            ptab.to_csv(os.path.join(RESULTS, f"parcels_{PRIMARY}.csv"), index=False)

        mm = os.path.join(os.path.dirname(f),
                          f"{sub}_{ses}_task-rest_desc-filtered_motion_mask.mat")
        if os.path.exists(mm):
            fd, keep, extra = per_frame_fd(mm, ts.shape[0])
            if keep.size != ts.shape[0]:
                k2 = np.zeros(ts.shape[0], dtype=bool)
                k2[: min(keep.size, ts.shape[0])] = keep[: min(keep.size, ts.shape[0])]
                keep = k2
                fd = np.concatenate([fd, np.full(ts.shape[0] - fd.size, np.nan)])[: ts.shape[0]]
        else:
            fd = np.full(ts.shape[0], np.nan)
            keep = np.ones(ts.shape[0], dtype=bool)
            extra = {"fd_threshold_used": np.nan, "dcan_remaining_frames": np.nan,
                     "dcan_remaining_mean_fd": np.nan, "epi_TR": tr}

        np.save(os.path.join(out_ts, f"{sub}_{ses}.npy"), ts)
        np.save(os.path.join(out_ts, f"{sub}_{ses}_keep.npy"), keep)

        bad = ~np.isfinite(ts).all(axis=0) | (ts.std(axis=0) == 0)
        rows.append(dict(
            subject=sub, session=ses, tr=tr, n_frames=int(ts.shape[0]),
            n_parcels=int(ts.shape[1]), n_bad_parcels=int(bad.sum()),
            dur_s=float(ts.shape[0] * tr),
            mean_fd=float(np.nanmean(fd)), median_fd=float(np.nanmedian(fd)),
            perc_fd_gt_02=float(np.nanmean(fd > 0.2) * 100),
            n_keep=int(keep.sum()), keep_s=float(keep.sum() * tr),
            **extra))
        if n % 100 == 0:
            print(f"  {n}/{len(files)}", flush=True)

    qc = pd.DataFrame(rows).sort_values(["subject", "session"])
    qc.to_csv(os.path.join(RESULTS, "qc_sessions.csv"), index=False)
    print(qc[["tr", "n_frames", "dur_s", "mean_fd", "keep_s"]].describe().to_string())


if __name__ == "__main__":
    main()
