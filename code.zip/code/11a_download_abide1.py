"""Step 11a - fetch the ABIDE I Preprocessed Connectomes Project ROI time series.

Used as an independent replication cohort: a different sample, a different
preprocessing pipeline (C-PAC) and a different parcellation (CC200), so that the
reliability-to-agreement mapping is not tested only in the DCAN/Gordon pipeline.
Both global-signal-regressed and non-regressed strategies are downloaded, which
makes global signal regression one of the sensitivity axes.
"""
from __future__ import annotations

import os
import sys
from concurrent.futures import ThreadPoolExecutor, as_completed

import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import s3util  # noqa: E402

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA = os.path.join(ROOT, "data")
PHENO = os.path.join(DATA, "pheno")
PREFIX = "data/Projects/ABIDE_Initiative/Outputs/cpac"
STRATEGIES = ["filt_noglobal", "filt_global"]
ATLAS = "rois_cc200"


def main() -> None:
    ph = pd.read_csv(os.path.join(PHENO, "ABIDEI_Phenotypic_preprocessed1.csv"))
    ph = ph[ph.FILE_ID != "no_filename"]
    print(f"{len(ph)} ABIDE I subjects with preprocessed derivatives", flush=True)

    jobs = []
    for strat in STRATEGIES:
        for fid in ph.FILE_ID:
            key = f"{PREFIX}/{strat}/{ATLAS}/{fid}_{ATLAS}.1D"
            dest = os.path.join(DATA, "abide1", strat, f"{fid}_{ATLAS}.1D")
            jobs.append((key, dest))

    done = fail = 0
    with ThreadPoolExecutor(max_workers=16) as ex:
        futs = {ex.submit(s3util.fetch, k, d): k for k, d in jobs}
        for fut in as_completed(futs):
            try:
                fut.result()
                done += 1
            except Exception as exc:
                fail += 1
                if fail < 10:
                    print("FAIL", futs[fut], exc, flush=True)
            if done % 300 == 0:
                print(f"  {done}/{len(jobs)}", flush=True)
    print(f"downloaded {done} files ({fail} failures)")


if __name__ == "__main__":
    main()
