"""Step 1 - index and download the openly available ABIDE II DCAN derivatives.

Downloads, for every available resting-state session:
  * parcellated BOLD time series (.ptseries.nii) for four independent
    parcellations (Gordon 2014, HCP/Glasser 2016, Power 2011, Markov 2012,
    each with 19 FreeSurfer subcortical structures appended);
  * the DCAN framewise-displacement (FD) mask file, from which a per-frame FD
    trace is reconstructed at 0.01 mm resolution.

It also downloads the open ABIDE I/II phenotypic tables.

All sources are public and require no credentials or data-use agreement.
"""
from __future__ import annotations

import collections
import os
import re
import sys
from concurrent.futures import ThreadPoolExecutor, as_completed

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import s3util  # noqa: E402

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA = os.path.join(ROOT, "data")
RAW = os.path.join(DATA, "raw")
PHENO = os.path.join(DATA, "pheno")

DCAN_PREFIX = "data/Projects/ABIDE2/Derivatives/DCAN/"
ATLASES = [
    "Gordon2014FreeSurferSubcortical",
    "HCP2016FreeSurferSubcortical",
    "Power2011FreeSurferSubcortical",
    "Markov2012FreeSurferSubcortical",
]
PHENO_BASE = "http://fcon_1000.projects.nitrc.org/indi/abide2/release/phenotypic_data/"
PHENO_FILES = [
    "ABIDEII_Composite_Phenotypic.csv",
    "ABIDEII_Long_Composite_Phenotypic.csv",
]
ABIDE1_PHENO = (
    "https://s3.amazonaws.com/fcp-indi/data/Projects/ABIDE_Initiative/"
    "Phenotypic_V1_0b_preprocessed1.csv"
)


def build_index() -> dict:
    cache = os.path.join(DATA, "dcan_index.json")
    if os.path.exists(cache):
        return s3util.load_json(cache)
    keys = s3util.list_keys(DCAN_PREFIX)
    idx: dict = collections.defaultdict(lambda: collections.defaultdict(dict))
    for key, size in keys:
        m = re.search(r"/(sub-\d+)/(ses-[^/]+)/func/", key)
        if not m:
            continue
        sub, ses = m.group(1), m.group(2)
        a = re.search(r"atlas-([A-Za-z0-9]+)_desc-filtered_timeseries\.ptseries\.nii$", key)
        if a:
            idx[sub][ses][f"atlas:{a.group(1)}"] = [key, size]
        elif key.endswith("desc-filtered_motion_mask.mat"):
            idx[sub][ses]["motion"] = [key, size]
    idx = {s: {k: dict(v) for k, v in d.items()} for s, d in idx.items()}
    s3util.save_json(idx, cache)
    return idx


def main() -> None:
    os.makedirs(RAW, exist_ok=True)
    os.makedirs(PHENO, exist_ok=True)

    for f in PHENO_FILES:
        s3util.fetch_url(PHENO_BASE + f, os.path.join(PHENO, f))
    s3util.fetch_url(ABIDE1_PHENO, os.path.join(PHENO, "ABIDEI_Phenotypic_preprocessed1.csv"))
    print("phenotypic tables ready", flush=True)

    idx = build_index()
    n_ses = sum(len(v) for v in idx.values())
    print(f"indexed {len(idx)} subjects / {n_ses} sessions", flush=True)

    jobs = []
    for sub, sessions in idx.items():
        for ses, files in sessions.items():
            for tag, (key, _size) in files.items():
                jobs.append((key, os.path.join(RAW, sub, ses, os.path.basename(key))))

    done = fail = 0
    with ThreadPoolExecutor(max_workers=16) as ex:
        futs = {ex.submit(s3util.fetch, k, d): k for k, d in jobs}
        for fut in as_completed(futs):
            try:
                fut.result()
                done += 1
            except Exception as exc:
                fail += 1
                print("FAIL", futs[fut], exc, flush=True)
            if done % 500 == 0:
                print(f"  {done}/{len(jobs)} downloaded", flush=True)
    print(f"downloaded {done} files ({fail} failures)")


if __name__ == "__main__":
    main()
