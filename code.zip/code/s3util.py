"""Minimal, dependency-light helpers for anonymous listing/downloading of the
public INDI/FCP S3 bucket (fcp-indi), plus small I/O conveniences.

The bucket is readable without credentials, so plain HTTP range/list requests
are used instead of boto3 to keep the environment minimal and fast.
"""
from __future__ import annotations

import json
import os
import re
import time
import urllib.parse
import urllib.request

BUCKET = "https://s3.amazonaws.com/fcp-indi"
UA = {"User-Agent": "connectome-subtype-stability/1.0 (academic research)"}


def list_keys(prefix: str, suffix: str | None = None, timeout: int = 120):
    """Return [(key, size_bytes), ...] for every object under *prefix*."""
    out, token = [], None
    while True:
        q = {"list-type": "2", "prefix": prefix, "max-keys": "1000"}
        if token:
            q["continuation-token"] = token
        url = f"{BUCKET}?{urllib.parse.urlencode(q)}"
        req = urllib.request.Request(url, headers=UA)
        xml = urllib.request.urlopen(req, timeout=timeout).read().decode()
        keys = re.findall(r"<Key>([^<]+)</Key>", xml)
        sizes = re.findall(r"<Size>(\d+)</Size>", xml)
        for k, s in zip(keys, sizes):
            if suffix is None or k.endswith(suffix):
                out.append((k, int(s)))
        m = re.search(r"<NextContinuationToken>([^<]+)</NextContinuationToken>", xml)
        if not m:
            break
        token = m.group(1)
    return out


def fetch(key: str, dest: str, retries: int = 4, timeout: int = 180) -> str:
    """Download bucket *key* to *dest* (skips if already present, non-empty)."""
    if os.path.exists(dest) and os.path.getsize(dest) > 0:
        return dest
    os.makedirs(os.path.dirname(dest), exist_ok=True)
    url = f"{BUCKET}/{key}"
    last = None
    for attempt in range(retries):
        try:
            req = urllib.request.Request(url, headers=UA)
            with urllib.request.urlopen(req, timeout=timeout) as r, open(dest + ".part", "wb") as f:
                while True:
                    chunk = r.read(1 << 20)
                    if not chunk:
                        break
                    f.write(chunk)
            os.replace(dest + ".part", dest)
            return dest
        except Exception as exc:  # pragma: no cover - network robustness
            last = exc
            time.sleep(1.5 * (attempt + 1))
    raise RuntimeError(f"failed to download {key}: {last}")


def fetch_url(url: str, dest: str, retries: int = 4, timeout: int = 180) -> str:
    if os.path.exists(dest) and os.path.getsize(dest) > 0:
        return dest
    os.makedirs(os.path.dirname(dest), exist_ok=True)
    last = None
    for attempt in range(retries):
        try:
            req = urllib.request.Request(url, headers=UA)
            with urllib.request.urlopen(req, timeout=timeout) as r, open(dest + ".part", "wb") as f:
                f.write(r.read())
            os.replace(dest + ".part", dest)
            return dest
        except Exception as exc:  # pragma: no cover
            last = exc
            time.sleep(1.5 * (attempt + 1))
    raise RuntimeError(f"failed to download {url}: {last}")


def save_json(obj, path: str) -> None:
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w") as f:
        json.dump(obj, f, indent=1, sort_keys=True)


def load_json(path: str):
    with open(path) as f:
        return json.load(f)
