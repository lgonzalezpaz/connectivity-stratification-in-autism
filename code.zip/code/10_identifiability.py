"""Step 10 - is the connectome itself stable across development, or only the label?

The subtype label is a one-bit summary of a 61,776-dimensional measurement.  A
label can therefore be unstable while the underlying connectome is highly
individual and highly stable.  This step separates the two by measuring, in the
same participants and the same data,

  * within-session connectome self-similarity (split halves, the measurement
    floor);
  * between-wave self-similarity across 1.6-2.0 years;
  * between-subject similarity (the reference for "no individual information");
  * identification accuracy: for each participant's wave-1 connectome, whether
    the nearest wave-2 connectome in the sample is their own (chance = 1/n);
  * the fraction of the reliable connectome variance that the subtype score
    retains, which quantifies how much information the labelling discards.

Identification accuracy is informative at small n because every participant
contributes a full high-dimensional profile rather than one bit.
"""
from __future__ import annotations

import importlib.util
import json
import os
import sys

import numpy as np
import pandas as pd
from scipy import stats

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import pipeline as P  # noqa: E402

_spec = importlib.util.spec_from_file_location("theory", os.path.join(HERE, "03_theory.py"))
th = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(th)

ROOT = os.path.dirname(HERE)
DATA = os.path.join(ROOT, "data")
RESULTS = os.path.join(ROOT, "results")
ATLAS = "Gordon2014FreeSurferSubcortical"
SEED = 20261024


def corr_rows(A, B):
    """Row-wise correlation between two matrices of equal shape."""
    A = A - A.mean(1, keepdims=True)
    B = B - B.mean(1, keepdims=True)
    return (A * B).sum(1) / (np.linalg.norm(A, axis=1) * np.linalg.norm(B, axis=1))


def identify(A, B):
    """Accuracy of matching each row of A to its own row in B by max correlation."""
    A = (A - A.mean(1, keepdims=True))
    B = (B - B.mean(1, keepdims=True))
    A /= np.linalg.norm(A, axis=1, keepdims=True)
    B /= np.linalg.norm(B, axis=1, keepdims=True)
    S = A @ B.T
    hit = (S.argmax(1) == np.arange(A.shape[0]))
    rank = np.array([1 + (S[i] > S[i, i]).sum() for i in range(A.shape[0])])
    return float(hit.mean()), rank, S


def main() -> None:
    out = {}
    for T in (150, 120, 90):
        m = P.fit_model(atlas=ATLAS, T=T)
        meta = m["meta"]
        pairs = P.longitudinal_pairs(meta)
        if len(pairs) < 5:
            continue
        tag = f"{ATLAS}_T{T}"
        Xm = np.load(os.path.join(DATA, f"conn_{tag}_matched.npy"), mmap_mode="r")
        Xa = np.load(os.path.join(DATA, f"conn_{tag}_conA.npy"), mmap_mode="r")
        Xb = np.load(os.path.join(DATA, f"conn_{tag}_conB.npy"), mmap_mode="r")
        i1, i2 = pairs.i1.values, pairs.i2.values
        long_idx = np.where(meta.collection.values == "longitudinal")[0]

        # remove the grand mean connectome of the longitudinal collection so that
        # similarity reflects individual deviation, not the shared group pattern
        ref = np.asarray(Xm[long_idx], dtype=np.float32).mean(0)
        W1 = np.asarray(Xm[i1], dtype=np.float32) - ref
        W2 = np.asarray(Xm[i2], dtype=np.float32) - ref
        A = np.asarray(Xa[long_idx], dtype=np.float32)
        B = np.asarray(Xb[long_idx], dtype=np.float32)
        refh = (A.mean(0) + B.mean(0)) / 2.0
        A, B = A - refh, B - refh

        self_within = corr_rows(A, B)
        self_between = corr_rows(W1, W2)
        n = len(pairs)
        off = []
        C = np.corrcoef(np.vstack([W1, W2]))[:n, n:]
        for i in range(n):
            for j in range(n):
                if i != j:
                    off.append(C[i, j])
        off = np.asarray(off)

        acc12, rank12, _ = identify(W1, W2)
        acc21, rank21, _ = identify(W2, W1)
        accw, rankw, _ = identify(A, B)
        # permutation test on identification accuracy
        rng = np.random.default_rng(SEED)
        perm = np.array([identify(W1, W2[rng.permutation(n)])[0] for _ in range(2000)])

        # how much of the reliable signal does the one-dimensional score keep?
        s = m["score"]
        var_score = float(np.var(s["matched"][long_idx]))
        rel_score = th.spearman_brown(
            float(np.corrcoef(s["conA"][long_idx], s["conB"][long_idx])[0, 1]), 2.0)
        rec = {
            "T": T, "n_pairs": int(n),
            "interval_mean_y": float(pairs.interval.mean()),
            "self_similarity_within_session": {
                "mean": float(self_within.mean()), "sd": float(self_within.std(ddof=1)),
                "n_sessions": int(len(self_within))},
            "self_similarity_between_waves": {
                "mean": float(self_between.mean()), "sd": float(self_between.std(ddof=1))},
            "between_subject_similarity": {
                "mean": float(off.mean()), "sd": float(off.std(ddof=1)),
                "n": int(off.size)},
            "self_vs_other_t": float(stats.ttest_1samp(
                self_between - off.reshape(n, n - 1).mean(1), 0.0).statistic),
            "self_vs_other_p": float(stats.ttest_1samp(
                self_between - off.reshape(n, n - 1).mean(1), 0.0).pvalue),
            "identification_accuracy_w1_to_w2": acc12,
            "identification_accuracy_w2_to_w1": acc21,
            "identification_accuracy_within_session": accw,
            "chance_accuracy": 1.0 / n,
            "identification_perm_p": float((perm >= acc12).mean()),
            "median_rank_of_self": float(np.median(rank12)),
            "score_reliability_longitudinal_sessions": float(rel_score),
            "score_variance_longitudinal": var_score,
        }
        # differential identifiability (Amico & Goni): self minus other, in percent
        rec["differential_identifiability_between_waves"] = float(
            100 * (self_between.mean() - off.mean()))
        rec["differential_identifiability_within_session"] = float(
            100 * (self_within.mean() - corr_rows(
                A, B[rng.permutation(len(B))]).mean()))
        out[f"T{T}"] = rec
        print(f"T={T}s n={n}: within-session self r={rec['self_similarity_within_session']['mean']:.3f}, "
              f"between-wave self r={rec['self_similarity_between_waves']['mean']:.3f}, "
              f"other r={rec['between_subject_similarity']['mean']:.3f}, "
              f"ID acc={acc12:.2f} (chance {1/n:.2f}, p={rec['identification_perm_p']:.4f})",
              flush=True)
        del m, Xm, Xa, Xb, A, B, W1, W2

    with open(os.path.join(RESULTS, "10_identifiability.json"), "w") as f:
        json.dump(out, f, indent=1, default=float)
    pd.DataFrame([{k: v for k, v in r.items() if not isinstance(v, dict)}
                  for r in out.values()]).to_csv(
        os.path.join(RESULTS, "identifiability.csv"), index=False)
    print("written results/10_identifiability.json")


if __name__ == "__main__":
    main()
