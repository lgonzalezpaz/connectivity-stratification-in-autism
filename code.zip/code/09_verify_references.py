"""Step 9 - machine-verified bibliography.

Every reference is resolved against Crossref (authoritative metadata: authors,
title, container, year, volume, pages, DOI) and, where available, against
PubMed (abstract text), so that no citation is written from memory.  The script
stores what it retrieved in results/references_verified.json, prints a
Vancouver-style list, and flags any entry whose metadata could not be
confirmed.

For claims that rest on a specific number, the abstract text is searched for
that number and the result recorded, so the manuscript's quantitative citations
can be audited.
"""
from __future__ import annotations

import json
import os
import re
import sys
import time
import urllib.parse
import urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
RESULTS = os.path.join(ROOT, "results")
MAIL = "lgonzalezpaz@gmail.com"
UA = {"User-Agent": f"reference-verifier/1.0 (mailto:{MAIL})"}

# key -> (doi, claim the manuscript attaches to it, strings expected in the abstract)
REFS: dict[str, tuple[str, str, list[str]]] = {
    "dimartino2014": ("10.1038/mp.2013.78",
                      "ABIDE I aggregated resting-state data in autism", []),
    "dimartino2017": ("10.1038/sdata.2017.10",
                      "ABIDE II contents, including two longitudinal collections", []),
    "rasero2023": ("10.1016/j.biopsych.2023.04.014",
                   "two connectivity subtypes in 657 individuals; transcriptomic "
                   "enrichment only in the hyperconnected subtype", ["657"]),
    "choi2022": ("10.1016/j.neuroimage.2022.119212",
                 "gradient-based connectivity subtypes replicated across samples", []),
    "buch2023": ("10.1038/s41593-023-01259-x",
                 "brain-behaviour dimensions define four autism subgroups, replicated", []),
    "horien2022": ("10.1016/j.biopsych.2022.04.008",
                   "review of connectome-based predictive modelling in autism; "
                   "ABIDE dependence and reliability recommendations", []),
    "wen2025": ("10.1038/s41380-024-02807-y",
                "subtyping solutions agree poorly across imaging modalities", []),
    "xuan2026": ("10.1016/j.jad.2025.121143",
                 "altered dynamic functional stability in autism, multicentre", []),
    "yue2026": ("10.1186/s13229-026-00728-x",
                "co-activation-pattern executive-function subtypes with four-year "
                "follow-up", []),
    "noble2019": ("10.1016/j.neuroimage.2019.116157",
                  "meta-analytic mean test-retest reliability of functional "
                  "connectivity edges", ["ICC"]),
    "noble2017": ("10.1093/cercor/bhx230",
                  "reliability of functional connectivity increases with scan "
                  "duration and conditions behavioural utility", []),
    "birn2013": ("10.1016/j.neuroimage.2013.05.099",
                 "scan length determines reliability of resting-state connectivity", []),
    "laumann2015": ("10.1016/j.neuron.2015.06.037",
                    "individual-specific functional connectomes require tens of "
                    "minutes of data", []),
    "gratton2018": ("10.1016/j.neuron.2018.03.035",
                    "functional network organisation is dominated by stable "
                    "individual features", []),
    "finn2015": ("10.1038/nn.4135",
                 "connectome fingerprinting identifies individuals across sessions", []),
    "zuo2014": ("10.1038/sdata.2014.49",
                "CoRR: an open resource for test-retest reliability", []),
    "shehzad2009": ("10.1093/cercor/bhn256",
                    "resting-state connectivity is reliable but heterogeneous "
                    "across edges", []),
    "elliott2020": ("10.1177/0956797620916786",
                    "poor test-retest reliability limits individual-differences "
                    "research with fMRI", []),
    "marek2022": ("10.1038/s41586-022-04492-9",
                  "brain-wide association studies require thousands of individuals", []),
    "power2012": ("10.1016/j.neuroimage.2011.10.018",
                  "framewise displacement and motion artefact in resting-state fMRI", []),
    "power2011": ("10.1016/j.neuron.2011.09.006",
                  "functional network organisation of the human brain (Power atlas)", []),
    "gordon2016": ("10.1093/cercor/bhu239",
                   "cortical area parcellation from resting-state correlations", []),
    "glasser2016": ("10.1038/nature18933",
                    "multi-modal parcellation of human cerebral cortex", []),
    "landis1977": ("10.2307/2529310",
                   "benchmark ranges for the kappa statistic", []),
    "shrout1979": ("10.1037/0033-2909.86.2.420",
                   "intraclass correlations for rater reliability", []),
    "mcgraw1996": ("10.1037/1082-989X.1.1.30",
                   "forming inferences about intraclass correlation coefficients", []),
    "cohen1960": ("10.1177/001316446002000104",
                  "coefficient of agreement for nominal scales", []),
    "spearman1904": ("10.2307/1412159",
                     "correction of correlations for attenuation by unreliability", []),
    "brown1910": ("10.1111/j.2044-8295.1910.tb00207.x",
                  "split-half estimation of test reliability", []),
    "spearman1910": ("10.1111/j.2044-8295.1910.tb00206.x",
                     "correlation computed from faulty data", []),
    "jacobson1991": ("10.1037/0022-006X.59.1.12",
                     "reliable change index for individual-level change", []),
    "monti2003": ("10.1023/A:1023949509487",
                  "consensus clustering for assessing cluster stability", []),
    "senbabaoglu2014": ("10.1038/srep06207",
                        "proportion of ambiguous clustering for choosing k", []),
    "meehl1995": ("10.1037/0003-066X.50.4.266",
                  "taxometric logic for distinguishing categories from continua", []),
    "haslam2012": ("10.1017/S0033291711001966",
                   "taxometric evidence overwhelmingly favours continua over "
                   "categories in psychopathology", []),
    "lombardo2019": ("10.1038/s41380-018-0321-0",
                     "decomposing heterogeneity in autism", []),
    "feczko2019": ("10.1016/j.tics.2019.03.009",
                   "heterogeneity and biotypes in psychiatry", []),
    "dinga2019": ("10.1016/j.nicl.2019.101796",
                  "failure to replicate data-driven depression subtypes", []),
    "uddin2013": ("10.1001/jamapsychiatry.2013.104",
                  "age-related differences in salience-network connectivity in autism",
                  []),
    "nomi2015": ("10.1016/j.nicl.2015.02.024",
                 "developmental changes in large-scale network connectivity in autism",
                 []),
    "hull2017": ("10.3389/fpsyt.2016.00205",
                 "review of resting-state connectivity findings in autism", []),
    "king2019": ("10.1186/s13229-019-0273-5",
                 "generalizability and reproducibility of functional connectivity "
                 "measures in autism", []),
    "casey2018": ("10.1016/j.dcn.2018.03.001",
                  "ABCD study imaging acquisition protocol", []),
    "alexander2017": ("10.1038/sdata.2017.181",
                      "Healthy Brain Network biobank protocol", []),
    "vanessen2013": ("10.1016/j.neuroimage.2013.05.041",
                     "Human Connectome Project acquisition", []),
    "miller2016": ("10.1038/nn.4393",
                   "UK Biobank brain imaging protocol", []),
    "amico2018": ("10.1038/s41598-018-25089-1",
                  "differential identifiability of human functional connectomes", []),
    "fair2020": ("10.1016/j.neuroimage.2019.116400",
                 "respiratory artefact correction in head-motion estimates", []),
    "hartigan1985": ("10.1214/aos/1176346577",
                     "dip test of unimodality", []),
    "pfister2013": ("10.3389/fpsyg.2013.00700",
                    "bimodality coefficient and its limitations", []),
    "markov2014": ("10.1093/cercor/bhs270",
                   "macaque M132 interareal parcellation, projected to human cortex "
                   "in the pipeline's atlas set", []),
    "glasser2013": ("10.1016/j.neuroimage.2013.04.127",
                    "minimal preprocessing pipelines and grayordinate/CIFTI framework",
                    []),
    "padmanabhan2017": ("10.1016/j.bpsc.2017.04.004",
                        "default mode network changes with age in autism", []),
    "lord2000": ("10.1023/A:1005592401947",
                 "Autism Diagnostic Observation Schedule", []),
    "loth2017": ("10.1186/s13229-017-0146-8",
                 "EU-AIMS LEAP stratification cohort rationale", []),
    "cronbach1951": ("10.1007/BF02310555",
                     "internal consistency of composite measures", []),
    "pedregosa2011": ("10.5555/1953048.2078195",
                      "scikit-learn", []),
    "virtanen2020": ("10.1038/s41592-019-0686-2",
                     "SciPy", []),
    "harris2020": ("10.1038/s41586-020-2649-2",
                   "NumPy", []),
}


def crossref(doi: str):
    url = f"https://api.crossref.org/works/{urllib.parse.quote(doi)}?mailto={MAIL}"
    try:
        req = urllib.request.Request(url, headers=UA)
        d = json.loads(urllib.request.urlopen(req, timeout=60).read())["message"]
    except Exception as exc:
        return {"ok": False, "error": str(exc)}
    authors = []
    for a in d.get("author", []) or []:
        fam = a.get("family", "")
        giv = "".join(p[0] for p in re.split(r"[\s\-]+", a.get("given", "")) if p)
        authors.append(f"{fam} {giv}".strip())
    year = None
    for k in ("published-print", "published-online", "issued", "created"):
        if k in d and d[k].get("date-parts", [[None]])[0][0]:
            year = d[k]["date-parts"][0][0]
            break
    return {"ok": True, "doi": d.get("DOI"), "title": (d.get("title") or [""])[0],
            "journal": (d.get("container-title") or [""])[0],
            "short_journal": (d.get("short-container-title") or [""])[0],
            "year": year, "volume": d.get("volume"), "issue": d.get("issue"),
            "page": d.get("page"), "authors": authors,
            "type": d.get("type"), "publisher": d.get("publisher")}


def pubmed(doi: str):
    base = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils"
    try:
        q = urllib.parse.urlencode({"db": "pubmed", "term": f"{doi}[DOI]",
                                    "retmode": "json", "email": MAIL})
        r = json.loads(urllib.request.urlopen(
            urllib.request.Request(f"{base}/esearch.fcgi?{q}", headers=UA),
            timeout=60).read())
        ids = r["esearchresult"].get("idlist", [])
        if not ids:
            return {"ok": False, "error": "no PubMed record"}
        pmid = ids[0]
        q2 = urllib.parse.urlencode({"db": "pubmed", "id": pmid, "rettype": "abstract",
                                     "retmode": "text", "email": MAIL})
        txt = urllib.request.urlopen(
            urllib.request.Request(f"{base}/efetch.fcgi?{q2}", headers=UA),
            timeout=60).read().decode("utf-8", "replace")
        return {"ok": True, "pmid": pmid, "abstract": txt}
    except Exception as exc:
        return {"ok": False, "error": str(exc)}


def vancouver(meta: dict) -> str:
    a = meta.get("authors") or []
    names = ", ".join(a[:6]) + (", et al." if len(a) > 6 else "")
    jt = meta.get("short_journal") or meta.get("journal") or ""
    vol = meta.get("volume") or ""
    pg = meta.get("page") or ""
    bits = f"{names} {meta.get('title','').rstrip('.')}. {jt}. {meta.get('year','')}"
    if vol:
        bits += f";{vol}"
    if pg:
        bits += f":{pg}"
    return bits + f". doi:{meta.get('doi','')}."


def main() -> None:
    out = {}
    for key, (doi, claim, expect) in REFS.items():
        cr = crossref(doi)
        pm = pubmed(doi) if cr.get("ok") else {"ok": False}
        rec = {"key": key, "doi_requested": doi, "claim": claim,
               "crossref": cr, "pubmed_ok": pm.get("ok", False),
               "pmid": pm.get("pmid")}
        if pm.get("ok"):
            ab = pm["abstract"]
            rec["abstract_chars"] = len(ab)
            rec["expected_strings_found"] = {e: (e.lower() in ab.lower()) for e in expect}
            rec["abstract"] = ab
        if cr.get("ok"):
            rec["vancouver"] = vancouver(cr)
            print(f"[ok]   {key}: {cr['title'][:70]}", flush=True)
        else:
            print(f"[FAIL] {key}: {cr.get('error')}", flush=True)
        out[key] = rec
        time.sleep(0.2)

    with open(os.path.join(RESULTS, "references_verified.json"), "w") as f:
        json.dump(out, f, indent=1)
    bad = [k for k, v in out.items() if not v["crossref"].get("ok")]
    print(f"\n{len(out) - len(bad)}/{len(out)} resolved; unresolved: {bad}")
    with open(os.path.join(RESULTS, "references_vancouver.txt"), "w") as f:
        for k, v in out.items():
            if v["crossref"].get("ok"):
                f.write(f"{k}\t{v['vancouver']}\n")


if __name__ == "__main__":
    main()
