"""Step 7 - intraindividual stability of subtype assignment across development.

The 17 participants of the ABIDE II UPSM_Long collection are the openly
available evidence base for this question: their baseline scans were released in
ABIDE I and their follow-up scans, acquired on the same scanner with an
identical protocol 1.6-2.0 years later, in ABIDE II.  They are held out of
subtype discovery entirely, so their labels are out-of-sample.

Quantities computed
-------------------
* label agreement (Cohen's kappa) between waves, with bootstrap intervals;
* test-retest correlation and ICC of the continuous subtype score, which is the
  statistically efficient version of the same question;
* the measured reliability of that score in these same participants, hence the
  stability ceiling and the Subtype Stability Index;
* a parametric-bootstrap test of the trait null (no latent change), at the
  realised sample size;
* the latent decorrelation time tau and the half-life of subtype identity;
* per-participant reliable-change indices;
* group-level drift versus individual reconfiguration;
* sensitivity to matched duration, parcellation, cluster number, clustering
  algorithm and to the reliability-regularised axis.
"""
from __future__ import annotations

import importlib.util
import json
import os
import sys

import numpy as np
import pandas as pd
from scipy import stats

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import pipeline as P  # noqa: E402

_spec = importlib.util.spec_from_file_location("theory", os.path.join(HERE, "03_theory.py"))
th = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(th)

ROOT = os.path.dirname(HERE)
RESULTS = os.path.join(ROOT, "results")
SEED = 20261024
DURATIONS = [90, 120, 150, 180, 240]
ATLASES = ["Gordon2014FreeSurferSubcortical", "HCP2016FreeSurferSubcortical",
           "Power2011FreeSurferSubcortical", "Markov2012FreeSurferSubcortical"]
PRIMARY_T = 150


def pair_stats(m, pairs, score_key="score", omega=0.0):
    """Agreement, correlation and ceiling statistics for the longitudinal pairs."""
    i1 = pairs.i1.values
    i2 = pairs.i2.values
    s = m[score_key]
    l1 = (s["matched"][i1] > 0).astype(int)
    l2 = (s["matched"][i2] > 0).astype(int)
    kap = th.cohen_kappa(l1, l2)
    ci = th.kappa_ci_bootstrap(l1, l2, n_boot=20000, seed=SEED)
    r_long = float(np.corrcoef(s["matched"][i1], s["matched"][i2])[0, 1])
    icc_long = th.icc_consistency(s["matched"][i1], s["matched"][i2])
    n = len(pairs)

    # reliability measured in the longitudinal collection (all usable sessions
    # of both waves, not only the paired ones, for a less noisy estimate)
    meta = m["meta"]
    idx = np.where(meta.collection.values == "longitudinal")[0]
    if idx.size < 10:
        idx = np.concatenate([i1, i2])
    r_half_local = float(np.corrcoef(s["conA"][idx], s["conB"][idx])[0, 1])
    rho_local = th.spearman_brown(r_half_local, 2.0)
    sites = meta.site_scanner.values
    r_half_ws, per_site = th.pooled_within_group_r(s["conA"], s["conB"], sites)
    rho_ws = th.spearman_brown(r_half_ws, 2.0)
    rho_disc = m["rho_full"] if score_key == "score" else m["rho_full_rr"]
    prev = float(m["prevalence"])

    out = {
        "n_pairs": int(n),
        "interval_mean_y": float(pairs.interval.mean()),
        "interval_range_y": [float(pairs.interval.min()), float(pairs.interval.max())],
        "kappa_between_waves": kap, "kappa_ci": list(ci),
        "p_agree": float((l1 == l2).mean()),
        "n_switchers": int((l1 != l2).sum()),
        "r_score_between_waves": r_long,
        "r_ci": list(th.fisher_ci(r_long, n)),
        "icc_score_between_waves": icc_long,
        "reliability_local_halfhalf": r_half_local,
        "rho_local_full": rho_local,
        "rho_discovery_full": float(rho_disc),
        "reliability_within_site_pooled_halfhalf": float(r_half_ws),
        "rho_within_site_pooled_full": float(rho_ws),
        "reliability_by_site": per_site,
    }
    for nm, rho in (("local", rho_local), ("discovery", float(rho_disc)),
                    ("within_site_pooled", float(rho_ws))):
        cs = P.ceiling_set(rho, prev, omega)
        ceil_w = cs["kappa_max_balanced_omega"]
        rec = {"rho": float(rho), "omega": float(omega), "prevalence": prev}
        rec.update(cs)
        rec["kappa_max"] = ceil_w
        rec["SSI"] = th.ssi(kap, ceil_w)
        rec["SSI_continuum"] = th.ssi(kap, cs["kappa_max_balanced_continuum"])
        rec["SSI_prevalence_omega"] = th.ssi(kap, cs["kappa_max_prevalence_omega"])
        rec["r_attenuation_ratio"] = r_long / rho if rho > 0 else np.nan
        rec["tau_years"] = th.tau_from_two_intervals(rho, 0.0, r_long,
                                                     float(pairs.interval.mean()))
        rec["half_life_years"] = th.half_life(rec["tau_years"])
        out[f"ceiling_{nm}"] = rec
    return out, l1, l2


def trait_null_test(rho: float, omega: float, n: int, kappa_obs: float,
                    r_obs: float, n_sim: int = 20000, seed: int = SEED):
    """Parametric bootstrap under the hypothesis of perfectly stable latent
    subtype identity, at the realised sample size."""
    rng = np.random.default_rng(seed)
    kaps = np.empty(n_sim)
    rs = np.empty(n_sim)
    for i in range(n_sim):
        c = rng.choice([-1.0, 1.0], size=n)
        theta = c * np.sqrt(omega * rho) + rng.standard_normal(n) * np.sqrt((1 - omega) * rho)
        s1 = theta + rng.standard_normal(n) * np.sqrt(1 - rho)
        s2 = theta + rng.standard_normal(n) * np.sqrt(1 - rho)
        kaps[i] = th.cohen_kappa(s1 > 0, s2 > 0)
        rs[i] = np.corrcoef(s1, s2)[0, 1]
    kaps = kaps[np.isfinite(kaps)]
    return {
        "kappa_null_mean": float(kaps.mean()),
        "kappa_null_ci95": [float(np.percentile(kaps, 2.5)), float(np.percentile(kaps, 97.5))],
        "p_kappa_below_null": float((kaps <= kappa_obs).mean()),
        "r_null_mean": float(rs.mean()),
        "r_null_ci95": [float(np.percentile(rs, 2.5)), float(np.percentile(rs, 97.5))],
        "p_r_below_null": float((rs <= r_obs).mean()),
    }


def main() -> None:
    out: dict = {}
    m = P.fit_model(T=PRIMARY_T)
    meta = m["meta"]
    pairs = P.longitudinal_pairs(meta)
    print(f"primary model: T={PRIMARY_T}s, discovery n={m['disc'].size}, "
          f"rho_full={m['rho_full']:.3f}; {len(pairs)} longitudinal pairs", flush=True)
    print(pairs[["subject", "dx", "age1", "age2", "interval", "keep1", "keep2"]]
          .to_string(index=False), flush=True)

    with open(os.path.join(RESULTS, "06_subtyping.json")) as f:
        prev = json.load(f)
    omega = float(prev["omega_primary"])
    out["omega_used"] = omega
    out["pairs_table"] = pairs.to_dict("records")

    # --------------------------------------------------------------- primary
    st, l1, l2 = pair_stats(m, pairs, omega=omega)
    out["primary"] = st
    print(f"  kappa between waves = {st['kappa_between_waves']:.3f} "
          f"{st['kappa_ci']}; r = {st['r_score_between_waves']:.3f}; "
          f"ceiling = {st['ceiling_local']['kappa_max']:.3f}; "
          f"SSI = {st['ceiling_local']['SSI']:.2f}; "
          f"half-life = {st['ceiling_local']['half_life_years']:.2f} y", flush=True)

    out["trait_null_local"] = trait_null_test(
        st["rho_local_full"], omega, len(pairs),
        st["kappa_between_waves"], st["r_score_between_waves"])
    out["trait_null_discovery"] = trait_null_test(
        st["rho_discovery_full"], omega, len(pairs),
        st["kappa_between_waves"], st["r_score_between_waves"])

    # ------------------------------------------- reliability-regularised axis
    st_rr, _, _ = pair_stats(m, pairs, score_key="score_rr", omega=omega)
    out["reliability_regularised"] = st_rr
    print(f"  reliability-regularised: kappa = {st_rr['kappa_between_waves']:.3f}, "
          f"r = {st_rr['r_score_between_waves']:.3f}, "
          f"rho_local = {st_rr['rho_local_full']:.3f}", flush=True)

    # ----------------------------------------- per-participant change indices
    s = m["score"]
    sigma_e = np.sqrt(max(1.0 - st["rho_local_full"], 1e-6))
    d = s["matched"][pairs.i2.values] - s["matched"][pairs.i1.values]
    rci = d / (sigma_e * np.sqrt(2.0))
    pairs = pairs.assign(score1=s["matched"][pairs.i1.values],
                         score2=s["matched"][pairs.i2.values],
                         delta=d, rci=rci,
                         label1=l1, label2=l2, switched=(l1 != l2).astype(int),
                         score_rr1=m["score_rr"]["matched"][pairs.i1.values],
                         score_rr2=m["score_rr"]["matched"][pairs.i2.values])
    pairs.to_csv(os.path.join(RESULTS, "longitudinal_pairs.csv"), index=False)
    out["reliable_change"] = {
        "n_exceeding_1p96": int((np.abs(rci) > 1.96).sum()),
        "frac_exceeding_1p96": float((np.abs(rci) > 1.96).mean()),
        "expected_frac_under_null": 0.05,
        "binomial_p": float(stats.binomtest(int((np.abs(rci) > 1.96).sum()),
                                            len(rci), 0.05).pvalue),
        "mean_abs_rci": float(np.abs(rci).mean())}

    # ------------------------------------- group drift vs individual change
    tt = stats.ttest_rel(s["matched"][pairs.i2.values], s["matched"][pairs.i1.values])
    out["group_drift"] = {
        "mean_delta": float(d.mean()), "sd_delta": float(d.std(ddof=1)),
        "t": float(tt.statistic), "p": float(tt.pvalue),
        "cohens_dz": float(d.mean() / d.std(ddof=1))}
    X = np.column_stack([np.ones(len(pairs)), pairs.age1.values,
                         pairs.interval.values, (pairs.dx == "ASD").astype(float)])
    beta, *_ = np.linalg.lstsq(X, d, rcond=None)
    resid = d - X @ beta
    dof = len(d) - X.shape[1]
    se = np.sqrt(np.sum(resid ** 2) / dof * np.diag(np.linalg.pinv(X.T @ X)))
    out["delta_regression"] = {
        "terms": ["intercept", "baseline_age", "interval_y", "ASD"],
        "beta": [float(b) for b in beta], "se": [float(x) for x in se],
        "t": [float(b / x) if x > 0 else np.nan for b, x in zip(beta, se)],
        "p": [float(2 * stats.t.sf(abs(b / x), dof)) if x > 0 else np.nan
              for b, x in zip(beta, se)], "dof": int(dof)}

    # -------------------------------------------------------- ASD versus TDC
    grp = {}
    for g in ("ASD", "TDC"):
        sel = (pairs.dx == g).values
        if sel.sum() >= 3:
            r = float(np.corrcoef(pairs.score1[sel], pairs.score2[sel])[0, 1])
            grp[g] = {"n": int(sel.sum()), "r": r,
                      "kappa": th.cohen_kappa(pairs.label1[sel], pairs.label2[sel]),
                      "mean_abs_delta": float(np.abs(pairs.delta[sel]).mean()),
                      "switch_rate": float(pairs.switched[sel].mean())}
    if len(grp) == 2:
        a = np.abs(pairs.delta[(pairs.dx == "ASD").values])
        b = np.abs(pairs.delta[(pairs.dx == "TDC").values])
        u = stats.mannwhitneyu(a, b)
        grp["ASD_vs_TDC_abs_delta"] = {"U": float(u.statistic), "p": float(u.pvalue)}
    out["by_diagnosis"] = grp

    # ------------------------------------------------ sensitivity: duration
    dur = []
    for T in DURATIONS:
        mm = P.fit_model(T=T)
        pp = P.longitudinal_pairs(mm["meta"])
        if len(pp) < 4:
            dur.append(dict(T=T, n_pairs=len(pp)))
            continue
        stt, _, _ = pair_stats(mm, pp, omega=omega)
        dur.append(dict(T=T, n_pairs=len(pp), n_discovery=int(mm["disc"].size),
                        r_half=mm["r_half"], rho_full=mm["rho_full"],
                        kappa=stt["kappa_between_waves"],
                        r_long=stt["r_score_between_waves"],
                        ceiling=stt["ceiling_local"]["kappa_max"],
                        ssi=stt["ceiling_local"]["SSI"],
                        tau=stt["ceiling_local"]["tau_years"],
                        half_life=stt["ceiling_local"]["half_life_years"],
                        rho_local=stt["rho_local_full"]))
        print(f"  T={T}: n={len(pp)} rho={mm['rho_full']:.3f} "
              f"kappa={stt['kappa_between_waves']:.3f} "
              f"r_long={stt['r_score_between_waves']:.3f}", flush=True)
        del mm
    out["sensitivity_duration"] = dur
    pd.DataFrame(dur).to_csv(os.path.join(RESULTS, "sensitivity_duration.csv"), index=False)

    # --------------------------------------------- sensitivity: parcellation
    atl = []
    for a in ATLASES:
        try:
            mm = P.fit_model(atlas=a, T=PRIMARY_T)
        except FileNotFoundError:
            continue
        pp = P.longitudinal_pairs(mm["meta"])
        if len(pp) < 4:
            continue
        stt, _, _ = pair_stats(mm, pp, omega=omega)
        atl.append(dict(atlas=a, n_pairs=len(pp), rho_full=mm["rho_full"],
                        kappa=stt["kappa_between_waves"],
                        r_long=stt["r_score_between_waves"],
                        ceiling=stt["ceiling_local"]["kappa_max"],
                        ssi=stt["ceiling_local"]["SSI"],
                        half_life=stt["ceiling_local"]["half_life_years"]))
        print(f"  {a}: rho={mm['rho_full']:.3f} kappa={stt['kappa_between_waves']:.3f}",
              flush=True)
        del mm
    out["sensitivity_atlas"] = atl
    pd.DataFrame(atl).to_csv(os.path.join(RESULTS, "sensitivity_atlas.csv"), index=False)

    # ------------------------------- sensitivity: algorithm, k, and nuisance
    alg = []
    for algo in ("kmeans", "ward", "gmm", "spectral"):
        mm = P.fit_model(T=PRIMARY_T, algo=algo)
        pp = P.longitudinal_pairs(mm["meta"])
        stt, _, _ = pair_stats(mm, pp, omega=omega)
        alg.append(dict(variant=f"algo={algo}", rho_full=mm["rho_full"],
                        kappa=stt["kappa_between_waves"],
                        r_long=stt["r_score_between_waves"],
                        ceiling=stt["ceiling_local"]["kappa_max"],
                        ssi=stt["ceiling_local"]["SSI"]))
        del mm
    for npc in (20, 50, 100):
        mm = P.fit_model(T=PRIMARY_T, n_pc=npc)
        pp = P.longitudinal_pairs(mm["meta"])
        stt, _, _ = pair_stats(mm, pp, omega=omega)
        alg.append(dict(variant=f"n_pc={npc}", rho_full=mm["rho_full"],
                        kappa=stt["kappa_between_waves"],
                        r_long=stt["r_score_between_waves"],
                        ceiling=stt["ceiling_local"]["kappa_max"],
                        ssi=stt["ceiling_local"]["SSI"]))
        del mm
    for nui in ((), ("mean_fd",), ("mean_fd", "age"), ("mean_fd", "age", "SEX")):
        mm = P.fit_model(T=PRIMARY_T, nuisance=nui)
        pp = P.longitudinal_pairs(mm["meta"])
        stt, _, _ = pair_stats(mm, pp, omega=omega)
        alg.append(dict(variant="nuisance=" + ("none" if not nui else "+".join(nui)),
                        rho_full=mm["rho_full"], kappa=stt["kappa_between_waves"],
                        r_long=stt["r_score_between_waves"],
                        ceiling=stt["ceiling_local"]["kappa_max"],
                        ssi=stt["ceiling_local"]["SSI"]))
        del mm
    out["sensitivity_variants"] = alg
    pd.DataFrame(alg).to_csv(os.path.join(RESULTS, "sensitivity_variants.csv"), index=False)

    # multi-class agreement (k = 3, 4)
    multi = []
    for k in (2, 3, 4):
        mm = P.fit_model(T=PRIMARY_T, k=k)
        pp = P.longitudinal_pairs(mm["meta"])
        lab = mm["labels"]["matched"]
        kap = th.cohen_kappa(lab[pp.i1.values], lab[pp.i2.values])
        la = mm["labels"]["conA"]
        lb = mm["labels"]["conB"]
        idx = np.concatenate([pp.i1.values, pp.i2.values])
        multi.append(dict(k=k, kappa_between_waves=kap,
                          kappa_within_session=th.cohen_kappa(la[idx], lb[idx]),
                          kappa_within_session_discovery=th.cohen_kappa(
                              la[mm["disc"]], lb[mm["disc"]])))
        print(f"  k={k}: kappa_between={kap:.3f}", flush=True)
        del mm
    out["sensitivity_k"] = multi
    pd.DataFrame(multi).to_csv(os.path.join(RESULTS, "sensitivity_k.csv"), index=False)

    with open(os.path.join(RESULTS, "07_longitudinal.json"), "w") as f:
        json.dump(out, f, indent=1, default=float)
    print("written results/07_longitudinal.json")


if __name__ == "__main__":
    main()
