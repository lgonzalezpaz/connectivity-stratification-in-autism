"""Step 6 - cross-sectional subtype discovery, score reliability, ceiling test.

All model fitting happens in the cross-sectional autistic sample, so that the
longitudinal participants of step 7 are an untouched out-of-sample test set.

Analyses
--------
1.  Cluster-number selection (silhouette, resampling ARI/AMI, proportion of
    ambiguous clustering) with consensus k-means.
2.  Description of the primary two-subtype solution: mean connectivity, network
    composition of the discriminant, clinical and motion correlates.
3.  Reliability of the subtype score from within-session split halves, and the
    edge-level reliability distribution, which is compared with the
    meta-analytic value reported for resting-state connectivity.
4.  The decisive internal test of the theory: observed within-session label
    agreement against the agreement predicted by the ceiling equation at the
    measured reliability and the observed subtype prevalence.
5.  Categoricity: omega by method of moments from the zero-interval agreement,
    with Hartigan's dip test and out-of-sample Gaussian-mixture BIC reported as
    independent descriptive evidence.
6.  Reliability-regularised subtyping (clustering in the error-whitened
    subspace), evaluated out of fold.
"""
from __future__ import annotations

import importlib.util
import json
import os
import sys

import numpy as np
import pandas as pd
from scipy import stats
from sklearn.cluster import KMeans
from sklearn.metrics import adjusted_mutual_info_score, adjusted_rand_score, silhouette_score
from sklearn.mixture import GaussianMixture

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import pipeline as P  # noqa: E402

_spec = importlib.util.spec_from_file_location("theory", os.path.join(HERE, "03_theory.py"))
th = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(th)

ROOT = os.path.dirname(HERE)
DATA = os.path.join(ROOT, "data")
RESULTS = os.path.join(ROOT, "results")
ATLAS = "Gordon2014FreeSurferSubcortical"
T = 150
SEED = 20261024


def consensus_kmeans(Z, k, n_resample=300, frac=0.8, seed=SEED):
    rng = np.random.default_rng(seed)
    n = Z.shape[0]
    co = np.zeros((n, n), dtype=np.float32)
    cnt = np.zeros((n, n), dtype=np.float32)
    labs = []
    for _ in range(n_resample):
        idx = rng.choice(n, size=int(frac * n), replace=False)
        lab = KMeans(k, n_init=10, random_state=int(rng.integers(1e6))).fit_predict(Z[idx])
        for c in range(k):
            m = idx[lab == c]
            co[np.ix_(m, m)] += 1
        cnt[np.ix_(idx, idx)] += 1
        full = np.full(n, -1)
        full[idx] = lab
        labs.append(full)
    co = np.divide(co, cnt, out=np.zeros_like(co), where=cnt > 0)
    L = np.vstack(labs)
    aris, amis = [], []
    rng2 = np.random.default_rng(seed + 1)
    for _ in range(300):
        i, j = rng2.integers(0, L.shape[0], 2)
        both = (L[i] >= 0) & (L[j] >= 0)
        if both.sum() < 20:
            continue
        aris.append(adjusted_rand_score(L[i][both], L[j][both]))
        amis.append(adjusted_mutual_info_score(L[i][both], L[j][both]))
    off = co[np.triu_indices_from(co, 1)]
    return (float(np.mean(aris)), float(np.mean(amis)),
            float(np.mean((off > 0.1) & (off < 0.9))), co)


def bimodality(scores, seed=SEED):
    """Out-of-sample evidence on whether the score distribution is two-humped."""
    import diptest
    s = np.asarray(scores, float)
    s = (s - s.mean()) / s.std()
    dip, pval = diptest.diptest(s)
    g1 = GaussianMixture(1, random_state=seed).fit(s.reshape(-1, 1))
    g2 = GaussianMixture(2, covariance_type="tied", n_init=10,
                         random_state=seed).fit(s.reshape(-1, 1))
    m3 = stats.skew(s)
    m4 = stats.kurtosis(s, fisher=False)
    bc = (m3 ** 2 + 1) / m4                      # Sarle's bimodality coefficient
    return {"dip_statistic": float(dip), "dip_p": float(pval),
            "bic_1comp": float(g1.bic(s.reshape(-1, 1))),
            "bic_2comp": float(g2.bic(s.reshape(-1, 1))),
            "delta_bic_2minus1": float(g2.bic(s.reshape(-1, 1)) - g1.bic(s.reshape(-1, 1))),
            "bimodality_coefficient": float(bc),
            "bc_threshold_uniform": 0.555,
            "skew": float(m3), "kurtosis": float(m4),
            "preferred_by_bic": "two-component" if g2.bic(s.reshape(-1, 1)) <
                                g1.bic(s.reshape(-1, 1)) else "single Gaussian"}


def main() -> None:
    rng = np.random.default_rng(SEED)
    m = P.fit_model(atlas=ATLAS, T=T)
    meta, disc, Z = m["meta"], m["disc"], m["Z"]
    s, lab = m["score"], m["labels"]
    out = {"atlas": ATLAS, "matched_seconds": T, "n_sessions": int(len(meta)),
           "n_discovery": int(disc.size), "n_pc": m["n_pc"],
           "pca_explained_variance": m["pca_evr"],
           "nuisance_regressed": list(m["nuisance"]),
           "dx_counts": meta.dx.value_counts().to_dict(),
           "edges": int(np.load(os.path.join(
               DATA, f"conn_{ATLAS}_T{T}_matched.npy"), mmap_mode="r").shape[1])}
    print(f"{len(meta)} sessions, discovery n={disc.size}, "
          f"PCA {m['pca_evr']:.1%} variance", flush=True)

    # ------------------------------------------------ cluster-number selection
    sel = []
    for k in range(2, 7):
        km = KMeans(k, n_init=50, random_state=SEED).fit(Z["matched"][disc])
        ari, ami, pac, _ = consensus_kmeans(Z["matched"][disc], k)
        sel.append(dict(k=k, silhouette=float(silhouette_score(Z["matched"][disc], km.labels_)),
                        resample_ari=ari, resample_ami=ami, pac=pac,
                        inertia=float(km.inertia_)))
        print(f"  k={k}: silhouette={sel[-1]['silhouette']:.3f} ARI={ari:.3f} "
              f"AMI={ami:.3f} PAC={pac:.3f}", flush=True)
    pd.DataFrame(sel).to_csv(os.path.join(RESULTS, "cluster_selection.csv"), index=False)
    out["cluster_selection"] = sel

    # --------------------------------------------------- subtype description
    nlab = np.bincount(lab["matched"][disc], minlength=2)
    out["subtype_n"] = nlab.tolist()
    out["subtype_prevalence_smaller"] = float(m["prevalence"])
    mfc = m["mean_fc"][disc]
    g0 = lab["matched"][disc] == 0
    tt = stats.ttest_ind(mfc[~g0], mfc[g0])
    out["mean_connectivity_difference"] = {
        "delta_fisher_z": float(mfc[~g0].mean() - mfc[g0].mean()),
        "t": float(tt.statistic), "p": float(tt.pvalue),
        "cohens_d": float((mfc[~g0].mean() - mfc[g0].mean()) /
                          np.sqrt((mfc[~g0].var(ddof=1) + mfc[g0].var(ddof=1)) / 2))}
    out["score_vs_mean_connectivity_r"] = float(np.corrcoef(s["matched"][disc], mfc)[0, 1])

    # network composition of the discriminant (edge weights back-projected)
    w_edge = m["pca"].components_.T @ ((m["cen"][1] - m["cen"][0]) /
                                       np.linalg.norm(m["cen"][1] - m["cen"][0]))
    par = pd.read_csv(os.path.join(RESULTS, f"parcels_{ATLAS}.csv"))
    iu = np.triu_indices(len(par), 1)
    net = par.network.fillna("unlabelled").astype(str).values
    ni, nj = net[iu[0]], net[iu[1]]
    rows = []
    for a in sorted(set(net)):
        for b in sorted(set(net)):
            if a > b:
                continue
            msk = ((ni == a) & (nj == b)) | ((ni == b) & (nj == a))
            if msk.sum() < 20:
                continue
            rows.append(dict(net_a=a, net_b=b, n_edges=int(msk.sum()),
                             mean_abs_weight=float(np.abs(w_edge[msk]).mean()),
                             mean_weight=float(w_edge[msk].mean())))
    nd = pd.DataFrame(rows).sort_values("mean_abs_weight", ascending=False)
    nd.to_csv(os.path.join(RESULTS, "discriminant_by_network.csv"), index=False)
    out["top_network_pairs"] = nd.head(10).to_dict("records")

    # --------------------------------------------------------- reliability
    rel = {}
    for st, nm in (("con", "contiguous"), ("int", "interleaved")):
        a, b = s[f"{st}A"][disc], s[f"{st}B"][disc]
        r = float(np.corrcoef(a, b)[0, 1])
        rel[nm] = {"r_halfhalf": r, "icc_halfhalf": th.icc_consistency(a, b),
                   "rho_full_sb": th.spearman_brown(r, 2.0),
                   "ci_r": list(th.fisher_ci(r, disc.size))}
        print(f"  {nm}: split-half r={r:.3f} -> rho_full={rel[nm]['rho_full_sb']:.3f}",
              flush=True)
    out["score_reliability"] = rel

    Xm = np.load(os.path.join(DATA, f"conn_{ATLAS}_T{T}_conA.npy"), mmap_mode="r")
    Xn = np.load(os.path.join(DATA, f"conn_{ATLAS}_T{T}_conB.npy"), mmap_mode="r")
    a = np.asarray(Xm[disc], dtype=np.float32)
    b = np.asarray(Xn[disc], dtype=np.float32)
    num = ((a - a.mean(0)) * (b - b.mean(0))).mean(0)
    den = a.std(0) * b.std(0)
    edge_r = num / np.where(den == 0, np.nan, den)
    edge_icc = np.array([th.icc_consistency(a[:, j], b[:, j])
                         for j in rng.choice(a.shape[1], 3000, replace=False)])
    out["edge_reliability"] = {
        "median_r_halfhalf": float(np.nanmedian(edge_r)),
        "iqr_r": [float(np.nanpercentile(edge_r, 25)), float(np.nanpercentile(edge_r, 75))],
        "median_rho_full_sb": float(th.spearman_brown(float(np.nanmedian(edge_r)), 2.0)),
        "median_icc_halfhalf_sample3000": float(np.nanmedian(edge_icc)),
        "median_icc_full_sb": float(th.spearman_brown(float(np.nanmedian(edge_icc)), 2.0)),
        "frac_r_above_0p4": float(np.nanmean(edge_r > 0.4)),
        "score_vs_median_edge_gain": float(rel["contiguous"]["rho_full_sb"] /
                                           th.spearman_brown(float(np.nanmedian(edge_r)), 2.0))}
    np.save(os.path.join(DATA, "edge_halfhalf_r.npy"), edge_r.astype(np.float32))
    print(f"  edge-level: median half-half r={out['edge_reliability']['median_r_halfhalf']:.3f} "
          f"-> rho={out['edge_reliability']['median_rho_full_sb']:.3f}", flush=True)
    del a, b

    # --------------------- ceiling test and method-of-moments categoricity
    tests = {}
    for st, nm in (("con", "contiguous"), ("int", "interleaved")):
        lA = lab[f"{st}A"][disc]
        lB = lab[f"{st}B"][disc]
        k_obs = th.cohen_kappa(lA, lB)
        ci = th.kappa_ci_bootstrap(lA, lB, n_boot=10000, seed=SEED)
        r_half = rel[nm]["r_halfhalf"]
        prev = float(min(lA.mean(), 1 - lA.mean()))
        om_bal = th.omega_from_kappa(k_obs, r_half)
        om_prev = th.omega_from_kappa(k_obs, r_half, prev)
        tests[nm] = {
            "kappa_observed": k_obs, "kappa_ci": list(ci),
            "reliability_at_half_length": r_half,
            "prevalence_smaller_label": prev,
            "kappa_max_continuum": float(th.kappa_max_continuum(r_half)),
            "kappa_max_categorical": float(th.kappa_max_categorical(r_half)),
            "kappa_max_prevalence_continuum": th.kappa_max_unbalanced(r_half, prev, 0.0),
            "omega_moment_balanced": om_bal,
            "omega_moment_prevalence": om_prev,
            "within_bracket": bool(float(th.kappa_max_continuum(r_half)) <= ci[1] and
                                   float(th.kappa_max_categorical(r_half)) >= ci[0])}
        print(f"  {nm}: kappa_obs={k_obs:.3f} {np.round(ci,3).tolist()} | bracket "
              f"[{tests[nm]['kappa_max_continuum']:.3f}, "
              f"{tests[nm]['kappa_max_categorical']:.3f}] | omega_hat="
              f"{om_prev:.3f}", flush=True)
    out["within_session_ceiling_test"] = tests
    out["omega_primary"] = tests["contiguous"]["omega_moment_prevalence"]

    # ------------------------------------------- independent bimodality checks
    perm = rng.permutation(disc)
    fit_i, ev_i = perm[: perm.size // 2], perm[perm.size // 2:]
    from sklearn.decomposition import PCA
    pca_cv = PCA(n_components=m["n_pc"], random_state=SEED)
    Zc_fit = pca_cv.fit_transform(np.asarray(
        np.load(os.path.join(DATA, f"conn_{ATLAS}_T{T}_matched.npy"), mmap_mode="r")[fit_i],
        dtype=np.float32))
    Zc_all = pca_cv.transform(np.asarray(
        np.load(os.path.join(DATA, f"conn_{ATLAS}_T{T}_matched.npy"), mmap_mode="r"),
        dtype=np.float32))
    _, cen_cv = P.cluster(Zc_fit, 2, "kmeans", SEED)
    s_cv = P.axis_score(Zc_all, cen_cv)[0]
    out["bimodality_out_of_sample"] = bimodality(s_cv[ev_i])
    out["bimodality_in_sample"] = bimodality(s["matched"][disc])
    print(f"  bimodality (out of sample): dip p={out['bimodality_out_of_sample']['dip_p']:.3f}, "
          f"deltaBIC={out['bimodality_out_of_sample']['delta_bic_2minus1']:.1f} "
          f"({out['bimodality_out_of_sample']['preferred_by_bic']})", flush=True)

    # ------------------------------------------- reliability-regularised axis
    srr = m["score_rr_oof"]
    lrr_a = (srr[disc, 1] > 0).astype(int)
    lrr_b = (srr[disc, 2] > 0).astype(int)
    out["reliability_regularised"] = {
        "r_halfhalf_out_of_fold": m["r_half_rr"],
        "rho_full_sb_out_of_fold": m["rho_full_rr"],
        "kappa_within_session_out_of_fold": th.cohen_kappa(lrr_a, lrr_b),
        "gain_in_rho": m["rho_full_rr"] - rel["contiguous"]["rho_full_sb"],
        "cosine_with_standard_axis": float(np.dot(
            (m["cen_rr"][1] - m["cen_rr"][0]) / np.linalg.norm(m["cen_rr"][1] - m["cen_rr"][0]),
            (m["cen"][1] - m["cen"][0]) / np.linalg.norm(m["cen"][1] - m["cen"][0])))}
    print(f"  reliability-regularised (out of fold): rho={m['rho_full_rr']:.3f} "
          f"vs standard {rel['contiguous']['rho_full_sb']:.3f}", flush=True)

    # ---------------------------------------------------- clinical correlates
    dd = meta.loc[disc]
    corr = {}
    for v in ("age", "FIQ", "VIQ", "PIQ", "ADOS_2_SEVERITY_TOTAL", "ADOS_G_TOTAL",
              "SRS_TOTAL_RAW", "ADI_R_SOCIAL_TOTAL_A", "mean_fd", "keep_s"):
        if v not in dd:
            continue
        x = pd.to_numeric(dd[v], errors="coerce").values
        ok = np.isfinite(x)
        if ok.sum() > 30:
            r, p = stats.pearsonr(s["matched"][disc][ok], x[ok])
            corr[v] = {"r": float(r), "p": float(p), "n": int(ok.sum())}
    sexd = pd.Series(dd.sex.values)
    if (sexd == "F").sum() > 10:
        u = stats.mannwhitneyu(s["matched"][disc][(sexd == "F").values],
                               s["matched"][disc][(sexd == "M").values])
        corr["sex_F_vs_M"] = {"U": float(u.statistic), "p": float(u.pvalue)}
    out["score_correlates"] = corr

    # ---------------------------------------------------------------- outputs
    sc = meta[["subject", "session", "site_scanner", "dx", "age", "sex", "wave",
               "collection", "mean_fd", "keep_s", "FIQ",
               "ADOS_2_SEVERITY_TOTAL", "SRS_TOTAL_RAW"]].copy()
    sc["score"] = s["matched"]
    sc["score_conA"] = s["conA"]
    sc["score_conB"] = s["conB"]
    sc["label"] = lab["matched"]
    sc["score_rr"] = m["score_rr"]["matched"]
    sc["label_rr"] = m["labels_rr"]["matched"]
    sc["mean_fc"] = m["mean_fc"]
    sc["in_discovery"] = False
    sc.loc[disc, "in_discovery"] = True
    sc.to_csv(os.path.join(RESULTS, "subtype_scores.csv"), index=False)
    np.save(os.path.join(DATA, "discriminant_edge_weights.npy"), w_edge.astype(np.float32))
    with open(os.path.join(RESULTS, "06_subtyping.json"), "w") as f:
        json.dump(out, f, indent=1, default=float)
    print("written results/06_subtyping.json")


if __name__ == "__main__":
    main()
