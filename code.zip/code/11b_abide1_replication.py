"""Step 11b - independent replication of the ceiling test in ABIDE I.

A different sample, a different preprocessing pipeline (C-PAC, as distributed by
the Preprocessed Connectomes Project) and a different parcellation (CC200) are
used to check that the relation between measured reliability and observed label
agreement is not specific to the DCAN/Gordon derivatives.

Because ABIDE I preprocessed derivatives do not ship per-frame motion traces,
segments are matched on frame count rather than seconds and mean framewise
displacement from the phenotypic table is used as the motion covariate; both
global-signal-regressed and non-regressed strategies are analysed.
"""
from __future__ import annotations

import importlib.util
import json
import os
import sys

import numpy as np
import pandas as pd
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
_spec = importlib.util.spec_from_file_location("theory", os.path.join(HERE, "03_theory.py"))
th = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(th)

ROOT = os.path.dirname(HERE)
DATA = os.path.join(ROOT, "data")
RESULTS = os.path.join(ROOT, "results")
N_FRAMES = 100          # frame-matched segment length
N_PC = 50
SEED = 20261024
STRATEGIES = ("filt_noglobal", "filt_global")


def fisher_z_vec(ts, iu):
    x = ts - ts.mean(0, keepdims=True)
    sd = x.std(0)
    if (sd <= 0).any():
        return None
    x = x / sd
    c = (x.T @ x) / x.shape[0]
    np.fill_diagonal(c, 0.0)
    return np.arctanh(np.clip(c, -0.999999, 0.999999))[iu].astype(np.float32)


def build(strategy, ph):
    folder = os.path.join(DATA, "abide1", strategy)
    rows, M, A, B = [], [], [], []
    iu = None
    for _, r in ph.iterrows():
        f = os.path.join(folder, f"{r.FILE_ID}_rois_cc200.1D")
        if not os.path.exists(f):
            continue
        ts = np.loadtxt(f, skiprows=1, dtype=np.float32)
        if ts.ndim != 2 or ts.shape[0] < N_FRAMES:
            continue
        if iu is None:
            iu = np.triu_indices(ts.shape[1], 1)
        if ts.shape[1] != 200:
            continue
        seg = ts[:N_FRAMES]
        h = N_FRAMES // 2
        v = fisher_z_vec(seg, iu)
        a = fisher_z_vec(seg[:h], iu)
        b = fisher_z_vec(seg[h:], iu)
        if v is None or a is None or b is None:
            continue
        M.append(v)
        A.append(a)
        B.append(b)
        rows.append(dict(file_id=r.FILE_ID, site=r.SITE_ID, dx=int(r.DX_GROUP),
                         age=float(r.AGE_AT_SCAN), sex=int(r.SEX),
                         mean_fd=float(r.func_mean_fd) if np.isfinite(r.func_mean_fd) else np.nan))
    return pd.DataFrame(rows), np.vstack(M), np.vstack(A), np.vstack(B)


def analyse(meta, M, A, B, label):
    disc = np.where(meta.dx.values == 1)[0]
    # site centring, then motion residualisation fitted in the discovery sample
    for site, idx in meta.groupby("site").groups.items():
        idx = np.asarray(list(idx))
        for X in (M, A, B):
            X[idx] -= X[idx].mean(0, keepdims=True)
    fd = meta.mean_fd.values.astype(float)
    fd = np.where(np.isfinite(fd), fd, np.nanmean(fd[np.isfinite(fd)]))
    D = np.column_stack([np.ones(len(meta)), (fd - fd.mean()) / fd.std()])
    out_X = []
    for X in (M, A, B):
        beta, *_ = np.linalg.lstsq(D[disc], X[disc], rcond=None)
        out_X.append(X - D @ beta)
    M, A, B = out_X
    sd = M[disc].std(0)
    sd[sd == 0] = 1.0
    pca = PCA(n_components=N_PC, random_state=SEED).fit(M[disc] / sd)
    Zm, Za, Zb = (pca.transform(X / sd) for X in (M, A, B))
    km = KMeans(2, n_init=100, random_state=SEED).fit(Zm[disc])
    cen = km.cluster_centers_
    mfc = M.mean(1)
    if mfc[disc][km.labels_ == 0].mean() > mfc[disc][km.labels_ == 1].mean():
        cen = cen[::-1]
    w = (cen[1] - cen[0]) / np.linalg.norm(cen[1] - cen[0])
    mid = (cen[0] + cen[1]) / 2.0
    s = {k: (Z - mid) @ w for k, Z in (("m", Zm), ("a", Za), ("b", Zb))}
    sg = s["m"][disc].std()
    s = {k: v / sg for k, v in s.items()}
    r_ws, per = th.pooled_within_group_r(s["a"][disc], s["b"][disc],
                                         meta.site.values[disc])
    r_pool = float(np.corrcoef(s["a"][disc], s["b"][disc])[0, 1])
    lA, lB = (s["a"][disc] > 0).astype(int), (s["b"][disc] > 0).astype(int)
    kap = th.cohen_kappa(lA, lB)
    ci = th.kappa_ci_bootstrap(lA, lB, n_boot=10000, seed=SEED)
    prev = float(min(lA.mean(), 1 - lA.mean()))
    num = ((A[disc] - A[disc].mean(0)) * (B[disc] - B[disc].mean(0))).mean(0)
    den = A[disc].std(0) * B[disc].std(0)
    edge_r = num / np.where(den == 0, np.nan, den)
    rec = {
        "strategy": label, "n_sessions": int(len(meta)), "n_discovery_asd": int(disc.size),
        "n_sites": int(meta.site.nunique()), "frames_matched": N_FRAMES,
        "edges": int(M.shape[1]),
        "score_r_halfhalf_within_site": float(r_ws),
        "score_r_halfhalf_pooled": r_pool,
        "score_rho_full_sb": th.spearman_brown(float(r_ws), 2.0),
        "edge_median_r_halfhalf": float(np.nanmedian(edge_r)),
        "edge_median_rho_full_sb": float(th.spearman_brown(float(np.nanmedian(edge_r)), 2.0)),
        "kappa_within_session": kap, "kappa_ci": list(ci),
        "prevalence_smaller": prev,
        "kappa_max_continuum": float(th.kappa_max_continuum(float(r_ws))),
        "kappa_max_categorical": float(th.kappa_max_categorical(float(r_ws))),
        "omega_moment": th.omega_from_kappa(kap, float(r_ws), prev),
        "reliability_by_site": per,
    }
    print(f"  {label}: n={len(meta)} (ASD {disc.size}) r_hh={r_ws:.3f} "
          f"kappa={kap:.3f} {np.round(ci,3).tolist()} bracket "
          f"[{rec['kappa_max_continuum']:.3f}, {rec['kappa_max_categorical']:.3f}] "
          f"edge rho={rec['edge_median_rho_full_sb']:.3f}", flush=True)
    return rec


def main() -> None:
    ph = pd.read_csv(os.path.join(DATA, "pheno", "ABIDEI_Phenotypic_preprocessed1.csv"))
    ph = ph[ph.FILE_ID != "no_filename"].copy()
    ph["func_mean_fd"] = pd.to_numeric(ph.get("func_mean_fd"), errors="coerce")
    out = {}
    for strat in STRATEGIES:
        meta, M, A, B = build(strat, ph)
        out[strat] = analyse(meta, M, A, B, strat)
        meta.to_csv(os.path.join(RESULTS, f"abide1_meta_{strat}.csv"), index=False)
        del M, A, B
    with open(os.path.join(RESULTS, "11_abide1_replication.json"), "w") as f:
        json.dump(out, f, indent=1, default=float)
    print("written results/11_abide1_replication.json")


if __name__ == "__main__":
    main()
