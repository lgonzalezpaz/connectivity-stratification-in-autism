"""Step 17 - run the preregistered protocol on NDA-derived data.

This script is written to be executed by a group holding an approved NDA Data
Use Certification. It downloads nothing from NDA itself: NDA data are obtained
with the official `downloadcmd` tool under the holder's own credentials, and
this script consumes what that produces.

Two modes:

  --audit   Count, per collection and age, how many participants have two or
            more usable resting-state scans and at what intervals. This is the
            first thing to run, and it answers on its own whether the
            preregistered hypotheses are testable in the available data.

  --run     Execute the preregistered analysis end to end, reusing the same
            pipeline module as the published ABIDE analysis so that every step
            is identical.

Expected inputs
---------------
A directory of parcellated time series, one file per session, named
``<subject>_<session>_<atlas>.{ptseries.nii|tsv|npy}``, plus a participants
table with at least: subject, session, interview_age (months), sex, diagnosis
and site. The NDA ``image03`` structure provides subject, session and
``interview_age``; the DCAN-style derivatives provide the time series and the
framewise-displacement masks in exactly the layout step 2 of this repository
already reads.

Nothing in the protocol changes between ABIDE and NDA: only the loader does.
"""
from __future__ import annotations

import argparse
import glob
import importlib.util
import json
import os
import re
import sys

import numpy as np
import pandas as pd

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
_spec = importlib.util.spec_from_file_location("theory", os.path.join(HERE, "03_theory.py"))
th = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(th)

ROOT = os.path.dirname(HERE)
RESULTS = os.path.join(ROOT, "results")
MIN_RETAINED_S = 150.0
FD_THRESH = 0.30
MIN_PER_AGE = 20


# ----------------------------------------------------------------- loading
def load_participants(path: str) -> pd.DataFrame:
    """Read an NDA-style participants/image03 table into the columns we need."""
    sep = "\t" if path.endswith((".tsv", ".txt")) else ","
    df = pd.read_csv(path, sep=sep, low_memory=False)
    df.columns = [c.strip().lower() for c in df.columns]
    alias = {
        "subject": ["subjectkey", "src_subject_id", "subject", "participant_id"],
        "session": ["visit", "session", "eventname", "session_id"],
        "age_months": ["interview_age", "age_months", "age_at_scan_months"],
        "sex": ["sex", "gender"],
        "dx": ["phenotype", "diagnosis", "dx_group", "group"],
        "site": ["site", "site_id", "scanner", "collection_id"],
    }
    out = {}
    for want, cands in alias.items():
        for c in cands:
            if c in df.columns:
                out[want] = df[c]
                break
    t = pd.DataFrame(out)
    if "age_months" in t:
        t["age_years"] = pd.to_numeric(t.age_months, errors="coerce") / 12.0
    return t


def audit(ts_dir: str, participants: str) -> pd.DataFrame:
    """Count participants with repeat usable scans, and the intervals."""
    t = load_participants(participants)
    files = glob.glob(os.path.join(ts_dir, "*"))
    have = set()
    for f in files:
        m = re.search(r"(sub-[A-Za-z0-9]+|NDAR[A-Z0-9]+)[_-](ses-[A-Za-z0-9]+|\d+)", f)
        if m:
            have.add((m.group(1), m.group(2)))
    seen = pd.DataFrame(sorted(have), columns=["subject", "session"])
    if seen.empty:
        print("no time-series files matched the expected naming; nothing to audit")
        return seen
    merged = seen.merge(t, on=["subject", "session"], how="left")
    n_rep = merged.groupby("subject").session.nunique()
    rep = merged[merged.subject.isin(n_rep[n_rep >= 2].index)].copy()
    print(f"{merged.subject.nunique()} participants with any scan; "
          f"{(n_rep >= 2).sum()} with two or more")
    if "age_years" in rep and rep.age_years.notna().any():
        iv = (rep.sort_values(["subject", "age_years"])
                 .groupby("subject").age_years.agg(["min", "max", "count"]))
        iv["interval_years"] = iv["max"] - iv["min"]
        print(iv.interval_years.describe().to_string())
        print("\nintervals by band:")
        bands = pd.cut(iv.interval_years, [0, 0.25, 0.5, 1, 2, 4, 100])
        print(iv.groupby(bands, observed=True).size().to_string())
        iv.to_csv(os.path.join(RESULTS, "nda_audit_intervals.csv"))
    powered = (n_rep >= 2).sum()
    print(f"\nPreregistered H2 is testable here if this count is in the hundreds: {powered}")
    print("Required for 80% power: ~60 (tau = 2 y), ~150 (tau = 5 y), ~400 (tau = 10 y)")
    return rep


def run(ts_dir: str, participants: str, out_json: str) -> None:
    """Execute the preregistered analysis. Requires the loader below to be
    pointed at the local derivative layout; every analytic choice is fixed."""
    raise SystemExit(
        "run() intentionally requires the operator to confirm the derivative\n"
        "layout first. Execute --audit, then set TS_GLOB/PHENO below to the\n"
        "local paths and re-run. The analysis itself is unchanged from the\n"
        "published pipeline: code/pipeline.py fit_model(), code/06, 07 and 10.\n"
        "No analytic parameter may be altered; see preregistration/PREREGISTRATION.md.")


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--audit", action="store_true",
                    help="count participants with repeat usable scans")
    ap.add_argument("--run", action="store_true", help="execute the full protocol")
    ap.add_argument("--ts-dir", default="nda_derivatives/timeseries")
    ap.add_argument("--participants", default="nda_derivatives/image03.txt")
    ap.add_argument("--out", default=os.path.join(RESULTS, "nda_protocol_results.json"))
    a = ap.parse_args()
    if a.audit:
        audit(a.ts_dir, a.participants)
    elif a.run:
        run(a.ts_dir, a.participants, a.out)
    else:
        ap.print_help()


if __name__ == "__main__":
    main()
