"""Step 3 - the stability-ceiling theory (closed-form results + Monte-Carlo check).

Equation numbers in this module are local; the manuscript numbers the same
results (1)-(9) here as (3)-(9) and (11), because it additionally numbers the
connectome and subtype-score definitions. The mapping is: local (1)-(3) ->
manuscript (3)-(5); local (4)-(5) -> manuscript (6)-(7); local (6) -> (8);
local (7) -> (9); local (8) -> (10); local (9) -> (11).

Framework
---------
A two-subtype connectome solution assigns labels by nearest centroid, a rule
that depends on the data only through the scalar projection onto the
centroid-difference axis (the *subtype score*).  Write the standardised score of
participant i at occasion t as

    s_i(t) = theta_i(t) + eps_i(t),      Var(s) = 1,                          (1)

where theta is the latent (true) score and eps independent measurement error.
The test-retest correlation of the score is then its reliability,

    rho = Var(theta) / (Var(theta) + Var(eps)) = Var(theta).                  (2)

The latent score itself is decomposed into a categorical part (which of two
classes the individual belongs to) and a continuous part (where the individual
sits within its class):

    theta_i = c_i * sqrt(omega * rho) + b_i,   c_i = +-1,
    b_i ~ N(0, (1 - omega) * rho),                                            (3)

so that omega in [0, 1] is the share of reliable (latent) variance that is
*between* classes.  omega = 1 is a true dichotomy; omega = 0 is a pure Gaussian
continuum cut in two by the clustering algorithm.

With a balanced median split, labels L(t) = 1[s(t) > 0], expected agreement is

    P_o(rho, omega) = 1 - 2*Phi(-m) + 2*Phi2(-m, -m; r),
    m = sqrt(omega*rho / (1 - omega*rho)),
    r = (1 - omega)*rho / (1 - omega*rho),                                    (4)

and because the marginals are symmetric, chance agreement is 1/2, giving the
*stability ceiling*

    kappa_max(rho, omega) = 2*P_o - 1.                                        (5)

Equation (5) has two exact limits that bracket every intermediate case:

    omega -> 0 :  kappa_max = (2/pi) * arcsin(rho)                            (6)
    omega -> 1 :  kappa_max = (2*Phi(sqrt(rho/(1-rho))) - 1)^2                (7)

Equation (6) is the appropriate benchmark when subtypes are cuts through a
continuum - the situation for which there is current evidence in autism
connectomics - and equation (7) the benchmark if genuinely discrete biotypes
exist.  Observed agreement is compared with the ceiling through the Subtype
Stability Index

    SSI = kappa_obs / kappa_max(rho, omega).                                  (8)

True developmental reconfiguration is modelled as exponential decorrelation of
the latent score with characteristic time tau,

    kappa(dt) = kappa_max(rho_0 * exp(-dt/tau), omega),                       (9)

with half-life t_half = tau * ln 2.  Reliability scales with scan duration by
the Spearman-Brown relation, which turns equation (5) into a design calculator.
"""
from __future__ import annotations

import numpy as np
from scipy import optimize, stats

_SQRT2 = np.sqrt(2.0)


# ---------------------------------------------------------------- basic pieces
def phi2(a: float, b: float, rho: float) -> float:
    """Standard bivariate normal CDF P(Z1 <= a, Z2 <= b) with correlation rho."""
    rho = float(np.clip(rho, -0.999999, 0.999999))
    return float(stats.multivariate_normal(mean=[0.0, 0.0],
                                           cov=[[1.0, rho], [rho, 1.0]]).cdf([a, b]))


def kappa_max(rho: float, omega: float = 0.0) -> float:
    """Stability ceiling, equation (5): balanced two-subtype solution."""
    rho = float(np.clip(rho, 0.0, 0.999999))
    omega = float(np.clip(omega, 0.0, 1.0))
    if rho <= 0:
        return 0.0
    wr = omega * rho
    m = np.sqrt(wr / (1.0 - wr)) if wr < 1 else np.inf
    r = (1.0 - omega) * rho / (1.0 - wr) if wr < 1 else 0.0
    if not np.isfinite(m):
        return 1.0
    p_o = 1.0 - 2.0 * stats.norm.cdf(-m) + 2.0 * phi2(-m, -m, r)
    return float(2.0 * p_o - 1.0)


def kappa_max_continuum(rho) -> np.ndarray:
    """Equation (6): omega = 0 limit."""
    rho = np.clip(np.asarray(rho, dtype=float), 0.0, 1.0)
    return (2.0 / np.pi) * np.arcsin(rho)


def kappa_max_categorical(rho) -> np.ndarray:
    """Equation (7): omega = 1 limit."""
    rho = np.clip(np.asarray(rho, dtype=float), 0.0, 1.0 - 1e-12)
    u = np.sqrt(rho / (1.0 - rho))
    return (2.0 * stats.norm.cdf(u) - 1.0) ** 2


def kappa_max_unbalanced(rho: float, prevalence: float, omega: float = 0.0) -> float:
    """Ceiling when the smaller subtype has prevalence p < 0.5 (numeric).

    The decision threshold is placed at the quantile reproducing the observed
    prevalence; the categorical component shifts the class means accordingly.
    """
    rho = float(np.clip(rho, 0.0, 0.999999))
    p = float(np.clip(prevalence, 1e-4, 0.5))
    c = float(stats.norm.ppf(1.0 - p))
    if omega <= 0:
        fc = stats.norm.cdf(c)
        p_o = 1.0 - 2.0 * fc + 2.0 * phi2(c, c, rho)
        p_e = fc ** 2 + (1.0 - fc) ** 2
        return float((p_o - p_e) / (1.0 - p_e))
    # two-component mixture with priors (p, 1-p) and matched marginal variance
    wr = omega * rho
    sd = np.sqrt(1.0 - wr)
    r = (1.0 - omega) * rho / (1.0 - wr)
    d = np.sqrt(wr / (p * (1.0 - p)))           # class separation in SD units
    mu = np.array([-p * d, (1.0 - p) * d])      # zero-mean mixture
    pri = np.array([1.0 - p, p])
    p_o = 0.0
    p1 = 0.0
    for w, mk in zip(pri, mu):
        z = (c - mk) / sd
        p_o += w * (1.0 - 2.0 * stats.norm.cdf(z) + 2.0 * phi2(z, z, r))
        p1 += w * (1.0 - stats.norm.cdf(z))
    p_e = p1 ** 2 + (1.0 - p1) ** 2
    return float((p_o - p_e) / (1.0 - p_e))


def rho_for_kappa(kappa: float, omega: float = 0.0) -> float:
    """Invert the ceiling: reliability required to reach a target kappa."""
    f = lambda r: kappa_max(r, omega) - kappa
    if f(0.999999) < 0:
        return float("nan")
    return float(optimize.brentq(f, 1e-9, 0.999999, xtol=1e-10))


def omega_from_kappa(kappa_obs: float, rho: float,
                     prevalence: float | None = None) -> float:
    """Method-of-moments categoricity: the omega for which the ceiling equals an
    observed agreement measured at effectively zero interval.

    With *prevalence* given, the unbalanced ceiling is inverted instead, so the
    estimate respects the actual subtype sizes produced by the clustering.
    """
    f_ceil = (lambda w: kappa_max(rho, w)) if prevalence is None else \
             (lambda w: kappa_max_unbalanced(rho, prevalence, w))
    lo, hi = f_ceil(0.0), f_ceil(1.0)
    if not (lo < kappa_obs < hi):
        return 0.0 if kappa_obs <= lo else 1.0
    return float(optimize.brentq(lambda w: f_ceil(w) - kappa_obs, 0.0, 1.0, xtol=1e-8))


# ------------------------------------------------------- duration / attenuation
def spearman_brown(r: float, k: float) -> float:
    """Reliability after multiplying measurement length by k."""
    r = float(np.clip(r, 1e-9, 1 - 1e-9))
    return float(k * r / (1.0 + (k - 1.0) * r))


def rho_from_duration(rho_ref: float, T: float, T_ref: float) -> float:
    return spearman_brown(rho_ref, T / T_ref)


def duration_for_kappa(kappa_target: float, rho_ref: float, T_ref: float,
                       omega: float = 0.0) -> float:
    """Measurement duration at which the ceiling reaches kappa_target."""
    r_need = rho_for_kappa(kappa_target, omega)
    if not np.isfinite(r_need) or r_need >= 1.0:
        return float("inf")
    rho_ref = float(np.clip(rho_ref, 1e-9, 1 - 1e-9))
    k = (r_need * (1.0 - rho_ref)) / (rho_ref * (1.0 - r_need))
    return float(k * T_ref)


def attenuate(rho0: float, dt: float, tau: float) -> float:
    return float(rho0 * np.exp(-dt / tau))


def tau_from_two_intervals(rho_short: float, dt_short: float,
                           rho_long: float, dt_long: float) -> float:
    """Characteristic latent decorrelation time from two observed correlations."""
    if not (0 < rho_long < rho_short):
        return float("inf")
    return float((dt_long - dt_short) / np.log(rho_short / rho_long))


def half_life(tau: float) -> float:
    return float(tau * np.log(2.0)) if np.isfinite(tau) else float("inf")


def ssi(kappa_obs: float, ceiling: float) -> float:
    return float(kappa_obs / ceiling) if ceiling > 0 else np.nan


# ------------------------------------------------------------- Monte-Carlo check
def kappa_mc(rho: float, omega: float, n: int = 400_000, seed: int = 0) -> float:
    """Simulate equation (1)-(3) and return the realised kappa."""
    rng = np.random.default_rng(seed)
    c = rng.choice([-1.0, 1.0], size=n)
    theta = c * np.sqrt(omega * rho) + rng.standard_normal(n) * np.sqrt((1 - omega) * rho)
    s1 = theta + rng.standard_normal(n) * np.sqrt(1 - rho)
    s2 = theta + rng.standard_normal(n) * np.sqrt(1 - rho)
    l1, l2 = s1 > 0, s2 > 0
    po = float((l1 == l2).mean())
    p1, p2 = l1.mean(), l2.mean()
    pe = p1 * p2 + (1 - p1) * (1 - p2)
    return float((po - pe) / (1 - pe))


def kappa_mc_kmeans(rho: float, omega: float, n: int = 20_000, d: int = 1,
                    seed: int = 0, k: int = 2) -> float:
    """End-to-end check: simulate features, re-run k-means at each occasion."""
    from sklearn.cluster import KMeans
    rng = np.random.default_rng(seed)
    c = rng.choice([-1.0, 1.0], size=n)
    theta = c * np.sqrt(omega * rho) + rng.standard_normal(n) * np.sqrt((1 - omega) * rho)
    X1 = (theta + rng.standard_normal(n) * np.sqrt(1 - rho))[:, None]
    X2 = (theta + rng.standard_normal(n) * np.sqrt(1 - rho))[:, None]
    if d > 1:  # pad with pure-noise dimensions
        X1 = np.hstack([X1, rng.standard_normal((n, d - 1))])
        X2 = np.hstack([X2, rng.standard_normal((n, d - 1))])
    l1 = KMeans(k, n_init=10, random_state=0).fit_predict(X1)
    l2 = KMeans(k, n_init=10, random_state=1).fit_predict(X2)
    # align labels (Hungarian on the confusion matrix)
    from scipy.optimize import linear_sum_assignment
    M = np.zeros((k, k))
    for i in range(k):
        for j in range(k):
            M[i, j] = np.sum((l1 == i) & (l2 == j))
    ri, ci = linear_sum_assignment(-M)
    remap = dict(zip(ci, ri))
    l2 = np.array([remap[v] for v in l2])
    return cohen_kappa(l1, l2)


# ------------------------------------------------------------------ estimators
def cohen_kappa(a, b) -> float:
    a, b = np.asarray(a), np.asarray(b)
    labs = np.unique(np.concatenate([a, b]))
    po = float((a == b).mean())
    pe = float(sum((a == l).mean() * (b == l).mean() for l in labs))
    return float((po - pe) / (1 - pe)) if pe < 1 else np.nan


def kappa_ci_bootstrap(a, b, n_boot: int = 10_000, seed: int = 0, alpha: float = 0.05):
    rng = np.random.default_rng(seed)
    a, b = np.asarray(a), np.asarray(b)
    n = a.size
    vals = np.empty(n_boot)
    for i in range(n_boot):
        idx = rng.integers(0, n, n)
        vals[i] = cohen_kappa(a[idx], b[idx])
    vals = vals[np.isfinite(vals)]
    return (float(np.percentile(vals, 100 * alpha / 2)),
            float(np.percentile(vals, 100 * (1 - alpha / 2))))


def icc_consistency(x1, x2) -> float:
    """Two-way mixed single-measure consistency ICC(3,1)."""
    x1, x2 = np.asarray(x1, float), np.asarray(x2, float)
    ok = np.isfinite(x1) & np.isfinite(x2)
    x1, x2 = x1[ok], x2[ok]
    n = x1.size
    if n < 3:
        return np.nan
    Y = np.column_stack([x1, x2])
    grand = Y.mean()
    ms_rows = 2 * ((Y.mean(1) - grand) ** 2).sum() / (n - 1)
    resid = Y - Y.mean(1, keepdims=True) - Y.mean(0, keepdims=True) + grand
    ms_err = (resid ** 2).sum() / (n - 1)
    return float((ms_rows - ms_err) / (ms_rows + ms_err)) if (ms_rows + ms_err) > 0 else np.nan


def pooled_within_group_r(a, b, groups, min_n: int = 8):
    """Fisher-z pooled within-group correlation.

    Between-site differences in noise amplitude are shared by both halves of a
    session and therefore inflate a correlation computed across pooled sites.
    Estimating within site and pooling removes that inflation.
    """
    a, b, groups = np.asarray(a, float), np.asarray(b, float), np.asarray(groups)
    zs, ws, per = [], [], {}
    for g in np.unique(groups):
        m = groups == g
        if m.sum() < min_n:
            continue
        r = float(np.corrcoef(a[m], b[m])[0, 1])
        if not np.isfinite(r):
            continue
        per[str(g)] = {"n": int(m.sum()), "r": r}
        zs.append(np.arctanh(np.clip(r, -0.999999, 0.999999)))
        ws.append(m.sum() - 3)
    if not zs:
        return np.nan, {}
    z = float(np.average(zs, weights=ws))
    return float(np.tanh(z)), per


def fisher_ci(r: float, n: int, alpha: float = 0.05):
    if n < 4 or not np.isfinite(r):
        return (np.nan, np.nan)
    z = np.arctanh(np.clip(r, -0.999999, 0.999999))
    se = 1.0 / np.sqrt(n - 3)
    q = stats.norm.ppf(1 - alpha / 2)
    return (float(np.tanh(z - q * se)), float(np.tanh(z + q * se)))


# ------------------------------------------------------------------ self-check
if __name__ == "__main__":
    print("Table S1  Validation of the stability ceiling against simulation.")
    print("Columns: the closed form of manuscript equation (7); direct Monte-Carlo")
    print("simulation of the measurement model; an end-to-end simulation in which")
    print("k-means is re-run independently at each occasion; and the two limits,")
    print("manuscript equations (8) and (9).")
    print()
    hdr = (f"{'rho':>5} {'omega':>6} {'eq (7)':>8} {'MC':>8} {'k-means':>8} "
           f"{'eq (8)':>8} {'eq (9)':>8}")
    print(hdr)
    for rho in (0.2, 0.4, 0.6, 0.8):
        for omega in (0.0, 0.5, 1.0):
            print(f"{rho:5.2f} {omega:6.2f} {kappa_max(rho, omega):8.4f} "
                  f"{kappa_mc(rho, omega, seed=1):8.4f} "
                  f"{kappa_mc_kmeans(rho, omega, seed=2):8.4f} "
                  f"{float(kappa_max_continuum(rho)):8.4f} "
                  f"{float(kappa_max_categorical(rho)):8.4f}")
    print("\nreliability required for conventional kappa benchmarks (omega = 0 / 1)")
    for k in (0.2, 0.4, 0.6, 0.8):
        print(f"  kappa={k:.1f} -> rho={rho_for_kappa(k, 0.0):.3f} / "
              f"{rho_for_kappa(k, 1.0):.3f}")
