"""Reusable subtyping pipeline, so that every sensitivity analysis re-runs an
identical sequence of steps with one option changed at a time.

Steps: site centring -> nuisance residualisation -> global scaling -> PCA ->
clustering -> one-dimensional subtype score.  A reliability-regularised variant
clusters in the error-whitened subspace instead, and is always evaluated out of
fold so that its reliability cannot be inflated by the fitting step.
"""
from __future__ import annotations

import importlib.util
import os

import numpy as np
import pandas as pd
from scipy import linalg
from sklearn.cluster import AgglomerativeClustering, KMeans, SpectralClustering
from sklearn.decomposition import PCA
from sklearn.mixture import GaussianMixture

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
DATA = os.path.join(ROOT, "data")
RESULTS = os.path.join(ROOT, "results")

_spec = importlib.util.spec_from_file_location("theory", os.path.join(HERE, "03_theory.py"))
th = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(th)

KEYS = ("matched", "conA", "conB", "intA", "intB")
SEED = 20261024


# --------------------------------------------------------------------- loading
def load(atlas: str, T: int):
    tag = f"{atlas}_T{T}"
    meta = pd.read_csv(os.path.join(RESULTS, f"conn_meta_{tag}.csv"))
    ph = pd.read_csv(os.path.join(RESULTS, "phenotype_sessions.csv"))
    meta = meta.merge(ph.drop(columns=["tr"]), on=["subject", "session"], how="left")
    X = {k: np.load(os.path.join(DATA, f"conn_{tag}_{k}.npy")).astype(np.float32)
         for k in KEYS}
    return meta.reset_index(drop=True), X


def site_center(X: dict, meta: pd.DataFrame):
    """Centre each edge within site on that site's baseline-wave mean.

    Centring is a per-site constant, so it cannot create or remove
    within-subject change between waves.
    """
    out = {k: v.copy() for k, v in X.items()}
    for _site, idx in meta.groupby("site_scanner").groups.items():
        idx = np.asarray(list(idx))
        base = idx[meta.loc[idx, "wave"].values == 1]
        ref = base if base.size >= 3 else idx
        for k in out:
            out[k][idx] -= out[k][ref].mean(0, keepdims=True)
    return out


def regress_out(X: dict, meta: pd.DataFrame, cols, fit_idx):
    """Residualise edges on nuisance variables, with coefficients fitted on
    fit_idx (the discovery sample) and applied everywhere."""
    if not cols:
        return X
    C = []
    for c in cols:
        v = pd.to_numeric(meta[c], errors="coerce").values.astype(float)
        mu = np.nanmean(v[np.isfinite(v)]) if np.isfinite(v).any() else 0.0
        v = np.where(np.isfinite(v), v, mu)
        s = v.std() if v.std() > 0 else 1.0
        C.append((v - v.mean()) / s)
    D = np.column_stack([np.ones(len(meta))] + C)
    out = {}
    for k, v in X.items():
        beta, *_ = np.linalg.lstsq(D[fit_idx], v[fit_idx], rcond=None)
        out[k] = (v - D @ beta).astype(np.float32)
    return out


# ------------------------------------------------------------------ clustering
def cluster(Z, k, algo, seed=SEED):
    if algo == "kmeans":
        m = KMeans(k, n_init=50, random_state=seed).fit(Z)
        return m.labels_, m.cluster_centers_
    if algo == "ward":
        lab = AgglomerativeClustering(k, linkage="ward").fit_predict(Z)
    elif algo == "gmm":
        lab = GaussianMixture(k, covariance_type="diag", n_init=10, reg_covar=1e-3,
                              random_state=seed).fit_predict(Z)
    elif algo == "spectral":
        lab = SpectralClustering(k, affinity="nearest_neighbors", n_neighbors=15,
                                 random_state=seed, assign_labels="kmeans").fit_predict(Z)
    else:
        raise ValueError(algo)
    cen = np.vstack([Z[lab == c].mean(0) for c in range(k)])
    return lab, cen


def axis_score(Z, cen):
    """Projection on the centroid-difference axis (the 2-means decision axis)."""
    w = cen[1] - cen[0]
    w = w / np.linalg.norm(w)
    mid = (cen[0] + cen[1]) / 2.0
    return (Z - mid) @ w, w


def nearest_centroid(Z, cen):
    return np.argmin(((Z[:, None, :] - cen[None]) ** 2).sum(-1), axis=1)


# ------------------------------------------------------- error-whitened space
def error_cov(Za, Zb, ridge=0.05):
    """Full-length measurement-error covariance from split halves.

    Half-length estimates carry twice the error variance of full-length ones, so
    Cov(A - B) = 2 * Sigma_e^half = 4 * Sigma_e^full.
    """
    S = np.cov(Za - Zb, rowvar=False) / 4.0
    p = S.shape[0]
    return (1 - ridge) * S + ridge * np.trace(S) / p * np.eye(p)


def whiten_matrix(Sigma_e):
    vals, vecs = linalg.eigh(Sigma_e)
    vals = np.maximum(vals, 1e-10)
    return vecs @ np.diag(vals ** -0.5) @ vecs.T


# ---------------------------------------------------------------------- driver
def fit_model(atlas="Gordon2014FreeSurferSubcortical", T=150, k=2, n_pc=50,
              algo="kmeans", nuisance=("mean_fd",), seed=SEED,
              dx_discovery="ASD", split_type="con"):
    """Fit on the cross-sectional discovery sample; score every session."""
    meta, X = load(atlas, T)
    X = site_center(X, meta)
    disc = np.where((meta.dx == dx_discovery) &
                    (meta.collection == "cross-sectional"))[0]
    X = regress_out(X, meta, list(nuisance), disc)
    sd = X["matched"][disc].std(0)
    sd[sd == 0] = 1.0
    S = {kk: (v / sd).astype(np.float32) for kk, v in X.items()}
    pca = PCA(n_components=n_pc, random_state=seed).fit(S["matched"][disc])
    Z = {kk: pca.transform(v) for kk, v in S.items()}
    A, B = (f"{split_type}A", f"{split_type}B")

    lab, cen = cluster(Z["matched"][disc], k, algo, seed)
    mean_fc = X["matched"].mean(1)
    res = dict(meta=meta, disc=disc, Z=Z, pca=pca, cen=cen, mean_fc=mean_fc,
               k=k, T=T, atlas=atlas, algo=algo, n_pc=n_pc,
               pca_evr=float(pca.explained_variance_ratio_.sum()),
               split_type=split_type, nuisance=tuple(nuisance))

    if k == 2:
        if mean_fc[disc][lab == 0].mean() > mean_fc[disc][lab == 1].mean():
            cen, lab = cen[::-1], 1 - lab
        res["cen"] = cen
        res["disc_labels"] = lab
        s = {kk: axis_score(Z[kk], cen)[0] for kk in Z}
        mu, sg = s["matched"][disc].mean(), s["matched"][disc].std()
        s = {kk: (v - mu) / sg for kk, v in s.items()}
        res["score"] = s
        res["labels"] = {kk: (v > 0).astype(int) for kk, v in s.items()}
        res["prevalence"] = float(min(np.mean(res["labels"]["matched"][disc]),
                                      1 - np.mean(res["labels"]["matched"][disc])))
        res["r_half_pooled_sites"] = float(np.corrcoef(s[A][disc], s[B][disc])[0, 1])
        ws, per = th.pooled_within_group_r(s[A][disc], s[B][disc],
                                           meta.site_scanner.values[disc])
        res["r_half"] = float(ws) if np.isfinite(ws) else res["r_half_pooled_sites"]
        res["r_half_by_site"] = per
        res["rho_full"] = th.spearman_brown(res["r_half"], 2.0)

        # ---- reliability-regularised variant, cross-fitted within discovery
        rng = np.random.default_rng(seed)
        perm = rng.permutation(disc)
        folds = [perm[: perm.size // 2], perm[perm.size // 2:]]
        s_rr_oof = np.full((len(meta), 3), np.nan)   # matched, A, B (out of fold)
        for f_fit, f_eval in ((folds[0], folds[1]), (folds[1], folds[0])):
            W = whiten_matrix(error_cov(Z[A][f_fit], Z[B][f_fit]))
            Zw = {kk: Z[kk] @ W for kk in Z}
            l2, c2 = cluster(Zw["matched"][f_fit], 2, algo, seed)
            if mean_fc[f_fit][l2 == 0].mean() > mean_fc[f_fit][l2 == 1].mean():
                c2 = c2[::-1]
            sm = axis_score(Zw["matched"], c2)[0]
            sa = axis_score(Zw[A], c2)[0]
            sb = axis_score(Zw[B], c2)[0]
            mu2, sg2 = sm[f_fit].mean(), sm[f_fit].std()
            s_rr_oof[f_eval, 0] = (sm[f_eval] - mu2) / sg2
            s_rr_oof[f_eval, 1] = (sa[f_eval] - mu2) / sg2
            s_rr_oof[f_eval, 2] = (sb[f_eval] - mu2) / sg2
        ws_rr, _ = th.pooled_within_group_r(s_rr_oof[disc, 1], s_rr_oof[disc, 2],
                                            meta.site_scanner.values[disc])
        res["r_half_rr"] = float(ws_rr) if np.isfinite(ws_rr) else float(
            np.corrcoef(s_rr_oof[disc, 1], s_rr_oof[disc, 2])[0, 1])
        res["rho_full_rr"] = th.spearman_brown(res["r_half_rr"], 2.0)
        res["score_rr_oof"] = s_rr_oof

        # model trained on the whole discovery set, for the held-out longitudinal data
        W = whiten_matrix(error_cov(Z[A][disc], Z[B][disc]))
        Zw = {kk: Z[kk] @ W for kk in Z}
        l2, c2 = cluster(Zw["matched"][disc], 2, algo, seed)
        if mean_fc[disc][l2 == 0].mean() > mean_fc[disc][l2 == 1].mean():
            c2 = c2[::-1]
        s2 = {kk: axis_score(Zw[kk], c2)[0] for kk in Zw}
        mu2, sg2 = s2["matched"][disc].mean(), s2["matched"][disc].std()
        res["score_rr"] = {kk: (v - mu2) / sg2 for kk, v in s2.items()}
        res["labels_rr"] = {kk: (v > 0).astype(int) for kk, v in res["score_rr"].items()}
        res["whitener"] = W
        res["cen_rr"] = c2
    else:
        res["labels"] = {kk: nearest_centroid(Z[kk], cen) for kk in Z}
        res["score"] = res["score_rr"] = res["labels_rr"] = None
        res["prevalence"] = float(np.min(np.bincount(res["labels"]["matched"][disc],
                                                     minlength=k)) / disc.size)
        res["r_half"] = res["rho_full"] = np.nan
        res["r_half_rr"] = res["rho_full_rr"] = np.nan
    return res


def longitudinal_pairs(meta: pd.DataFrame, min_interval=0.5):
    """Subjects with two usable sessions and a non-trivial inter-scan interval."""
    rows = []
    for sub, d in meta.groupby("subject"):
        if d.session.nunique() < 2 or len(d) != 2:
            continue
        d = d.sort_values("wave")
        a, b = d.iloc[0], d.iloc[1]
        dt = float(b.age) - float(a.age)
        if not np.isfinite(dt) or dt < min_interval:
            continue
        rows.append(dict(subject=sub, i1=int(a.name), i2=int(b.name),
                         age1=float(a.age), age2=float(b.age), interval=dt,
                         dx=a.dx, sex=a.sex, site=a.site_scanner,
                         fd1=float(a.mean_fd), fd2=float(b.mean_fd),
                         keep1=float(a.keep_s), keep2=float(b.keep_s)))
    return pd.DataFrame(rows)


def ceiling_set(rho: float, prevalence: float, omega: float) -> dict:
    """All ceiling variants for a measured reliability and subtype prevalence."""
    return {
        "kappa_max_balanced_continuum": float(th.kappa_max_continuum(rho)),
        "kappa_max_balanced_categorical": float(th.kappa_max_categorical(rho)),
        "kappa_max_balanced_omega": th.kappa_max(rho, omega),
        "kappa_max_prevalence_continuum": th.kappa_max_unbalanced(rho, prevalence, 0.0),
        "kappa_max_prevalence_omega": th.kappa_max_unbalanced(rho, prevalence, omega),
    }
