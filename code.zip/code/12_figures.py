"""Step 12 - manuscript figures.

Vector PDF plus 600-dpi PNG for every panel group.  The categorical palette is
the Okabe-Ito colour-blind-safe set, ordered so that every adjacent pair clears
the CVD separation threshold; identity is additionally carried by marker shape
and line style, so no panel depends on colour alone, and all panels remain
legible in greyscale.
"""
from __future__ import annotations

import importlib.util
import json
import os
import sys

import matplotlib as mpl
import numpy as np
import pandas as pd

mpl.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
from matplotlib.lines import Line2D  # noqa: E402

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import pipeline as P  # noqa: E402

_spec = importlib.util.spec_from_file_location("theory", os.path.join(HERE, "03_theory.py"))
th = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(th)

ROOT = os.path.dirname(HERE)
DATA = os.path.join(ROOT, "data")
RESULTS = os.path.join(ROOT, "results")
FIG = os.path.join(ROOT, "figures")
os.makedirs(FIG, exist_ok=True)

BLUE, VERM, GREEN, SKY, PURPLE = "#0072B2", "#D55E00", "#009E73", "#56B4E9", "#CC79A7"
INK, MUTED, GRID = "#1a1a1a", "#595959", "#d9d9d9"

mpl.rcParams.update({
    "figure.dpi": 150, "savefig.dpi": 600, "savefig.bbox": "tight",
    "font.family": "sans-serif", "font.sans-serif": ["DejaVu Sans"],
    "font.size": 7, "axes.labelsize": 7.5, "axes.titlesize": 8,
    "xtick.labelsize": 6.5, "ytick.labelsize": 6.5, "legend.fontsize": 6.5,
    "axes.edgecolor": MUTED, "axes.linewidth": 0.6, "axes.labelcolor": INK,
    "text.color": INK, "xtick.color": MUTED, "ytick.color": MUTED,
    "xtick.major.width": 0.6, "ytick.major.width": 0.6,
    "xtick.major.size": 2.5, "ytick.major.size": 2.5,
    "grid.color": GRID, "grid.linewidth": 0.5, "axes.grid": False,
    "legend.frameon": False, "lines.linewidth": 1.4, "lines.markersize": 4,
    "pdf.fonttype": 42, "ps.fonttype": 42,
})


def panel(ax, letter, dx=-0.17, dy=1.06):
    ax.text(dx, dy, letter, transform=ax.transAxes, fontsize=9,
            fontweight="bold", va="top", ha="left")


def save(fig, name):
    for ext in ("pdf", "png"):
        fig.savefig(os.path.join(FIG, f"{name}.{ext}"))
    plt.close(fig)
    print(f"  wrote figures/{name}.pdf / .png", flush=True)


def load_all():
    j = {}
    for k, f in (("s6", "06_subtyping.json"), ("s7", "07_longitudinal.json"),
                 ("s8", "08_design.json"), ("s10", "10_identifiability.json"),
                 ("s11", "11_abide1_replication.json")):
        p = os.path.join(RESULTS, f)
        j[k] = json.load(open(p)) if os.path.exists(p) else {}
    return j


# ----------------------------------------------------------------- figure 1
def figure1(j):
    fig, axes = plt.subplots(1, 3, figsize=(7.2, 2.4))
    rho = np.linspace(0, 0.999, 400)

    ax = axes[0]
    for i, (om, c, ls, lab) in enumerate([
            (0.0, BLUE, "-", r"$\omega=0$ (continuum)"),
            (0.5, GREEN, "--", r"$\omega=0.5$"),
            (1.0, VERM, "-.", r"$\omega=1$ (dichotomy)")]):
        y = [th.kappa_max(r, om) for r in rho]
        ax.plot(rho, y, color=c, ls=ls, label=lab)
    for lo, hi, lbl in ((0.0, 0.2, "slight"), (0.2, 0.4, "fair"),
                        (0.4, 0.6, "moderate"), (0.6, 0.8, "substantial")):
        ax.axhspan(lo, hi, color=GRID, alpha=0.22 if lbl in ("fair", "substantial") else 0.10,
                   lw=0)
        ax.text(0.015, (lo + hi) / 2, lbl, fontsize=5.6, color=MUTED, va="center")
    r_edge = j["s6"]["edge_reliability"]["median_rho_full_sb"]
    r_score = j["s7"]["primary"]["rho_within_site_pooled_full"]
    for x, c, lab in ((r_edge, MUTED, f"single edge, $\\rho$={r_edge:.2f}"),
                      (r_score, PURPLE, f"subtype score, $\\rho$={r_score:.2f}")):
        ax.axvline(x, color=c, ls=":", lw=0.9)
        ax.text(x - 0.020, 0.57, lab, fontsize=5.8, color=c, va="top",
                ha="right", rotation=90)
    ax.set_xlabel(r"reliability of the subtype score, $\rho$")
    ax.set_ylabel(r"maximum attainable agreement, $\kappa_{\max}$")
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)
    ax.legend(loc="upper left", bbox_to_anchor=(0.0, 1.0))
    panel(ax, "a")

    ax = axes[1]
    pts = []
    for om, c, mk in ((0.0, BLUE, "o"), (0.5, GREEN, "s"), (1.0, VERM, "^")):
        xs = [th.kappa_max(r, om) for r in (0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9)]
        ys = [th.kappa_mc(r, om, n=200000, seed=3) for r in
              (0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9)]
        ax.plot(xs, ys, mk, color=c, mfc="none", mew=1.0,
                label=rf"$\omega={om}$", ls="none")
        pts += list(zip(xs, ys))
    ax.plot([0, 1], [0, 1], color=MUTED, lw=0.7, ls="-", zorder=0)
    err = max(abs(a - b) for a, b in pts)
    ax.text(0.04, 0.93, f"max |closed form $-$ simulation|\n= {err:.4f}",
            fontsize=6, va="top")
    ax.set_xlabel(r"closed form, equation (7)")
    ax.set_ylabel(r"Monte-Carlo simulation")
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)
    ax.legend(loc="lower right")
    panel(ax, "b")

    ax = axes[2]
    g = pd.read_csv(os.path.join(RESULTS, "ceiling_by_duration.csv"))
    ax.plot(g.minutes, g.kappa_continuum, color=BLUE, label=r"$\omega=0$")
    ax.plot(g.minutes, g.kappa_categorical, color=VERM, ls="-.", label=r"$\omega=1$")
    ax.fill_between(g.minutes, g.kappa_continuum, g.kappa_categorical,
                    color=GRID, alpha=0.4, lw=0)
    for y, lab in ((0.4, "moderate"), (0.6, "substantial")):
        ax.axhline(y, color=MUTED, lw=0.6, ls=":")
        ax.text(58, y + 0.012, lab, fontsize=5.8, color=MUTED, ha="right")
    ax.axvline(2.5, color=PURPLE, lw=0.9, ls=":")
    ax.text(2.8, 0.05, "data analysed here\n(2.5 min retained)", fontsize=5.8,
            color=PURPLE)
    ax.set_xlabel("retained resting-state data per session (min)")
    ax.set_ylabel(r"$\kappa_{\max}$")
    ax.set_xlim(0, 60)
    ax.set_ylim(0, 1)
    ax.legend(loc="lower right")
    panel(ax, "c")

    fig.tight_layout(w_pad=1.8)
    save(fig, "figure1_stability_ceiling")


# ----------------------------------------------------------------- figure 2
def figure2(j):
    fig = plt.figure(figsize=(7.2, 4.6))
    gs = fig.add_gridspec(2, 3, hspace=0.72, wspace=0.95)

    ax = fig.add_subplot(gs[0, 0])
    cs = pd.read_csv(os.path.join(RESULTS, "cluster_selection.csv"))
    ax.plot(cs.k, cs.resample_ari, "o-", color=BLUE, label="resampling ARI")
    ax.plot(cs.k, cs.pac, "s--", color=VERM, label="ambiguous clustering")
    ax.plot(cs.k, cs.silhouette * 5, "^-.", color=GREEN,
            label=r"silhouette $\times$ 5")
    ax.set_xlabel("number of subtypes, $k$")
    ax.set_ylabel("index")
    ax.set_xticks(list(cs.k))
    ax.set_ylim(-0.05, 0.92)
    ax.legend(loc="lower left", fontsize=6)
    panel(ax, "a")

    ax = fig.add_subplot(gs[0, 1])
    sc = pd.read_csv(os.path.join(RESULTS, "subtype_scores.csv"))
    d = sc[sc.in_discovery]
    ax.hist(d.score, bins=32, color=SKY, edgecolor="white", linewidth=0.4)
    bi = j["s6"]["bimodality_out_of_sample"]
    ax.axvline(0, color=INK, lw=0.9, ls="--")
    ax.text(0.03, 0.97, f"out-of-sample dip test\n$P$ = {bi['dip_p']:.2f}\n"
                        f"$\\Delta$BIC = {bi['delta_bic_2minus1']:+.1f}",
            transform=ax.transAxes, fontsize=6, va="top")
    ax.set_xlabel("subtype score (SD units)")
    ax.set_ylabel("sessions")
    panel(ax, "b")

    ax = fig.add_subplot(gs[0, 2])
    er = np.load(os.path.join(DATA, "edge_halfhalf_r.npy"))
    rho_e = np.clip(2 * er / (1 + er), -1, 1)
    ax.hist(rho_e[np.isfinite(rho_e)], bins=60, color=GRID,
            edgecolor=MUTED, linewidth=0.3)
    med = j["s6"]["edge_reliability"]["median_rho_full_sb"]
    ax.axvline(med, color=BLUE, lw=1.1)
    ax.axvline(0.29, color=VERM, lw=1.1, ls="--")
    ax.text(0.97, 0.97, f"this study, median\n$\\rho$ = {med:.2f}", color=BLUE,
            transform=ax.transAxes, fontsize=6, va="top", ha="right")
    ax.text(0.03, 0.97, "meta-analytic\nICC = 0.29", color=VERM,
            transform=ax.transAxes, fontsize=6, va="top", ha="left")
    ax.set_xlabel(r"edge reliability, $\rho$")
    ax.set_ylabel("edges")
    ax.set_xlim(-0.5, 1)
    ax.set_ylim(0, ax.get_ylim()[1] * 1.3)
    panel(ax, "c")

    ax = fig.add_subplot(gs[1, :2])
    nd = pd.read_csv(os.path.join(RESULTS, "discriminant_by_network.csv"))
    nets = sorted(set(nd.net_a) | set(nd.net_b))
    Mx = np.full((len(nets), len(nets)), np.nan)
    for _, r in nd.iterrows():
        i, k2 = nets.index(r.net_a), nets.index(r.net_b)
        Mx[i, k2] = Mx[k2, i] = r.mean_abs_weight
    im = ax.imshow(Mx, cmap="Blues", interpolation="nearest")
    ax.set_xticks(range(len(nets)))
    ax.set_xticklabels(nets, rotation=90, fontsize=4.6)
    ax.set_yticks(range(len(nets)))
    ax.set_yticklabels(nets, fontsize=4.6)
    cb = fig.colorbar(im, ax=ax, fraction=0.030, pad=0.03)
    cb.set_label("mean |discriminant weight|", fontsize=6)
    cb.ax.tick_params(labelsize=5.5)
    panel(ax, "d", dx=-0.12)

    ax = fig.add_subplot(gs[1, 2])
    sd = pd.read_csv(os.path.join(RESULTS, "sensitivity_duration.csv")).dropna(subset=["rho_full"])
    T0 = 150.0
    rho0 = float(sd.loc[sd["T"] == T0, "rho_full"].iloc[0])
    tt = np.linspace(60, 300, 100)
    ax.plot(tt / 60, [th.rho_from_duration(rho0, t, T0) for t in tt],
            color=MUTED, lw=0.9, label="Spearman-Brown")
    ax.plot(sd["T"] / 60, sd.rho_full, "o", color=BLUE, label="observed")
    ax.set_xlabel("matched duration (min)")
    ax.set_ylabel(r"score reliability, $\rho$")
    ax.set_ylim(0.5, 0.9)
    ax.legend(loc="lower right")
    panel(ax, "e", dx=-0.30)

    save(fig, "figure2_subtypes_and_reliability")


# ----------------------------------------------------------------- figure 3
def figure3(j):
    fig, axes = plt.subplots(1, 2, figsize=(7.2, 2.9),
                             gridspec_kw={"width_ratios": [1.35, 1]})
    rows = []
    t6 = j["s6"]["within_session_ceiling_test"]
    rows.append(("ABIDE II, Gordon, contiguous halves", t6["contiguous"]))
    rows.append(("ABIDE II, Gordon, interleaved halves", t6["interleaved"]))
    for strat, rec in j.get("s11", {}).items():
        nm = ("ABIDE I, CC200, no GSR" if strat == "filt_noglobal"
              else "ABIDE I, CC200, with GSR")
        rows.append((nm, {"kappa_observed": rec["kappa_within_session"],
                          "kappa_ci": rec["kappa_ci"],
                          "kappa_max_continuum": rec["kappa_max_continuum"],
                          "kappa_max_categorical": rec["kappa_max_categorical"]}))
    ax = axes[0]
    for i, (nm, r) in enumerate(rows):
        y = len(rows) - 1 - i
        ax.plot([r["kappa_max_continuum"], r["kappa_max_categorical"]], [y, y],
                color=GRID, lw=6, solid_capstyle="butt", zorder=0)
        ax.plot(r["kappa_max_continuum"], y, "|", color=BLUE, ms=11, mew=1.6)
        ax.plot(r["kappa_max_categorical"], y, "|", color=VERM, ms=11, mew=1.6)
        ax.plot([r["kappa_ci"][0], r["kappa_ci"][1]], [y, y], color=INK, lw=1.1)
        ax.plot(r["kappa_observed"], y, "o", color=INK, ms=5)
        ax.text(0.015, y + 0.28, nm, fontsize=6.2, va="bottom")
    ax.set_yticks([])
    ax.set_ylim(-1.35, len(rows) - 0.2)
    ax.set_xlim(0, 0.85)
    ax.set_xlabel(r"within-session label agreement, $\kappa$")
    ax.legend(handles=[
        Line2D([], [], color=INK, marker="o", ls="-", label="observed (95% CI)"),
        Line2D([], [], color=BLUE, marker="|", ls="none", ms=10, mew=1.6,
               label=r"predicted, $\omega=0$"),
        Line2D([], [], color=VERM, marker="|", ls="none", ms=10, mew=1.6,
               label=r"predicted, $\omega=1$")],
        loc="lower right", fontsize=6)
    panel(ax, "a", dx=-0.06)

    ax = axes[1]
    at = pd.read_csv(os.path.join(RESULTS, "sensitivity_atlas.csv"))
    names = {"Gordon2014FreeSurferSubcortical": "Gordon\n(352)",
             "HCP2016FreeSurferSubcortical": "Glasser\n(379)",
             "Power2011FreeSurferSubcortical": "Power\n(94)",
             "Markov2012FreeSurferSubcortical": "M132\n(205)"}
    x = np.arange(len(at))
    ax.bar(x - 0.19, at.rho_full, width=0.36, color=BLUE, label=r"score $\rho$")
    ax.bar(x + 0.19, at.ceiling, width=0.36, color=GRID, edgecolor=MUTED,
           linewidth=0.4, label=r"$\kappa_{\max}$ at 1.8 y")
    ax.plot(x + 0.19, at.kappa, "D", color=VERM, ms=4.5,
            label=r"observed $\kappa$ at 1.8 y")
    ax.set_xticks(x)
    ax.set_xticklabels([names.get(a, a) for a in at.atlas], fontsize=6)
    ax.set_ylabel("value")
    ax.set_ylim(0, 0.9)
    ax.legend(loc="upper right", fontsize=6)
    panel(ax, "b", dx=-0.14)

    fig.tight_layout(w_pad=2.0)
    save(fig, "figure3_ceiling_validation")


# ----------------------------------------------------------------- figure 4
def figure4(j):
    fig = plt.figure(figsize=(7.2, 4.6))
    gs = fig.add_gridspec(2, 3, hspace=0.5, wspace=0.42)
    lp = pd.read_csv(os.path.join(RESULTS, "longitudinal_pairs.csv"))

    ax = fig.add_subplot(gs[0, 0])
    for _, r in lp.iterrows():
        c = VERM if r.dx == "ASD" else BLUE
        ls = "-" if r.switched == 0 else "--"
        ax.plot([0, 1], [r.score1, r.score2], color=c, ls=ls, lw=1.0, alpha=0.85,
                marker="o", ms=3.2, mfc="white" if r.switched else c, mew=0.9)
    ax.axhline(0, color=INK, lw=0.8, ls=":")
    ax.set_xticks([0, 1])
    ax.set_xticklabels(["wave 1", "wave 2"])
    ax.set_xlim(-0.2, 1.2)
    ax.set_ylabel("subtype score (SD units)")
    ax.legend(handles=[Line2D([], [], color=VERM, label="autistic"),
                       Line2D([], [], color=BLUE, label="non-autistic"),
                       Line2D([], [], color=MUTED, ls="--", marker="o",
                              mfc="white", label="label switched")],
              loc="upper center", bbox_to_anchor=(0.5, -0.13), ncol=1,
              fontsize=5.8)
    panel(ax, "a")

    ax = fig.add_subplot(gs[0, 1])
    sd = pd.read_csv(os.path.join(RESULTS, "sensitivity_duration.csv")).dropna(subset=["kappa"])
    ax.plot(sd["T"] / 60, sd.ceiling, "s--", color=GRID, mec=MUTED,
            label=r"$\kappa_{\max}$")
    ax.plot(sd["T"] / 60, sd.kappa, "o-", color=VERM, label=r"observed $\kappa$")
    ax.plot(sd["T"] / 60, sd.r_long, "^-.", color=BLUE, label=r"score $r$")
    ax.set_ylim(-0.45, 0.95)
    for _, r in sd.iterrows():
        ax.annotate(f"n={int(r.n_pairs)}", (r["T"] / 60, 0.82), fontsize=5.4,
                    ha="center", color=MUTED)
    ax.axhline(0, color=INK, lw=0.7, ls=":")
    ax.set_xlabel("matched duration (min)")
    ax.set_ylabel("value at 1.8 y")
    ax.legend(loc="lower right", fontsize=5.8, ncol=1)
    panel(ax, "b")

    ax = fig.add_subplot(gs[0, 2])
    s10 = j["s10"]["T150"]
    vals = [s10["self_similarity_within_session"]["mean"],
            s10["self_similarity_between_waves"]["mean"],
            s10["between_subject_similarity"]["mean"]]
    errs = [s10["self_similarity_within_session"]["sd"],
            s10["self_similarity_between_waves"]["sd"],
            s10["between_subject_similarity"]["sd"]]
    ax.bar(range(3), vals, yerr=errs, capsize=2.5, width=0.6,
           color=[GREEN, BLUE, GRID], edgecolor=MUTED, linewidth=0.4,
           error_kw={"elinewidth": 0.7, "ecolor": MUTED})
    ax.axhline(0, color=INK, lw=0.7)
    ax.set_xticks(range(3))
    ax.set_xticklabels(["same scan\n(halves)", "same person\n1.8 y apart",
                        "different\npeople"], fontsize=6)
    ax.set_ylabel("connectome similarity, $r$")
    panel(ax, "c")

    ax = fig.add_subplot(gs[1, 0])
    idf = pd.read_csv(os.path.join(RESULTS, "identifiability.csv"))
    x = np.arange(len(idf))
    ax.bar(x - 0.19, idf.identification_accuracy_within_session, width=0.36,
           color=GREEN, label="within session")
    ax.bar(x + 0.19, idf.identification_accuracy_w1_to_w2, width=0.36,
           color=BLUE, label="across 1.8 y")
    ax.plot(x, idf.chance_accuracy, "_", color=VERM, ms=16, mew=1.6, label="chance")
    ax.set_xticks(x)
    ax.set_xticklabels([f"{int(t)} s\n(n={int(n)})" for t, n in
                        zip(idf["T"], idf.n_pairs)], fontsize=6)
    ax.set_ylabel("identification accuracy")
    ax.set_ylim(0, 1.05)
    ax.legend(loc="upper center", bbox_to_anchor=(0.5, 1.26), ncol=3,
              fontsize=5.6, columnspacing=0.8, handlelength=1.2)
    panel(ax, "d")

    ax = fig.add_subplot(gs[1, 1])
    p = j["s7"]["primary"]
    rho_grid = np.linspace(0.45, 0.95, 60)
    dt = p["interval_mean_y"]
    r_obs = p["r_score_between_waves"]
    taus = [(dt / np.log(r / r_obs)) if r > r_obs else np.nan for r in rho_grid]
    hl = [th.half_life(t) if np.isfinite(t) else np.nan for t in taus]
    ax.plot(rho_grid, hl, color=BLUE)
    rho_hat = p["rho_within_site_pooled_full"]
    hl_hat = th.half_life(dt / np.log(rho_hat / r_obs))
    ax.plot([rho_hat], [hl_hat], "o", color=VERM, ms=5)
    ax.annotate(f"{hl_hat:.0f} y", (rho_hat, hl_hat), xytext=(5, 5),
                textcoords="offset points", fontsize=6.5, color=VERM)
    ax.set_xlabel(r"assumed zero-interval reliability, $\rho_0$")
    ax.set_ylabel("half-life of subtype identity (y)")
    ax.set_yscale("log")
    ax.set_yticks([1, 2, 3, 5, 10, 20])
    ax.get_yaxis().set_major_formatter(mpl.ticker.ScalarFormatter())
    ax.get_yaxis().set_minor_formatter(mpl.ticker.NullFormatter())
    panel(ax, "e")

    ax = fig.add_subplot(gs[1, 2])
    sn = pd.read_csv(os.path.join(RESULTS, "longitudinal_reliability_sensitivity.csv"))
    row = sn.iloc[0]
    tn = {"kappa_null_ci95": [row.kappa_null_ci_low, row.kappa_null_ci_high],
          "kappa_null_mean": row.kappa_max_continuum,
          "p_kappa_below_null": row.p_kappa_below_trait_null}
    lo, hi = tn["kappa_null_ci95"]
    ax.axvspan(lo, hi, color=GRID, alpha=0.6, lw=0)
    ax.axvline(tn["kappa_null_mean"], color=MUTED, lw=1.0, ls="--")
    ax.axvline(p["kappa_between_waves"], color=VERM, lw=1.4)
    ax.text(tn["kappa_null_mean"], 0.92, " expected under\n a stable trait",
            fontsize=6, color=MUTED, va="top")
    ax.text(p["kappa_between_waves"], 0.35, " observed\n at 1.8 y",
            fontsize=6, color=VERM, va="top")
    ax.set_xlabel(r"$\kappa$ between waves")
    ax.set_yticks([])
    ax.set_xlim(-0.6, 1)
    ax.text(0.02, 0.06, f"$P$ = {tn['p_kappa_below_null']:.2f} (n = {p['n_pairs']})",
            transform=ax.transAxes, fontsize=6.2)
    panel(ax, "f")

    save(fig, "figure4_longitudinal_stability")


# ----------------------------------------------------------------- figure 5
def figure5(j):
    fig, axes = plt.subplots(1, 3, figsize=(7.2, 2.4))

    ax = axes[0]
    dr = pd.read_csv(os.path.join(RESULTS, "duration_requirements.csv"))
    dr = dr[dr.omega_assumption.isin(["continuum", "categorical"])]
    ks = sorted(dr.kappa_target.unique())
    x = np.arange(len(ks))
    for i, (om, c) in enumerate((("continuum", BLUE), ("categorical", VERM))):
        v = [dr[(dr.kappa_target == k) & (dr.omega_assumption == om)]
             .retained_minutes.iloc[0] for k in ks]
        v = [min(vv, 1e4) for vv in v]
        ax.bar(x + (i - 0.5) * 0.36, v, width=0.36, color=c,
               label=r"$\omega=0$" if om == "continuum" else r"$\omega=1$")
        for xx, vv in zip(x + (i - 0.5) * 0.36, v):
            ax.text(xx, vv * 1.12, f"{vv:.0f}", fontsize=5.6, ha="center",
                    color=MUTED)
    ax.set_yscale("log")
    ax.set_ylim(top=ax.get_ylim()[1] * 2.2)
    ax.set_xticks(x)
    ax.set_xticklabels([f"{k:.1f}" for k in ks])
    ax.set_xlabel(r"target agreement, $\kappa$")
    ax.set_ylabel("retained data required (min)")
    ax.legend(loc="upper left", fontsize=6)
    panel(ax, "a")

    ax = axes[1]
    pw = pd.read_csv(os.path.join(RESULTS, "power_curves.csv"))
    for (tau, g), c, mk in zip(pw.groupby("tau_alt"),
                               [VERM, BLUE, GREEN, PURPLE], ["o", "s", "^", "D"]):
        ax.plot(g.n, g.power, marker=mk, color=c, ms=3.5,
                label=rf"$\tau$ = {tau:.0f} y")
    ax.axhline(0.8, color=MUTED, ls=":", lw=0.8)
    ax.text(11, 0.82, "80% power", fontsize=5.8, color=MUTED)
    ax.set_xscale("log")
    ax.set_xlabel("participants with two scans")
    ax.set_ylabel("power to detect reconfiguration")
    ax.set_ylim(0, 1.02)
    ax.legend(loc="lower right", fontsize=6)
    panel(ax, "b")

    ax = axes[2]
    p = j["s7"]["primary"]
    s10 = j["s10"]["T150"]
    labels = ["categorical\nlabel\n(1 bit)", "continuous\nscore", "whole\nconnectome"]
    vals = [max(p["kappa_between_waves"], 0.0), max(p["r_score_between_waves"], 0.0),
            s10["identification_accuracy_w1_to_w2"]]
    cols = [VERM, PURPLE, GREEN]
    ax.bar(range(3), vals, width=0.6, color=cols, edgecolor=MUTED, linewidth=0.4)
    for i, v in enumerate(vals):
        ax.text(i, v + 0.025, f"{v:.2f}", ha="center", fontsize=6.5)
    ax.set_xticks(range(3))
    ax.set_xticklabels(labels, fontsize=6)
    ax.set_ylabel("individual information retained\nacross 1.8 y")
    ax.set_ylim(0, 1.05)
    ax.text(0.5, 0.95, "same participants,\nsame scans", transform=ax.transAxes,
            fontsize=6, ha="center", va="top", color=MUTED)
    panel(ax, "c")

    fig.tight_layout(w_pad=1.8)
    save(fig, "figure5_design_implications")


def main():
    j = load_all()
    figure1(j)
    figure2(j)
    figure3(j)
    figure4(j)
    figure5(j)


if __name__ == "__main__":
    main()
