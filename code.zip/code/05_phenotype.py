"""Step 5 - attach open phenotypic data to every retained session.

Sources (all public, no data-use agreement):
  * ABIDEII_Composite_Phenotypic.csv       - cross-sectional ABIDE II sites
  * ABIDEII_Long_Composite_Phenotypic.csv  - the two longitudinal collections
    (UPSM_Long and UCLA_Long), whose baseline scans were released in ABIDE I

DCAN session labels encode the collection and wave, which is what identifies the
correct phenotypic row (e.g. ``ses-UPSMLongfollowup1`` -> SESSION ``Followup_1``
of SITE_ID ``ABIDEII-UPSM_Long``).
"""
from __future__ import annotations

import os
import re

import numpy as np
import pandas as pd

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RESULTS = os.path.join(ROOT, "results")
PHENO = os.path.join(ROOT, "data", "pheno")

SESSION_TO_SITE = {
    "ses-BNI1baseline": "ABIDEII-BNI_1",
    "ses-EMC1baseline": "ABIDEII-EMC_1",
    "ses-ETHZ1baseline": "ABIDEII-ETH_1",
    "ses-GU1baseline": "ABIDEII-GU_1",
    "ses-IP1baseline": "ABIDEII-IP_1",
    "ses-IU1baseline": "ABIDEII-IU_1",
    "ses-KKI1baseline": "ABIDEII-KKI_1",
    "ses-KUL3baseline": "ABIDEII-KUL_3",
    "ses-NYU1baseline": "ABIDEII-NYU_1",
    "ses-NYU2baseline": "ABIDEII-NYU_2",
    "ses-OHSU1baseline": "ABIDEII-OHSU_1",
    "ses-ONRC2baseline": "ABIDEII-OILH_2",
    "ses-ONRC2followup1": "ABIDEII-OILH_2",
    "ses-SDSU1baseline": "ABIDEII-SDSU_1",
    "ses-TCD1baseline": "ABIDEII-TCD_1",
    "ses-UCD1baseline": "ABIDEII-UCD_1",
    "ses-UCLA1baseline": "ABIDEII-UCLA_1",
    "ses-USM1baseline": "ABIDEII-USM_1",
}
LONG_SESSIONS = {
    "ses-UPSMLongbaseline": "Baseline",
    "ses-UCLALongbaseline": "Baseline",
    "ses-UPSMLongfollowup1": "Followup_1",
    "ses-UCLALongfollowup1": "Followup_1",
}
COLS = ["DX_GROUP", "AGE_AT_SCAN", "SEX", "FIQ", "VIQ", "PIQ",
        "HANDEDNESS_CATEGORY", "ADOS_2_SEVERITY_TOTAL", "ADOS_G_TOTAL",
        "ADI_R_SOCIAL_TOTAL_A", "SRS_TOTAL_RAW", "PDD_DSM_IV_TR"]


def tidy(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    df.columns = [c.strip() for c in df.columns]
    return df


def main() -> None:
    comp = tidy(pd.read_csv(os.path.join(PHENO, "ABIDEII_Composite_Phenotypic.csv"),
                            encoding="latin-1"))
    lng = tidy(pd.read_csv(os.path.join(PHENO, "ABIDEII_Long_Composite_Phenotypic.csv"),
                           encoding="latin-1"))
    for c in COLS:
        for d in (comp, lng):
            if c not in d.columns:
                d[c] = np.nan

    inc = pd.read_csv(os.path.join(RESULTS, "sessions_included.csv"))
    inc["sub_id"] = inc.subject.str.extract(r"(\d+)").astype(int)

    rows = []
    for _, r in inc.iterrows():
        ses = r.session
        rec = dict(subject=r.subject, session=ses, sub_id=r.sub_id, tr=r.tr,
                   keep_s=r.keep_s, mean_fd=r.dcan_remaining_mean_fd,
                   n_keep=r.n_keep)
        if ses in LONG_SESSIONS:
            m = lng[(lng.SUB_ID == r.sub_id) & (lng.SESSION == LONG_SESSIONS[ses])]
            rec["collection"] = "longitudinal"
        else:
            site = SESSION_TO_SITE.get(ses)
            m = comp[(comp.SUB_ID == r.sub_id) & (comp.SITE_ID == site)]
            if m.empty:
                m = comp[comp.SUB_ID == r.sub_id]
            rec["collection"] = "cross-sectional"
        if m.empty:
            rec.update({c: np.nan for c in COLS})
            rec["site"] = SESSION_TO_SITE.get(ses, ses)
        else:
            m = m.iloc[0]
            rec["site"] = m["SITE_ID"]
            for c in COLS:
                rec[c] = m[c]
        rows.append(rec)

    ph = pd.DataFrame(rows)
    ph["site_scanner"] = ph.site.replace({"ABIDEI-PITT": "PITT_UPSM",
                                          "ABIDEII-UPSM_Long": "PITT_UPSM",
                                          "ABIDEI-UCLA_1": "UCLA_long",
                                          "ABIDEI-UCLA_2": "UCLA_long",
                                          "ABIDEII-UCLA_Long": "UCLA_long"})
    ph["dx"] = ph.DX_GROUP.map({1: "ASD", 2: "TDC"})
    ph["age"] = pd.to_numeric(ph.AGE_AT_SCAN, errors="coerce")
    ph["sex"] = ph.SEX.map({1: "M", 2: "F"})
    ph["wave"] = np.where(ph.session.str.contains("followup"), 2, 1)
    ph.to_csv(os.path.join(RESULTS, "phenotype_sessions.csv"), index=False)

    print(f"{len(ph)} sessions with phenotype; missing DX: {ph.dx.isna().sum()}")
    print(ph.groupby(["collection", "dx"]).size().to_string())
    pairs = (ph.groupby("subject").filter(lambda g: g.session.nunique() > 1)
               .sort_values(["subject", "wave"]))
    print(f"\nsubjects with two usable sessions: {pairs.subject.nunique()}")
    if len(pairs):
        w = pairs.pivot_table(index="subject", columns="wave", values="age")
        w["interval_y"] = w[2] - w[1]
        dx = pairs.groupby("subject").dx.first()
        print(pd.concat([w, dx], axis=1).to_string())
        print("\ninterval (y):", w.interval_y.describe().to_string())


if __name__ == "__main__":
    main()
