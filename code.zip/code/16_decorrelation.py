"""Step 16 - how fast does the connectivity signal decorrelate between sessions?

The longitudinal estimate in the autism sample compares two occasions separated
by 1.76 years and attributes everything that is not within-session measurement
error to development. That attribution is wrong by construction: two sessions on
different days differ in head position, arousal, caffeine, time of day and
physiological state, none of which is neurodevelopment. Without an estimate of
that between-session state term, the inferred decorrelation time is a lower
bound and the developmental component an upper bound.

CoRR supplies the missing term. It released CC200 connectomes for 363
individuals scanned twice at published intervals spanning 30 minutes to 516
days, processed with a single pipeline, so the *shape* of the decorrelation
function can be measured rather than assumed.

Two things are estimated here:

1.  A bridge. CoRR connectomes are magnitude-valued (no negative edges), whereas
    the main analysis uses signed Fisher-z connectivity. The same magnitude
    transform is therefore applied to the ABIDE data, and the reliability and
    the 1.76-year attenuation are recomputed. If the two feature spaces behave
    alike, the CoRR decorrelation shape transfers; if not, the analysis stops.

2.  The decorrelation function, fitted as

        r(dt) = rho_trait + rho_state * exp(-dt / tau_state),

    whose asymptote is the genuinely stable part of the signal and whose
    exponential term is reversible between-session state. The fit is then used
    to split the autism cohort's observed attenuation into measurement error,
    between-session state and developmental reconfiguration.
"""
from __future__ import annotations

import importlib.util
import json
import os
import sys

import numpy as np
import pandas as pd
from scipy import optimize, stats
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import pipeline as P  # noqa: E402

_spec = importlib.util.spec_from_file_location("theory", os.path.join(HERE, "03_theory.py"))
th = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(th)

ROOT = os.path.dirname(HERE)
DATA = os.path.join(ROOT, "data")
RESULTS = os.path.join(ROOT, "results")
STRATEGY = "ANT_frf_scr_ngs_cc2"
SEED = 20261024
N_PC = 50
DAYS_PER_YEAR = 365.25


# --------------------------------------------------------------- the bridge
def magnitude_bridge(T: int = 150):
    """Recompute the main analysis on magnitude-valued connectomes.

    |tanh(z)| reproduces the CoRR feature convention from our own signed data,
    so the two feature spaces can be compared directly in the same participants.
    """
    out = {}
    for name in ("signed", "magnitude"):
        meta, X = P.load("Gordon2014FreeSurferSubcortical", T)
        if name == "magnitude":
            X = {k: np.abs(np.tanh(v)).astype(np.float32) for k, v in X.items()}
        X = P.site_center(X, meta)
        disc = np.where((meta.dx == "ASD") & (meta.collection == "cross-sectional"))[0]
        X = P.regress_out(X, meta, ["mean_fd"], disc)
        sd = X["matched"][disc].std(0)
        sd[sd == 0] = 1.0
        S = {k: (v / sd).astype(np.float32) for k, v in X.items()}
        pca = PCA(n_components=N_PC, random_state=SEED).fit(S["matched"][disc])
        Z = {k: pca.transform(v) for k, v in S.items()}
        _lab, cen = P.cluster(Z["matched"][disc], 2, "kmeans", SEED)
        s = {k: P.axis_score(Z[k], cen)[0] for k in Z}
        mu, sg = s["matched"][disc].mean(), s["matched"][disc].std()
        s = {k: (v - mu) / sg for k, v in s.items()}
        r_half, _ = th.pooled_within_group_r(s["conA"][disc], s["conB"][disc],
                                             meta.site_scanner.values[disc])
        pairs = P.longitudinal_pairs(meta)
        long_idx = np.where(meta.collection.values == "longitudinal")[0]
        r_half_long, _ = th.pooled_within_group_r(
            s["conA"][long_idx], s["conB"][long_idx],
            np.array(["L"] * long_idx.size))
        r_long = float(np.corrcoef(s["matched"][pairs.i1.values],
                                   s["matched"][pairs.i2.values])[0, 1])
        # edge-level reliability, for comparison with CoRR's edgewise estimate
        a, b = X["conA"][disc], X["conB"][disc]
        num = ((a - a.mean(0)) * (b - b.mean(0))).mean(0)
        den = a.std(0) * b.std(0)
        er = num / np.where(den == 0, np.nan, den)
        out[name] = {
            "score_r_halfhalf_discovery": float(r_half),
            "score_rho_full_discovery": th.spearman_brown(float(r_half), 2.0),
            "score_r_halfhalf_longitudinal": float(r_half_long),
            "score_rho_full_longitudinal": th.spearman_brown(float(r_half_long), 2.0),
            "score_r_between_waves": r_long,
            "edge_median_r_halfhalf": float(np.nanmedian(er)),
            "edge_median_rho_full": float(th.spearman_brown(float(np.nanmedian(er)), 2.0)),
            "n_pairs": int(len(pairs)),
        }
        del X, S, Z
    a, b = out["signed"], out["magnitude"]
    out["agreement"] = {
        "delta_rho_full_discovery": b["score_rho_full_discovery"] - a["score_rho_full_discovery"],
        "delta_r_between_waves": b["score_r_between_waves"] - a["score_r_between_waves"],
        "delta_edge_rho": b["edge_median_rho_full"] - a["edge_median_rho_full"],
        "bridge_holds": bool(
            abs(b["score_rho_full_discovery"] - a["score_rho_full_discovery"]) < 0.15
            and abs(b["score_r_between_waves"] - a["score_r_between_waves"]) < 0.25),
    }
    return out


# ------------------------------------------------------- CoRR decorrelation
def corr_curve(strategy: str = STRATEGY):
    X = np.load(os.path.join(DATA, "corr", f"corr_conn_{strategy}.npy")).astype(np.float32)
    md = pd.read_csv(os.path.join(RESULTS, f"corr_meta_{strategy}.csv"))
    md["row"] = np.arange(len(md))
    # drop edges that are constant or non-finite anywhere
    ok = np.isfinite(X).all(0) & (X.std(0) > 0)
    X = X[:, ok]

    # centre within site on the session-1 mean, as in the main analysis
    for site, idx in md.groupby("site").groups.items():
        idx = np.asarray(list(idx))
        ref = idx[md.loc[idx, "session"].values == 1]
        X[idx] -= X[ref if ref.size else idx].mean(0, keepdims=True)

    s1 = md[md.session == 1].sort_values("subject")
    s2 = md[md.session == 2].sort_values("subject")
    common = sorted(set(s1.subject) & set(s2.subject))
    i1 = s1.set_index("subject").loc[common, "row"].values
    i2 = s2.set_index("subject").loc[common, "row"].values
    sites = s1.set_index("subject").loc[common, "site"].values
    interval = s1.set_index("subject").loc[common, "interval_days"].values

    # a multivariate connectivity score, fitted on session 1 only
    sd = X[i1].std(0)
    sd[sd == 0] = 1.0
    pca = PCA(n_components=N_PC, random_state=SEED).fit(X[i1] / sd)
    Z1, Z2 = pca.transform(X[i1] / sd), pca.transform(X[i2] / sd)
    _lab, cen = P.cluster(Z1, 2, "kmeans", SEED)
    sc1 = P.axis_score(Z1, cen)[0]
    sc2 = P.axis_score(Z2, cen)[0]
    pc1_1, pc1_2 = Z1[:, 0], Z2[:, 0]

    rows = []
    for site in sorted(set(sites)):
        m = sites == site
        if m.sum() < 8:
            continue
        xa, xb = X[i1][m], X[i2][m]
        num = ((xa - xa.mean(0)) * (xb - xb.mean(0))).mean(0)
        den = xa.std(0) * xb.std(0)
        er = num / np.where(den == 0, np.nan, den)
        rows.append(dict(
            site=site, n=int(m.sum()), interval_days=float(interval[m][0]),
            interval_years=float(interval[m][0] / DAYS_PER_YEAR),
            edge_median_r=float(np.nanmedian(er)),
            score_r=float(np.corrcoef(sc1[m], sc2[m])[0, 1]),
            pc1_r=float(np.corrcoef(pc1_1[m], pc1_2[m])[0, 1])))
    return pd.DataFrame(rows).sort_values("interval_days")


def fit_decay(df: pd.DataFrame, col: str):
    """r(dt) = rho_trait + rho_state * exp(-dt / tau_state), weighted by n - 3."""
    x = df.interval_days.values
    y = df[col].values
    w = np.sqrt(np.maximum(df.n.values - 3, 1))

    def model(p, x):
        trait, state, tau = p
        return trait + state * np.exp(-x / max(tau, 1e-6))

    def resid(p):
        return (model(p, x) - y) * w

    best, best_cost = None, np.inf
    for tau0 in (1, 5, 20, 60, 200, 600):
        p0 = [max(y.min(), 0.0), max(y.max() - y.min(), 0.05), tau0]
        try:
            r = optimize.least_squares(resid, p0,
                                       bounds=([0, 0, 0.1], [1, 1, 1e5]))
            if r.cost < best_cost:
                best, best_cost = r, r.cost
        except Exception:
            continue
    trait, state, tau = best.x
    pred = model(best.x, x)
    ss_res = float(np.sum((y - pred) ** 2))
    ss_tot = float(np.sum((y - y.mean()) ** 2))
    # bootstrap over sites
    rng = np.random.default_rng(SEED)
    boots = []
    for _ in range(2000):
        idx = rng.integers(0, len(x), len(x))
        try:
            rb = optimize.least_squares(
                lambda p: (model(p, x[idx]) - y[idx]) * w[idx], best.x,
                bounds=([0, 0, 0.1], [1, 1, 1e5]))
            boots.append(rb.x)
        except Exception:
            pass
    B = np.array(boots)
    return {
        "rho_trait": float(trait), "rho_state": float(state),
        "tau_state_days": float(tau), "tau_state_years": float(tau / DAYS_PER_YEAR),
        "r_squared": float(1 - ss_res / ss_tot) if ss_tot > 0 else np.nan,
        "ci_rho_trait": [float(np.percentile(B[:, 0], 2.5)), float(np.percentile(B[:, 0], 97.5))],
        "ci_tau_days": [float(np.percentile(B[:, 2], 2.5)), float(np.percentile(B[:, 2], 97.5))],
        "state_share_at_zero": float(state / (trait + state)) if (trait + state) > 0 else np.nan,
        "n_sites": int(len(x)),
    }


def main() -> None:
    out = {}
    print("bridge: signed versus magnitude connectomes in the same participants",
          flush=True)
    out["bridge"] = magnitude_bridge()
    b = out["bridge"]
    for k in ("signed", "magnitude"):
        v = b[k]
        print(f"  {k:<10} score rho={v['score_rho_full_discovery']:.3f}  "
              f"edge rho={v['edge_median_rho_full']:.3f}  "
              f"r(1.76 y)={v['score_r_between_waves']:.3f}", flush=True)
    print(f"  bridge holds: {b['agreement']['bridge_holds']}", flush=True)

    print("\nCoRR decorrelation curve", flush=True)
    df = corr_curve()
    df.to_csv(os.path.join(RESULTS, "corr_decorrelation_points.csv"), index=False)
    print(df.to_string(index=False), flush=True)
    out["corr_points"] = df.to_dict("records")

    fits = {}
    for col in ("score_r", "pc1_r", "edge_median_r"):
        fits[col] = fit_decay(df, col)
        f = fits[col]
        print(f"  {col:<15} trait={f['rho_trait']:.3f} state={f['rho_state']:.3f} "
              f"tau={f['tau_state_days']:.1f} d  R2={f['r_squared']:.3f}", flush=True)
    out["fits"] = fits

    # ------------------------------------------- three-component decomposition
    with open(os.path.join(RESULTS, "07_longitudinal.json")) as f:
        s7 = json.load(f)
    p = s7["primary"]
    rho0 = float(p["rho_within_site_pooled_full"])     # zero-interval reliability
    r_obs = float(p["r_score_between_waves"])
    dt_days = float(p["interval_mean_y"]) * DAYS_PER_YEAR
    fit = fits["score_r"]
    # fraction of the zero-interval signal that is reversible state, and how much
    # of it has decayed by the observed interval
    f_state = fit["state_share_at_zero"]
    decayed = f_state * (1.0 - np.exp(-dt_days / fit["tau_state_days"]))
    r_state_only = rho0 * (1.0 - decayed)       # expected r if nothing developed
    dec = {
        "rho_zero_interval": rho0,
        "r_observed_at_interval": r_obs,
        "interval_days": dt_days,
        "state_share_of_reliable_signal": f_state,
        "state_decayed_fraction_by_interval": float(decayed),
        "r_expected_state_only": float(r_state_only),
        "attenuation_total": float(rho0 - r_obs),
        "attenuation_from_state": float(rho0 - r_state_only),
        "attenuation_from_development": float(r_state_only - r_obs),
        "share_of_attenuation_that_is_state": float((rho0 - r_state_only) / (rho0 - r_obs))
        if rho0 > r_obs else np.nan,
    }
    # developmental decorrelation time, after removing the state term
    if r_obs < r_state_only:
        tau_dev = dt_days / np.log(r_state_only / r_obs) / DAYS_PER_YEAR
    else:
        tau_dev = np.inf
    dec["tau_development_years"] = float(tau_dev)
    dec["half_life_development_years"] = th.half_life(tau_dev)
    dec["tau_naive_years"] = float(dt_days / np.log(rho0 / r_obs) / DAYS_PER_YEAR) \
        if rho0 > r_obs else np.inf
    dec["half_life_naive_years"] = th.half_life(dec["tau_naive_years"])
    out["decomposition"] = dec
    print("\nthree-component decomposition at 1.76 years", flush=True)
    for k, v in dec.items():
        print(f"  {k}: {v if isinstance(v, str) else round(float(v), 4)}", flush=True)

    with open(os.path.join(RESULTS, "16_decorrelation.json"), "w") as f:
        json.dump(out, f, indent=1, default=float)
    print("\nwritten results/16_decorrelation.json")


if __name__ == "__main__":
    main()
