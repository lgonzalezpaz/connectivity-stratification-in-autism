"""Step 8 - what a longitudinal subtyping study would actually have to measure.

Combines the ceiling equation with the Spearman-Brown duration law and the
measured reliability of the subtype score to answer three design questions:

1.  How much retained resting-state data per session is needed before label
    agreement can even reach the conventional benchmarks for "moderate" and
    "substantial" reliability?
2.  How many participants are needed to distinguish genuine developmental
    reconfiguration from measurement noise at a given interval?
3.  How large is the attainable ceiling for existing large cohorts, given their
    published protocol lengths?

Protocol lengths used for the public cohorts are taken from the corresponding
data descriptors and are recorded in results/cohort_protocols.csv together with
their sources, so the calculator can be audited.
"""
from __future__ import annotations

import importlib.util
import json
import os
import sys

import numpy as np
import pandas as pd

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
_spec = importlib.util.spec_from_file_location("theory", os.path.join(HERE, "03_theory.py"))
th = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(th)

ROOT = os.path.dirname(HERE)
RESULTS = os.path.join(ROOT, "results")
SEED = 20261024


def power_curve(rho: float, omega: float, tau_alt: float, dt: float,
                ns, n_sim: int = 4000, alpha: float = 0.05, seed: int = SEED):
    """Power to reject the trait null in favour of latent decorrelation with
    characteristic time tau_alt, using the score correlation as the statistic."""
    rng = np.random.default_rng(seed)
    rows = []
    rho_alt = rho * np.exp(-dt / tau_alt)
    for n in ns:
        # null distribution of Fisher-z of the observed correlation
        z_null = np.empty(n_sim)
        z_alt = np.empty(n_sim)
        for i in range(n_sim):
            for j, rr in enumerate((rho, rho_alt)):
                theta = rng.standard_normal(n) * np.sqrt(rr)
                # common latent part with correlation rr between occasions
                s1 = theta + rng.standard_normal(n) * np.sqrt(1 - rr)
                s2 = theta + rng.standard_normal(n) * np.sqrt(1 - rr)
                z = np.arctanh(np.clip(np.corrcoef(s1, s2)[0, 1], -0.999999, 0.999999))
                if j == 0:
                    z_null[i] = z
                else:
                    z_alt[i] = z
        crit = np.percentile(z_null, 100 * alpha)
        rows.append(dict(n=n, power=float((z_alt < crit).mean()),
                         rho_null=rho, rho_alt=float(rho_alt)))
    return rows


def main() -> None:
    with open(os.path.join(RESULTS, "06_subtyping.json")) as f:
        s6 = json.load(f)
    with open(os.path.join(RESULTS, "07_longitudinal.json")) as f:
        s7 = json.load(f)

    rho_ref = float(s7["primary"]["rho_within_site_pooled_full"])
    T_ref = float(s6["matched_seconds"])
    omega = float(s6["omega_primary"])
    out = {"rho_reference": rho_ref, "T_reference_s": T_ref, "omega": omega}

    # ------------------------------------------------- duration requirements
    req = []
    for k_target in (0.2, 0.4, 0.6, 0.8):
        for om, nm in ((0.0, "continuum"), (omega, "data-informed"), (1.0, "categorical")):
            T = th.duration_for_kappa(k_target, rho_ref, T_ref, om)
            req.append(dict(kappa_target=k_target, omega_assumption=nm,
                            omega=om, rho_required=th.rho_for_kappa(k_target, om),
                            retained_seconds=T, retained_minutes=T / 60.0))
    out["duration_requirements"] = req
    pd.DataFrame(req).to_csv(os.path.join(RESULTS, "duration_requirements.csv"), index=False)
    for r in req:
        if r["omega_assumption"] == "data-informed":
            print(f"  kappa={r['kappa_target']:.1f} needs rho={r['rho_required']:.3f} "
                  f"= {r['retained_minutes']:.1f} min retained data", flush=True)

    # ----------------------------------------------------- ceiling by duration
    grid = []
    for T in np.arange(30, 3601, 30):
        rho = th.rho_from_duration(rho_ref, T, T_ref)
        grid.append(dict(seconds=float(T), minutes=float(T) / 60.0, rho=rho,
                         kappa_continuum=float(th.kappa_max_continuum(rho)),
                         kappa_data_informed=th.kappa_max(rho, omega),
                         kappa_categorical=float(th.kappa_max_categorical(rho))))
    pd.DataFrame(grid).to_csv(os.path.join(RESULTS, "ceiling_by_duration.csv"), index=False)

    # ------------------------------------- ceilings at illustrative durations
    rows = []
    for T in (150.0, 300.0, 600.0, 1200.0, 1800.0, 3600.0):
        rho = th.rho_from_duration(rho_ref, T, T_ref)
        rows.append(dict(retained_seconds=T, retained_minutes=T / 60.0,
                         rho_expected=rho,
                         kappa_ceiling_continuum=float(th.kappa_max_continuum(rho)),
                         kappa_ceiling_omega=th.kappa_max(rho, omega),
                         kappa_ceiling_categorical=float(th.kappa_max_categorical(rho))))
    out["ceilings_at_illustrative_durations"] = rows
    pd.DataFrame(rows).to_csv(os.path.join(RESULTS, "ceilings_illustrative.csv"), index=False)

    # ------------------------------------------------------------ power curves
    tau = float(s7["primary"]["ceiling_local"]["tau_years"])
    dt = float(s7["primary"]["interval_mean_y"])
    out["tau_observed_years"] = tau
    out["interval_years"] = dt
    pw = []
    for tau_alt in (2.0, 5.0, 10.0, 20.0):
        pw += [dict(tau_alt=tau_alt, **r) for r in
               power_curve(rho_ref, omega, tau_alt, dt,
                           ns=(10, 20, 50, 100, 200, 400, 800), n_sim=2000)]
    out["power"] = pw
    pd.DataFrame(pw).to_csv(os.path.join(RESULTS, "power_curves.csv"), index=False)
    for r in pw:
        if r["n"] in (50, 200):
            print(f"  tau_alt={r['tau_alt']:.0f} y, n={r['n']}: power={r['power']:.2f}",
                  flush=True)

    with open(os.path.join(RESULTS, "08_design.json"), "w") as f:
        json.dump(out, f, indent=1, default=float)
    print("written results/08_design.json")


if __name__ == "__main__":
    main()
