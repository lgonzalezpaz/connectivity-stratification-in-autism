"""Step 15 - assemble the CoRR repeat-scan connectomes.

The Consortium for Reliability and Reproducibility aggregated resting-state
scans acquired twice or more in the same individuals at inter-scan intervals
spanning four orders of magnitude, from four minutes to nearly four years, and
released CC200 connectomes computed with one pipeline for every site. That makes
it the only open resource that can measure how fast the connectivity signal
decorrelates *between* sessions, which is the term this study otherwise has to
assume.

Per-site retest intervals are taken from Table 1 of the CoRR data descriptor and
are recorded in SITES below, with the site's own published mean interval.

The script streams each GraphML file, keeps only the upper triangle, and never
stores the raw file.
"""
from __future__ import annotations

import os
import re
import sys
import urllib.parse
import urllib.request
from concurrent.futures import ThreadPoolExecutor, as_completed

import numpy as np
import pandas as pd

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
DATA = os.path.join(ROOT, "data", "corr")
RESULTS = os.path.join(ROOT, "results")
S3 = "https://s3.amazonaws.com/fcp-indi"
PREFIX = "data/Projects/CORR/JHU-preproc-connectomes/cpacv0392/"
BIDS = "data/Projects/CORR/RawDataBIDS/"
STRATEGY = "ANT_frf_scr_ngs_cc2"
STRATEGY_ALT = "ANT_frf_scr_gsr_cc2"
NPARC = 200
UA = {"User-Agent": "corr-retest-analysis/1.0 (academic research)"}

SITES = {
    # file-name site tag -> (published mean retest interval in days, design)
    "IPCAS5":  (30 / 1440,   "within-session"),
    "IPCAS6":  (210 / 1440,  "between-session"),
    "HNU1":    (3.65,        "between-session"),
    "IPCAS1":  (13.9,        "between-session"),
    "IPCAS2":  (33.6,        "between-session"),
    "BNU1":    (40.9,        "between-session"),
    "IACAS":   (75.2,        "between-session"),
    "MRN":     (109.0,       "between-session"),
    "IBATRT":  (115.4,       "between-session"),
    "BNU2":    (160.5,       "between-session"),
    "JHNU":    (202.6,       "between-session"),
    "LMU3":    (399.6,       "between-session"),
    "IPCAS8":  (516.0,       "between-session"),
}
# Excluded for want of a published retest interval: DC1 (Dartmouth) and the
# generically tagged "IPCAS" files, which cannot be assigned to an IPCAS
# sub-study. BNU3 and MPG1 contribute only one session in this release.


def list_keys(prefix: str):
    out, token = [], None
    while True:
        q = {"list-type": "2", "prefix": prefix, "max-keys": "1000"}
        if token:
            q["continuation-token"] = token
        xml = urllib.request.urlopen(
            urllib.request.Request(f"{S3}?{urllib.parse.urlencode(q)}", headers=UA),
            timeout=120).read().decode()
        out += re.findall(r"<Key>([^<]+)</Key>", xml)
        m = re.search(r"<NextContinuationToken>([^<]+)</NextContinuationToken>", xml)
        if not m:
            break
        token = m.group(1)
    return out


def parse_graphml(blob: bytes, iu) -> np.ndarray | None:
    s = blob.decode("utf-8", "replace")
    ed = re.findall(r'source="n(\d+)" target="n(\d+)">\s*<data key="e_weight">([-0-9.eE]+)', s)
    if len(ed) < NPARC:
        return None
    M = np.zeros((NPARC, NPARC), dtype=np.float32)
    for a, b, w in ed:
        i, j = int(a), int(b)
        if i < NPARC and j < NPARC:
            M[i, j] = float(w)
    M = np.maximum(M, M.T)          # the file stores each pair once per direction
    return M[iu].astype(np.float16)


def main(strategy: str = STRATEGY) -> None:
    os.makedirs(DATA, exist_ok=True)
    iu = np.triu_indices(NPARC, 1)

    keys = [k for k in list_keys(PREFIX + strategy + "/") if k.endswith(".graphml")]
    print(f"{len(keys)} connectome files in {strategy}", flush=True)
    pat = re.compile(r"/([A-Za-z0-9]+)_(\d+)_session_(\d+)_correlation\.graphml$")
    rows = []
    for k in keys:
        m = pat.search(k)
        if not m:
            continue
        site, sub, ses = m.group(1), m.group(2), int(m.group(3))
        if site not in SITES or ses > 2:    # first two sessions only
            continue
        rows.append(dict(key=k, subject=f"{site}_{sub}", session=ses, site=site))
    idx = pd.DataFrame(rows)
    both = idx.groupby("subject").session.nunique()
    idx = idx[idx.subject.isin(both[both >= 2].index)]
    print(f"{idx.subject.nunique()} subjects with two sessions across "
          f"{idx.site.nunique()} sites; {len(idx)} files to fetch", flush=True)
    print(idx.groupby("site").subject.nunique().sort_values(ascending=False).to_string())

    def job(r):
        try:
            blob = urllib.request.urlopen(
                urllib.request.Request(f"{S3}/{r.key}", headers=UA), timeout=180).read()
            v = parse_graphml(blob, iu)
            return (r.subject, r.session, r.site, v)
        except Exception:
            return (r.subject, r.session, r.site, None)

    vecs, meta, done = [], [], 0
    with ThreadPoolExecutor(max_workers=12) as ex:
        futs = [ex.submit(job, r) for r in idx.itertuples()]
        for f in as_completed(futs):
            sub, ses, site, v = f.result()
            done += 1
            if v is not None:
                vecs.append(v)
                meta.append(dict(subject=sub, session=ses, site=site))
            if done % 250 == 0:
                print(f"  {done}/{len(idx)}", flush=True)

    X = np.vstack(vecs)
    md = pd.DataFrame(meta)
    md["interval_days"] = md.site.map({k: v[0] for k, v in SITES.items()})
    md["design"] = md.site.map({k: v[1] for k, v in SITES.items()})
    np.save(os.path.join(DATA, f"corr_conn_{strategy}.npy"), X)
    md.to_csv(os.path.join(RESULTS, f"corr_meta_{strategy}.csv"), index=False)
    print(f"saved {X.shape} connectomes for {md.subject.nunique()} subjects")


if __name__ == "__main__":
    main(sys.argv[1] if len(sys.argv) > 1 else STRATEGY)
