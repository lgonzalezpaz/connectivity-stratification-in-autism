"""Step 14 - crawl the public NDA collection catalogue to find candidate cohorts.

NDA exposes collection *metadata* without credentials (``/api/collection/{id}``)
even though the data themselves are controlled access. This script walks the
catalogue, keeps the descriptive fields, and scores every collection for how
well it matches the requirement of this research line: an autism cohort with
repeated structural/functional MRI in the same individuals across development.

It downloads no participant data and requires no NDA account; it is a literature
-search tool for deciding which Data Use Certification is worth requesting.
"""
from __future__ import annotations

import json
import os
import re
import sys
import urllib.request
from concurrent.futures import ThreadPoolExecutor, as_completed

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
RESULTS = os.path.join(ROOT, "results")
API = "https://nda.nih.gov/api/collection/{}"
UA = {"User-Agent": "nda-catalogue-survey/1.0 (academic research)",
      "Accept": "application/json"}
KEEP = ("id", "title", "description", "shared_subject_count", "collection_types",
        "data_sources", "nihResearchInitiatives", "state")

AUTISM = re.compile(r"\b(autis\w*|ASD|pervasive developmental|Asperger)\b", re.I)
LONGITUDINAL = re.compile(
    r"\b(longitudinal|follow[- ]?up|repeated (?:measures|scans?|assessments?)|"
    r"time ?points?|waves?|prospective|age \d+ (?:and|to|-) ?\d+|"
    r"re-?scan\w*|trajector\w*|developmental course)\b", re.I)
IMAGING = re.compile(
    r"\b(MRI|fMRI|magnetic resonance|resting[- ]state|neuroimag\w*|DTI|"
    r"diffusion|connectom\w*|imaging)\b", re.I)
INFANT = re.compile(r"\b(infant|toddler|6[- ]month|12[- ]month|24[- ]month|"
                    r"baby|babies|prospective high[- ]risk|high[- ]likelihood)\b", re.I)


def fetch(cid: int):
    try:
        req = urllib.request.Request(API.format(cid), headers=UA)
        with urllib.request.urlopen(req, timeout=45) as r:
            d = json.loads(r.read())
        if not isinstance(d, dict) or "title" not in d:
            return None
        return {k: d.get(k) for k in KEEP}
    except Exception:
        return None


def score(rec: dict):
    text = " ".join(str(rec.get(k) or "") for k in
                    ("title", "description", "data_sources", "nihResearchInitiatives"))
    s = 0
    hits = []
    if AUTISM.search(text):
        s += 4
        hits.append("autism")
    if IMAGING.search(text):
        s += 2
        hits.append("imaging")
    if LONGITUDINAL.search(text):
        s += 3
        hits.append("longitudinal")
    if INFANT.search(text):
        s += 2
        hits.append("infant/toddler")
    n = rec.get("shared_subject_count") or 0
    if n >= 100:
        s += 1
    if n >= 500:
        s += 1
    return s, hits


def main(lo: int = 1, hi: int = 4700) -> None:
    cache = os.path.join(RESULTS, "nda_collections.json")
    if os.path.exists(cache):
        recs = json.load(open(cache))
    else:
        recs = []
        with ThreadPoolExecutor(max_workers=12) as ex:
            futs = {ex.submit(fetch, i): i for i in range(lo, hi + 1)}
            done = 0
            for f in as_completed(futs):
                r = f.result()
                done += 1
                if r:
                    recs.append(r)
                if done % 500 == 0:
                    print(f"  {done}/{hi - lo + 1} probed, {len(recs)} collections",
                          flush=True)
        json.dump(recs, open(cache, "w"), indent=1)
    print(f"{len(recs)} collections in the catalogue", flush=True)

    scored = []
    for r in recs:
        s, hits = score(r)
        if s >= 7:
            scored.append((s, hits, r))
    scored.sort(key=lambda x: (-x[0], -(x[2].get("shared_subject_count") or 0)))
    out = []
    for s, hits, r in scored:
        out.append({"score": s, "matches": hits, "id": r["id"], "title": r["title"],
                    "n_shared_subjects": r.get("shared_subject_count"),
                    "types": r.get("collection_types"),
                    "description": (r.get("description") or "")[:1200]})
    json.dump(out, open(os.path.join(RESULTS, "nda_candidates.json"), "w"), indent=1)
    print(f"{len(out)} candidate collections written to results/nda_candidates.json")
    for o in out[:40]:
        print(f"  [{o['score']}] #{o['id']:>5} n={o['n_shared_subjects'] or 0:>6} "
              f"{o['title'][:88]}")


if __name__ == "__main__":
    a = [int(x) for x in sys.argv[1:3]] or [1, 4700]
    main(*(a if len(a) == 2 else [1, a[0]]))
