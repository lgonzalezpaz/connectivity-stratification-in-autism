# Preregistered protocol: intraindividual stability of connectivity subtypes across early development

**Status:** specified and implemented before data access. The analysis code in
`code/17_nda_adapter.py` runs this protocol unchanged on NDA-derived data; no
step below requires a decision that has not already been fixed here.

**Target data:** NIMH Data Archive collections **#19** and **#2027** (Infant
Brain Imaging Study, MRI at 6, 12 and 24 months), **#2775** (the same children
re-scanned at 8–12 years) and, if available, **#4622** (adolescence). Access
requires an approved Data Use Certification; the authors of this protocol hold
none, and the protocol is deposited so that any group that does can execute it.

**Motivation:** the companion study shows that categorical subtype assignment
has an exact agreement ceiling set by the reliability of the underlying score,
and that in the only openly reusable autism cohort with repeat scans (n = 12,
1.76 years) observed agreement cannot be distinguished from a perfectly stable
trait. Infancy is where the question is sharpest: connectivity reorganises
faster between 6 and 24 months than at any later age, so if subtypes ever
genuinely switch, that is where it happens.

---

## 1. Primary hypotheses

**H1 (ceiling validity).** Within-session label agreement, computed by splitting
each scan in two, will equal the continuum ceiling evaluated at the measured
reliability of the subtype score,

    kappa_within = (2/pi) * arcsin(rho_half),

to within the 95% bootstrap interval, at every age (6, 12, 24 months and school
age). This is a direct replication of the companion study's central test in a
new age range and is the prerequisite for interpreting anything else.

**H2 (state versus development).** Observed between-wave agreement will fall
below the ceiling by more than measurement error alone predicts, and the
shortfall will increase with the inter-scan interval.

**H3 (the labelling step, not the biology).** Connectome identification accuracy
between waves will exceed chance by a wide margin at every interval, while label
agreement remains at or below "fair", reproducing the dissociation reported in
the companion study.

**H4 (arousal state is a confound, and the ceiling separates it).** Infant scans
are acquired during natural sleep and school-age scans awake. The reliability
measured at each age absorbs that difference, so the ceiling computed per age
will account for apparent subtype switching between sleep and awake sessions
without invoking neurodevelopment. Concretely: the drop in agreement between an
infant-to-infant comparison (both asleep) and an infant-to-school-age comparison
(sleep versus awake) will be predicted by the respective ceilings.

## 2. Exclusions and quality control, fixed in advance

1. Sessions with fewer than 150 s of retained data after scrubbing at
   FD < 0.3 mm are excluded. Infant FD thresholds are not relaxed; if fewer than
   20 participants survive at any age, that age is reported descriptively only
   and excluded from inferential tests.
2. All connectomes are reduced to a common retained duration before any analysis
   (primary 150 s; sensitivity 90, 120, 180, 240 s), as in the companion study.
3. Sessions with any empty parcel are excluded.
4. No participant is excluded on the basis of their subtype assignment or their
   change in assignment.

## 3. Analysis, fixed in advance

1. Edges are centred within site on the site's own first-wave mean, residualised
   on mean framewise displacement with coefficients fitted in the discovery
   sample only, scaled, and reduced by PCA to 50 components.
2. Subtypes are obtained by k-means with 50 restarts; k is selected by consensus
   clustering over 300 subsamples using the proportion of ambiguous clustering,
   with k = 2 as the pre-specified primary solution.
3. The subtype score is the projection on the centroid-difference axis; labels
   are its sign.
4. Reliability is the contiguous split-half correlation of that score, pooled
   within site by Fisher z and corrected to full length by Spearman-Brown.
   Interleaved halves are the pre-specified sensitivity analysis.
5. The ceiling is computed from the companion study's equations (7)–(9) at the
   measured reliability and the observed subtype prevalence, and reported as the
   continuum-to-dichotomy bracket. The Subtype Stability Index is the ratio of
   observed to attainable agreement.
6. The trait null is tested by parametric bootstrap at the realised sample size.
7. Identification accuracy is computed between every pair of waves, with a
   permutation null.

## 4. What would falsify the companion study's framework

Observed within-session agreement lying **outside** the predicted bracket in a
sample of at least 100 participants, at a measured reliability estimated from
the same data, falsifies the ceiling equation. Finding it inside the bracket in
infancy as well as in childhood and adulthood would establish it across the
developmental range.

## 5. Power

At the reliability reported in the companion study (rho = 0.59 at 150 s of
retained data) and a two-year interval, rejecting the trait null with 80% power
requires roughly 60 participants if subtype identity decorrelates with a
two-year characteristic time, 150 if five years and 400 if ten years. The IBIS
collections report of the order of 1,000 shared subjects, so H2 is answerable
there if the number with two or more usable resting-state scans is in the
hundreds. **The first analysis to run, before anything else, is simply to count
them:** `code/17_nda_adapter.py --audit` does exactly that and nothing else.

## 6. Deviations

Any departure from this document will be reported as such, with the reason, in
any publication arising. This file is version-controlled; the version tag at the
time of data access is the preregistered one.
