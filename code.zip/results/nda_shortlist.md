# Candidate NDA collections for an intraindividual subtype-stability study in autism

Produced by `code/14_nda_catalogue.py`, which crawled the **public** NDA collection
metadata API (no credentials, no participant data). 2,617 collections were
retrieved and scored for the combination autism + imaging + longitudinal +
infancy; 335 passed the threshold. The shortlist below is the subset whose
descriptions state repeated imaging in the same individuals.

All of these require an approved Data Use Certification naming every person who
will analyse the data; the DUC is institution-bound, purpose-bound and lasts one
year.

## First tier — repeated MRI in the same children, autism ascertainment

| NDA collection | Title | Shared subjects | Why it matters here |
|---|---|---|---|
| **#19** and **#2027** | Longitudinal MRI Study of Infants at Risk for Autism (IBIS / ACE 1 and ACE 2) | 1,039 | Prospective MRI and behaviour at **6, 12 and 24 months** in infants at high familial likelihood, four sites, ADOS/ADI-R phenotyping, `image03` imaging structure. The reference cohort for pre-symptomatic autism imaging. |
| **#2775** | Brain and Behavior Study of Autism from Infancy through School Age (IBIS school-age) | 448 | The same children re-scanned at **8–12 years**; the 2025 school-age resting-state paper reports 97 children with usable rs-fMRI and names this collection as the repository. Gives an infancy → school-age span within individuals. |
| **#4622** | A Longitudinal Brain and Behavior Study of Autism From Infancy Through Adolescence | 73 | Extends the same design into adolescence. Small, but the longest within-person span available. |
| **#3221** | MRI Based Presymptomatic Prediction of ASD | 114 | Explicitly pre-symptomatic infant imaging with `image03`; directly addresses the earliest window. |

## Second tier — large heterogeneity/connectomics collections

| NDA collection | Title | Shared subjects | Why it matters here |
|---|---|---|---|
| **#3136** | Parsing early emerging heterogeneity related to autism spectrum disorder | 2,231 | The largest autism-heterogeneity collection found; quantifies behavioural and brain-connectivity-based heterogeneity in toddlers. Directly adjacent to the subtyping question. |
| **#3200** | Harmonization for multisite Connectomics: parsing heterogeneity and creating markers | 382 | Multisite connectomics harmonisation plus heterogeneity parsing — the methodological neighbours of this work. |
| **#2778** | Heterogeneity in ASD: Biological Mechanisms, Trajectories, and Treatment | 289 | Trajectory-focused heterogeneity cohort. |
| **#2026** | Biomarkers of Developmental Trajectories and Treatment in ASD (UCLA ACE) | 629 | Longitudinal multimodal imaging with `image03`. |

## Normative comparison cohort

| NDA collection | Title | Shared subjects | Why it matters here |
|---|---|---|---|
| **#2848** | UNC/UMN Baby Connectome Project | 420 | Accelerated longitudinal design across early childhood; the source of the only published infant connectome-fingerprinting work. The natural typically-developing reference for a developmental decorrelation estimate. |

## What the metadata cannot tell us

The public API exposes titles, descriptions, expected data structures and shared
subject counts, but not the number of imaging visits per participant or how many
of those visits include usable resting-state fMRI. Those counts are only visible
after a DUC is approved, by querying the `image03` structure for `visit` and
`interview_age`. The first query to run on gaining access is therefore simply:
how many individuals have two or more usable resting-state scans, and at what
intervals — the same question this study had to answer for ABIDE.
