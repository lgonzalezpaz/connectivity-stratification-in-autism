"""Post-process the built manuscript: write a well-formed page-number field.

docx-js emits the PAGE field's begin/instrText/separate/end markers inside a
single run with no field result. Word renders that correctly, but other
renderers (and some submission systems) do not, so the header is rewritten here
as the canonical five-run form with a cached result.
"""
from __future__ import annotations

import os
import re
import shutil
import subprocess
import sys
import tempfile
import zipfile

HERE = os.path.dirname(os.path.abspath(__file__))
DOCX = os.path.join(HERE, "Manuscript_Subtype_Stability_Ceiling.docx")

RPR = ('<w:rPr><w:rFonts w:ascii="Times New Roman" w:cs="Times New Roman" '
       'w:eastAsia="Times New Roman" w:hAnsi="Times New Roman"/>'
       '<w:sz w:val="20"/><w:szCs w:val="20"/></w:rPr>')
FIELD = (f'<w:r>{RPR}<w:fldChar w:fldCharType="begin"/></w:r>'
         f'<w:r>{RPR}<w:instrText xml:space="preserve"> PAGE </w:instrText></w:r>'
         f'<w:r>{RPR}<w:fldChar w:fldCharType="separate"/></w:r>'
         f'<w:r>{RPR}<w:t>1</w:t></w:r>'
         f'<w:r>{RPR}<w:fldChar w:fldCharType="end"/></w:r>')


def main() -> None:
    if not os.path.exists(DOCX):
        sys.exit(f"missing {DOCX}")
    tmp = tempfile.mkdtemp()
    with zipfile.ZipFile(DOCX) as z:
        names = z.namelist()
        z.extractall(tmp)
    fixed = 0
    for n in names:
        if not re.match(r"word/header\d+\.xml$", n):
            continue
        p = os.path.join(tmp, n)
        with open(p, encoding="utf-8") as f:
            xml = f.read()
        xml = xml.replace('<w:pPr><w:jc w:val="right"/></w:pPr>',
                          '<w:pPr><w:suppressLineNumbers/><w:jc w:val="right"/></w:pPr>')
        new, k = re.subn(r"<w:r>(?:(?!</w:r>).)*?<w:fldChar w:fldCharType=\"begin\"/>"
                         r".*?<w:fldChar w:fldCharType=\"end\"/></w:r>", FIELD, xml,
                         flags=re.S)
        if k:
            with open(p, "w", encoding="utf-8") as f:
                f.write(new)
            fixed += k
    out = DOCX + ".tmp"
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
        for n in names:
            z.write(os.path.join(tmp, n), n)
    shutil.move(out, DOCX)
    shutil.rmtree(tmp)
    print(f"rewrote {fixed} page-number field(s)")


if __name__ == "__main__":
    main()
