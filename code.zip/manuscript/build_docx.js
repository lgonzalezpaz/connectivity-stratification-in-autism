/*
 * Build the submission-ready Word manuscript from manuscript.md.
 *
 * Applies the journal style explicitly: US Letter, 1-inch margins, Times New
 * Roman, double-spaced body, continuous line numbers, page numbers top right,
 * centred and sequentially numbered equations as editable text, Vancouver
 * references with superscript in-text numbers resolved from the machine-verified
 * bibliography, and figures embedded after their legends.
 */
const fs = require('fs');
const path = require('path');
const d = require('docx');
const {
  Document, Packer, Paragraph, TextRun, HeadingLevel, AlignmentType, TabStopType,
  Table, TableRow, TableCell, WidthType, ShadingType, BorderStyle, ImageRun,
  Header, PageNumber, LineNumberRestartFormat, PageOrientation, convertInchesToTwip,
} = d;

const ROOT = path.resolve(__dirname, '..');
const MD = path.join(__dirname, 'manuscript.md');
const REFS = path.join(ROOT, 'results', 'references_verified.json');
const FIGDIR = path.join(ROOT, 'figures');
const OUT = path.join(__dirname, 'Manuscript_Subtype_Stability_Ceiling.docx');

const SERIF = 'Times New Roman';
const PAGE_W = 12240, MARGIN = 1440;         // US Letter, 1 inch
const TEXT_W = PAGE_W - 2 * MARGIN;          // 9360 dxa
const DOUBLE = 480;                           // 240 = single line

// ----------------------------------------------------------------- references
const refdata = JSON.parse(fs.readFileSync(REFS, 'utf8'));
const order = [];
function citeNumbers(keys) {
  return keys.map(k => {
    let i = order.indexOf(k);
    if (i === -1) { order.push(k); i = order.length - 1; }
    return i + 1;
  });
}
function vancouver(key) {
  const r = refdata[key];
  if (!r || !r.crossref || !r.crossref.ok) {
    if (key === 'pedregosa2011') {
      return 'Pedregosa F, Varoquaux G, Gramfort A, Michel V, Thirion B, Grisel O, et al. '
        + 'Scikit-learn: machine learning in Python. J Mach Learn Res. 2011;12:2825-2830.';
    }
    return `[UNRESOLVED REFERENCE: ${key}]`;
  }
  const c = r.crossref;
  const a = c.authors || [];
  const names = a.slice(0, 6).join(', ') + (a.length > 6 ? ', et al' : '');
  const jt = (c.short_journal || c.journal || '').replace(/\.$/, '');
  let t = (c.title || '').replace(/<[^>]+>/g, '').replace(/\s+/g, ' ').trim().replace(/\.$/, '');
  let s = `${names}. ${t}. ${jt}. ${c.year}`;
  if (c.volume) s += `;${c.volume}`;
  if (c.page) s += `:${c.page}`;
  return s + `. doi:${c.doi}.`;
}

// --------------------------------------------------------------- inline runs
const GREEK = 'α-ωΑ-Ω';
function italicToken(tok) {
  if (/^[a-zA-Z]$/.test(tok)) return true;                 // single Latin letter
  if (new RegExp(`^[${GREEK}]$`).test(tok)) return true;     // single Greek letter
  if (/^(P|n|t|r|z|d|U|F)$/.test(tok)) return true;
  return false;
}
function mathRuns(text, size) {
  // italicise single-letter variables and Greek symbols, leave the rest roman
  const parts = text.split(/([A-Za-zΑ-Ωα-ω]+|[^A-Za-zΑ-Ωα-ω]+)/)
    .filter(x => x !== '' && x !== undefined);
  return parts.map(p => new TextRun({
    text: p, font: SERIF, size, italics: italicToken(p),
  }));
}
function inlineRuns(text, opts = {}) {
  const size = opts.size || 24;
  const runs = [];
  // split on bold, italic and citation tokens
  const re = /(\*\*[^*]+\*\*|\*[^*]+\*|\[@[a-z0-9,]+\])/g;
  let last = 0, m;
  while ((m = re.exec(text)) !== null) {
    if (m.index > last) runs.push(new TextRun({ text: text.slice(last, m.index), font: SERIF, size }));
    const tok = m[0];
    if (tok.startsWith('[@')) {
      const keys = tok.slice(2, -1).split(',');
      runs.push(new TextRun({
        text: citeNumbers(keys).join(','), font: SERIF, size, superScript: true,
      }));
    } else if (tok.startsWith('**')) {
      runs.push(new TextRun({ text: tok.slice(2, -2), font: SERIF, size, bold: true }));
    } else {
      runs.push(new TextRun({ text: tok.slice(1, -1), font: SERIF, size, italics: true }));
    }
    last = m.index + tok.length;
  }
  if (last < text.length) runs.push(new TextRun({ text: text.slice(last), font: SERIF, size }));
  return runs;
}

const P = (text, o = {}) => new Paragraph({
  children: inlineRuns(text, o),
  alignment: o.align || AlignmentType.LEFT,
  spacing: { line: o.line === undefined ? DOUBLE : o.line, after: o.after === undefined ? 120 : o.after },
  indent: o.indent,
  keepNext: o.keepNext,
});

// --------------------------------------------------------------------- tables
function buildTable(rows0) {
  const ncol = Math.max(...rows0.map(r => r.length));
  const rows = rows0.map(r => r.concat(Array(ncol - r.length).fill('')));
  const need = Array(ncol).fill(0);
  rows.forEach(r => r.forEach((c, j) => {
    const L = c.replace(/\*\*/g, '').length;
    need[j] = Math.max(need[j], Math.min(L, 42));
  }));
  const MIN = 760;
  let widths = need.map(x => Math.floor(TEXT_W * x / need.reduce((a, b) => a + b, 0)));
  // raise narrow columns to a legible minimum, then shrink the rest to compensate
  for (let pass = 0; pass < 6; pass++) {
    const small = widths.map((w, j) => (w < MIN ? j : -1)).filter(j => j >= 0);
    if (!small.length) break;
    let deficit = 0;
    small.forEach(j => { deficit += MIN - widths[j]; widths[j] = MIN; });
    const big = widths.map((w, j) => (w > MIN ? j : -1)).filter(j => j >= 0);
    if (!big.length) break;
    const pool = big.reduce((a, j) => a + widths[j], 0);
    big.forEach(j => { widths[j] = Math.max(MIN, widths[j] - Math.round(deficit * widths[j] / pool)); });
  }
  const drift = TEXT_W - widths.reduce((a, b) => a + b, 0);
  widths[widths.indexOf(Math.max(...widths))] += drift;
  const border = { style: BorderStyle.SINGLE, size: 4, color: '000000' };
  return new Table({
    columnWidths: widths,
    width: { size: TEXT_W, type: WidthType.DXA },
    rows: rows.map((cells, ri) => new TableRow({
      tableHeader: ri === 0,
      children: cells.map((c, ci) => new TableCell({
        width: { size: widths[ci], type: WidthType.DXA },
        shading: ri === 0 ? { type: ShadingType.CLEAR, fill: 'F2F2F2' } : undefined,
        borders: { top: border, bottom: border, left: border, right: border },
        children: [new Paragraph({
          children: inlineRuns(c, { size: ncol >= 8 ? 16 : 18 }),
          spacing: { line: 240, after: 40 },
        })],
      })),
    })),
  });
}

// ----------------------------------------------------------------------- main
const lines = fs.readFileSync(MD, 'utf8').split('\n');
const body = [];
let eqNo = 0;
let i = 0;
let afterAbstractHeading = false;

while (i < lines.length) {
  const raw = lines[i];
  const line = raw.trimEnd();
  i++;
  if (line.trim() === '') continue;

  if (line.startsWith('# ')) {
    body.push(new Paragraph({
      children: [new TextRun({ text: line.slice(2), font: SERIF, size: 32, bold: true })],
      alignment: AlignmentType.LEFT, spacing: { line: DOUBLE, after: 240 },
    }));
    continue;
  }
  if (line.startsWith('[AUTHORS]')) {
    const txt = line.replace('[AUTHORS]', '').trim();
    const runs = [];
    txt.split(/(\^[^^]+\^)/).forEach(seg => {
      if (!seg) return;
      if (seg.startsWith('^') && seg.endsWith('^')) {
        runs.push(new TextRun({ text: seg.slice(1, -1), font: SERIF, size: 24, superScript: true }));
      } else {
        runs.push(new TextRun({ text: seg, font: SERIF, size: 24 }));
      }
    });
    body.push(new Paragraph({ children: runs, alignment: AlignmentType.CENTER,
      spacing: { line: 240, after: 80 } }));
    continue;
  }
  if (line.startsWith('[AFFIL]')) {
    body.push(new Paragraph({
      children: [new TextRun({ text: line.replace('[AFFIL]', '').trim(), font: SERIF, size: 19, italics: true })],
      alignment: AlignmentType.CENTER, spacing: { line: 240, after: 40 },
    }));
    continue;
  }
  if (line.startsWith('[CORRESP]')) {
    body.push(new Paragraph({
      children: [new TextRun({ text: line.replace('[CORRESP]', '').trim(), font: SERIF, size: 20 })],
      alignment: AlignmentType.CENTER, spacing: { line: 240, after: 240 },
    }));
    continue;
  }
  if (line.startsWith('## ')) {
    const t = line.slice(3);
    afterAbstractHeading = (t === 'Abstract');
    body.push(new Paragraph({
      children: [new TextRun({ text: t, font: SERIF, size: 26, bold: true })],
      spacing: { before: 240, line: DOUBLE, after: 120 }, keepNext: true,
    }));
    continue;
  }
  if (line.startsWith('### ')) {
    body.push(new Paragraph({
      children: [new TextRun({ text: line.slice(4), font: SERIF, size: 23, bold: true })],
      spacing: { before: 180, line: DOUBLE, after: 100 }, keepNext: true,
    }));
    continue;
  }
  if (line.startsWith('[EQ]')) {
    eqNo += 1;
    const txt = line.replace('[EQ]', '').trim().replace(/\s*\(\d+\)\s*$/, '');
    body.push(new Paragraph({
      children: [new TextRun({ text: '\t', font: SERIF, size: 24 })]
        .concat(mathRuns(txt, 24))
        .concat([new TextRun({ text: `\t(${eqNo})`, font: SERIF, size: 24 })]),
      tabStops: [
        { type: TabStopType.CENTER, position: Math.floor(TEXT_W / 2) },
        { type: TabStopType.RIGHT, position: TEXT_W },
      ],
      spacing: { before: 120, line: DOUBLE, after: 120 },
    }));
    continue;
  }
  if (line.startsWith('[PLACE]')) {
    body.push(new Paragraph({
      children: [new TextRun({ text: line.replace('[PLACE]', '').trim(), font: SERIF, size: 24, bold: true })],
      alignment: AlignmentType.CENTER, spacing: { before: 120, line: DOUBLE, after: 120 },
    }));
    continue;
  }
  if (line.startsWith('[TAB]')) {
    body.push(new Paragraph({
      children: inlineRuns(line.replace('[TAB]', '').trim(), { size: 20 }),
      spacing: { before: 200, line: 240, after: 100 }, keepNext: true,
    }));
    continue;
  }
  if (line.startsWith('[FIGCAP]')) {
    body.push(new Paragraph({
      children: inlineRuns(line.replace('[FIGCAP]', '').trim(), { size: 20 }),
      spacing: { before: 160, line: 240, after: 120 },
    }));
    continue;
  }
  if (line.startsWith('|')) {              // markdown table block
    const rows = [];
    let j = i - 1;
    while (j < lines.length && lines[j].trimStart().startsWith('|')) {
      const cells = lines[j].trim().replace(/^\|/, '').replace(/\|$/, '').split('|').map(c => c.trim());
      if (!/^-+$/.test(cells[0].replace(/[-: ]/g, '') === '' ? '-' : 'x')) rows.push(cells);
      j++;
    }
    i = j;
    const clean = rows.filter(r => !r.every(c => /^[-: ]*$/.test(c)));
    if (clean.length) {
      body.push(buildTable(clean));
      body.push(new Paragraph({ children: [new TextRun({ text: '', size: 12 })], spacing: { after: 160 } }));
    }
    continue;
  }
  if (line.startsWith('[REFERENCES]')) {
    for (let k = 0; k < order.length; k++) {
      body.push(new Paragraph({
        children: [new TextRun({ text: `${k + 1}. ${vancouver(order[k])}`, font: SERIF, size: 19 })],
        spacing: { line: 276, after: 60 },
        indent: { left: 360, hanging: 360 },
      }));
    }
    continue;
  }
  if (line.startsWith('**Keywords:**')) {
    body.push(new Paragraph({
      children: inlineRuns(line, { size: 20 }),
      spacing: { line: 240, after: 200 },
    }));
    continue;
  }
  // ordinary paragraph; the abstract is set slightly smaller and single-spaced
  const isAbstract = afterAbstractHeading;
  if (isAbstract) afterAbstractHeading = false;
  body.push(P(line, isAbstract ? { size: 21, line: 276 } : {}));
}

// figures, embedded after the legends
const figs = ['figure1_stability_ceiling', 'figure2_subtypes_and_reliability',
  'figure3_ceiling_validation', 'figure4_longitudinal_stability',
  'figure5_design_implications'];
body.push(new Paragraph({
  children: [new TextRun({ text: 'Figures', font: SERIF, size: 26, bold: true })],
  spacing: { before: 400, line: DOUBLE, after: 160 }, pageBreakBefore: true,
}));
figs.forEach((f, idx) => {
  const p = path.join(FIGDIR, `${f}.png`);
  if (!fs.existsSync(p)) return;
  const widthIn = 6.5;
  const sizeOf = require('child_process').execSync(
    `python3 -c "import struct,sys;d=open('${p}','rb').read(33);print(struct.unpack('>II',d[16:24])[0],struct.unpack('>II',d[16:24])[1])"`
  ).toString().trim().split(' ').map(Number);
  const ratio = sizeOf[1] / sizeOf[0];
  body.push(new Paragraph({
    children: [new ImageRun({
      type: 'png', data: fs.readFileSync(p),
      transformation: { width: widthIn * 96, height: widthIn * 96 * ratio },
    })],
    alignment: AlignmentType.CENTER, spacing: { after: 120 },
    pageBreakBefore: idx > 0,
  }));
  body.push(new Paragraph({
    children: [new TextRun({ text: `Figure ${idx + 1}`, font: SERIF, size: 20, bold: true })],
    alignment: AlignmentType.CENTER, spacing: { after: 400 },
  }));
});

const doc = new Document({
  creator: '[AUTHOR 1]',
  title: 'Individuals stay recognisable while their subtypes do not',
  styles: { default: { document: { run: { font: SERIF, size: 24, color: '000000' } } } },
  sections: [{
    properties: {
      page: {
        size: { width: PAGE_W, height: 15840, orientation: PageOrientation.PORTRAIT },
        margin: { top: MARGIN, right: MARGIN, bottom: MARGIN, left: MARGIN },
      },
      lineNumbers: { countBy: 1, start: 1, restart: LineNumberRestartFormat.CONTINUOUS, distance: 360 },
    },
    headers: {
      default: new Header({
        children: [new Paragraph({
          alignment: AlignmentType.RIGHT,
          children: [new TextRun({ children: [PageNumber.CURRENT], font: SERIF, size: 20 })],
        })],
      }),
    },
    children: body,
  }],
});

Packer.toBuffer(doc).then(buf => {
  fs.writeFileSync(OUT, buf);
  console.log(`wrote ${OUT} (${(buf.length / 1e6).toFixed(2)} MB), ${eqNo} equations, ${order.length} references`);
  fs.writeFileSync(path.join(__dirname, 'reference_list.txt'),
    order.map((k, n) => `${n + 1}. ${vancouver(k)}`).join('\n') + '\n');
});
