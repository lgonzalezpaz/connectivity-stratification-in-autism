# Individuals stay recognisable while their subtypes do not: a measurement ceiling for connectivity stratification in autism

[AUTHORS] [AUTHOR 1]^1,*^; [AUTHOR 2][@lombardo2019]; [AUTHOR 3][@feczko2019]
[AFFIL] 1. [Affiliation 1 — department, institution, city, country]
[AFFIL] 2. [Affiliation 2 — department, institution, city, country]
[CORRESP] *Correspondence: lgonzalezpaz@gmail.com ([AUTHOR 1 INITIALS])

## Abstract

Stratifying autism by functional connectivity is among the most actively pursued routes to precision psychiatry, yet it rests on an untested premise: that an individual's subtype is a stable property of that individual rather than a property of the scan. Whether a child assigned to a hyperconnected subtype remains in that subtype years later has never been measured directly, because the question requires repeat connectomes that almost no openly reusable resource contains. Here we show that the question cannot be answered without first fixing the measurement model, and we derive the model in closed form. Treating two-cluster assignment as a threshold on a noisy latent score yields an exact upper bound on attainable label agreement as a function of score reliability and of how categorical the latent structure is, bounded below by a continuum limit and above by a dichotomy limit. The bound predicted observed within-session agreement in 378 autistic participants of ABIDE II and, independently, in 468 autistic participants of ABIDE I processed with a different pipeline and parcellation, in every case to within the confidence interval. Applying the model to the only repeat connectomes in autism that are reusable without a data-use agreement, twelve individuals rescanned after 1.6 to 2.0 years, label agreement was poor and realised only 41% of the attainable ceiling, yet the same scans identified individuals from their connectomes with 75 to 92% accuracy against 8% chance. Subtype identity is therefore lost in the labelling, not in the biology.

**Keywords:** autism spectrum disorder; functional connectivity; biotypes; test–retest reliability; clustering; precision psychiatry; neurodevelopment; connectome fingerprinting

## Introduction

Autism is defined behaviourally but is biologically heterogeneous, and the dominant strategy for converting that heterogeneity into something clinically actionable has been stratification: dividing autistic individuals into subgroups whose brain measurements are more homogeneous than the diagnostic category as a whole[@lombardo2019,feczko2019]. Resting-state functional connectivity is the measurement of choice, because it is non-invasive, is acquired in minutes, and is aggregated across sites in open resources of a size that clustering methods require[@dimartino2014,dimartino2017]. Consensus clustering of connectivity in 657 autistic individuals recovered two stable subtypes, one hypoconnected and one hyperconnected relative to non-autistic participants, with transcriptomic enrichment for excitation–inhibition imbalance confined to the hyperconnected subtype[@rasero2023]. Connectivity-gradient subtyping reproduced three subgroups with similar symptom profiles across discovery and replication samples[@choi2022], and a four-subgroup model defined on brain–behaviour dimensions replicated across parcellations and in an independent dataset[@buch2023].

All of this evidence concerns reproducibility *between samples*: whether re-running an analysis elsewhere recovers a similar partition. It is silent on a different and, for any clinical use, more fundamental property — whether a *given individual* stays in the same subgroup over time. The distinction matters most where stratification is most wanted. Functional connectivity differences in autism are not uniform across the lifespan: within-network hyperconnectivity is reported in children under 11 but not in adolescents, whose differences are confined to between-network connectivity, and not at all in adults[@nomi2015,padmanabhan2017]. If subtypes track that developmental reorganisation, a child assigned to a hyperconnected subtype at 3 years could appear hypoconnected at 10, and an assignment made once would be a statement about an occasion rather than about a person.

The intraindividual question is unanswered rather than answered negatively. A recent multicentre study measured the temporal stability of resting-state activity itself in autism, reporting regionally specific alterations and noting that the underlying mechanisms remain poorly understood[@xuan2026]. A four-year follow-up study derived neurofunctional subtypes from baseline imaging and related them to subsequent executive-function trajectories, but did not reimage participants to ask whether their subtype assignment persisted[@yue2026]. Across modalities, subtyping solutions derived from structural, resting-state and task measures in the same participants agree poorly with one another even when each is internally stable[@wen2025], and connectivity features predictive of autism generalise only weakly across sites[@king2019]; reviews of the field explicitly recommend evaluating subtype reliability[@horien2022]. What is missing is the direct measurement: the same individuals, the same pipeline, two occasions separated by development.

That measurement, however, cannot be interpreted on its own. Any categorical assignment inherits the unreliability of the measurement it is computed from, and individual functional-connectivity edges are among the least reliable measurements in neuroimaging: a meta-analysis of a decade of test–retest studies put the average edge-level intraclass correlation at 0.29[@noble2019]; poor reliability of this kind has been shown to limit individual-differences research with fMRI quite generally[@elliott2020]; and reliability improves substantially only as scan length grows from five minutes to a quarter of an hour or more[@noble2017,birn2013]. A subtype label is a one-bit summary of such a measurement. Before an observed switch between waves can be attributed to brain development, it has to be compared with how often a *perfectly stable* subtype would appear to switch given the reliability actually achieved. No such benchmark exists, and in its absence reported instability is uninterpretable in either direction.

Here we supply the benchmark analytically and then use it. We show that for the two-cluster solutions that dominate this literature, assignment depends on the data only through a scalar projection, so expected label agreement can be written in closed form as a function of the reliability of that projection and of a single parameter describing how categorical the latent structure is. The resulting *stability ceiling* is bounded by two exact limits, one for subtypes that cut a continuum and one for subtypes that are a true dichotomy. We validate the ceiling against simulation and then against data, twice, in independent samples processed with unrelated pipelines. We then apply it to the only openly available repeat connectomes in autism and, in the same scans, ask a complementary question that does not depend on labels at all: whether individuals remain recognisable from their connectomes across development. Our aim is not to deliver a verdict on whether autism subtypes are traits — we show that the open evidence base is far too small for that — but to make the question answerable, and to quantify exactly what answering it would require.

## Methods

### Data sources

All data were public and required no data-use agreement. Resting-state derivatives for ABIDE II[@dimartino2017] were obtained from the DCAN Labs release hosted by the International Neuroimaging Data-sharing Initiative (`s3://fcp-indi/data/Projects/ABIDE2/Derivatives/DCAN/`), which provides, for each session, parcellated BOLD time series in CIFTI grayordinate format[@glasser2013] for four parcellations and the framewise-displacement (FD) mask used by the pipeline. The primary parcellation was Gordon (333 cortical parcels[@gordon2016] plus 19 FreeSurfer subcortical structures, 352 total, 61,776 edges); the Glasser multimodal parcellation (360 cortical[@glasser2016] plus 19 subcortical, 379 total), the surface-mapped Power ROI set (75 cortical[@power2011] plus 19 subcortical, 94 total) and a human projection of the macaque M132 parcellation (186 cortical[@markov2014] plus 19 subcortical, 205 total), all as distributed with the pipeline, were used for sensitivity analyses. Phenotypic data, including Autism Diagnostic Observation Schedule[@lord2000] scores, were taken from the ABIDE II composite and longitudinal composite tables.

Two ABIDE II collections contributed longitudinal data. Their baseline scans were released in ABIDE I[@dimartino2014] and their follow-up scans in ABIDE II, and both waves were reprocessed identically in the DCAN release, so the two occasions of a participant differ in acquisition date but not in protocol or processing. These are, to our knowledge, the only resting-state data distributed without a data-use agreement in which the same autistic individuals were scanned twice during development; longitudinal autism imaging held in controlled-access repositories was outside the scope of this analysis by design, since our aim was to characterise what the openly reusable evidence base can support.

For independent replication we used the ABIDE I Preprocessed Connectomes Project release (C-PAC pipeline, CC200 parcellation, 200 regions, 19,900 edges), in both the band-pass-filtered strategy with global signal regression and the strategy without it.

### Motion quantification and quality control

The DCAN motion mask stores, for 51 FD thresholds spanning 0.00–0.50 mm in 0.01 mm steps, the binary frame-removal vector the pipeline would apply. A per-frame FD trace was therefore recovered at 0.01 mm resolution as the lowest threshold at which a frame is retained, and the pipeline's own mask at FD < 0.3 mm was used for scrubbing[@power2012]; the release applies the respiratory-artefact correction recommended for multiband acquisitions[@fair2020]. Sessions were retained if they provided at least the matched duration of scrubbed data and contained no empty parcels. Of 1,009 sessions downloaded, 884 met these criteria at the primary matched duration.

### Duration-matched connectomes and split halves

Scan duration is the strongest determinant of connectome reliability[@noble2017,birn2013] and varied more than threefold across collections, so every session was reduced to a common amount of retained data before any connectome was computed. Matched durations of 90, 120, 150, 180 and 240 s were produced; 150 s was fixed in advance as the primary value, being the longest duration retaining a majority of the longitudinal participants. For a parcel time series truncated to the matched segment, the connectome was the Fisher-transformed Pearson correlation between every parcel pair,

[EQ] z_{ij} = arctanh( r_{ij} ),     i < j     (1)

vectorised over the upper triangle. Each matched segment was additionally split into two independent half-length connectomes in two ways: contiguous (first versus second half) and interleaved (alternating 20 s blocks). Contiguous halves were primary, because interleaved halves share the low-frequency autocorrelation of the band-passed signal and therefore overestimate reliability; interleaved halves are reported throughout as a sensitivity analysis, being in turn immune to within-run non-stationarity.

### Subtyping pipeline

Edges were centred within collection on that collection's baseline-wave mean, which is a per-collection constant and therefore cannot create or remove within-subject change between waves, then residualised on mean FD with coefficients fitted in the discovery sample only, then scaled to unit variance. Dimensionality was reduced by principal component analysis to 50 components fitted in the discovery sample (26.2% of edge variance). The discovery sample comprised the cross-sectional autistic sessions only; the longitudinal participants were never used for fitting, so their labels are out of sample.

Subtypes were obtained by k-means with 50 restarts. The number of clusters was chosen by consensus clustering[@monti2003] over 300 subsamples of 80% of participants, evaluating the silhouette coefficient, the adjusted Rand and adjusted mutual information indices between resampled solutions, and the proportion of ambiguous clustering[@senbabaoglu2014]. For the two-cluster solution, assignment by nearest centroid depends on the data only through the projection onto the centroid-difference axis, which defines the *subtype score*

[EQ] s = w^T ( x − m ),     w = (μ_2 − μ_1) / ||μ_2 − μ_1||,     m = (μ_1 + μ_2) / 2     (2)

standardised to unit variance in the discovery sample, so that the label is L = 1[s > 0]. Subtypes were ordered so that subtype 2 is the one with higher mean connectivity.

### The stability ceiling

Write the standardised subtype score of participant *i* on occasion *t* as a latent value plus independent measurement error,

[EQ] s_i(t) = θ_i(t) + ε_i(t),     Var(s) = 1,     (3)

so that the test–retest correlation of the score equals its reliability,

[EQ] ρ = Var(θ) / [ Var(θ) + Var(ε) ] = Var(θ).     (4)

Decompose the latent value into a categorical part, which of two classes the individual belongs to, and a continuous part, where the individual sits within its class:

[EQ] θ_i = c_i · sqrt(ω ρ) + b_i,     c_i = ±1,     b_i ~ N(0, (1 − ω) ρ),     (5)

where ω ∈ [0, 1] is the share of reliable latent variance lying *between* classes. ω = 1 describes a true dichotomy; ω = 0 describes a continuum that the clustering algorithm cuts in two. Conditional on class, the two occasions are bivariate normal, and for a balanced split the expected observed agreement is

[EQ] P_o(ρ, ω) = 1 − 2 Φ(−m) + 2 Φ_2(−m, −m; r),     m = sqrt( ωρ / (1 − ωρ) ),     r = (1 − ω)ρ / (1 − ωρ),     (6)

with Φ the standard normal distribution function and Φ_2 the standard bivariate normal distribution function. Chance agreement is 1/2 by symmetry, so Cohen's κ[@cohen1960] has the ceiling

[EQ] κ_max(ρ, ω) = 2 P_o(ρ, ω) − 1.     (7)

Equation (7) has two exact limits that bracket every intermediate case:

[EQ] κ_max(ρ, 0) = (2/π) · arcsin(ρ)     (8)

[EQ] κ_max(ρ, 1) = [ 2 Φ( sqrt( ρ / (1 − ρ) ) ) − 1 ]^{2}.     (9)

Unequal subtype prevalence was handled by placing the decision threshold at the corresponding normal quantile and integrating equation (6) over the two-component prior, which we evaluated numerically. Observed agreement is compared with the ceiling through the Subtype Stability Index

[EQ] SSI = κ_{obs} / κ_max(ρ, ω).     (10)

Because ω is not identified by the score distribution alone, we estimated it by the method of moments from agreement measured at effectively zero interval — the value of ω for which equation (7) reproduces the observed within-session agreement at the measured reliability — and we report the ω = 0 and ω = 1 bounds alongside every ceiling.

### Developmental decorrelation

True reconfiguration was modelled as exponential decorrelation of the latent score with characteristic time τ, so that the correlation observed after an interval Δt is ρ(Δt) = ρ_0 exp(−Δt/τ) and

[EQ] κ(Δt) = κ_max( ρ_0 · exp(−Δt/τ), ω ),     (11)

with the half-life of subtype identity

[EQ] t_½ = τ · ln 2,     τ = Δt / ln( ρ_0 / r_{obs} ).     (12)

Equation (12) is the classical correction for attenuation by unreliability[@spearman1904] rearranged for an unknown decorrelation time. Because τ depends entirely on the assumed zero-interval reliability ρ_0, every quantity derived from it is reported across the full range of defensible estimates of ρ_0 rather than at a single value.

### Design calculator

Reliability scales with measurement length by the Spearman–Brown relation[@spearman1910,brown1910],

[EQ] ρ(kT) = k ρ(T) / [ 1 + (k − 1) ρ(T) ],     (13)

which inverts to give the retained duration at which the ceiling reaches a target agreement κ*,

[EQ] T* = T_ref · ρ* (1 − ρ_ref) / [ ρ_ref (1 − ρ*) ],     ρ* = κ_max^{−1}(κ*, ω).     (14)

Statistical power to reject the trait null in favour of decorrelation with characteristic time τ was obtained by simulating equations (3)–(5) at the realised interval and sample size, using the Fisher-transformed score correlation as the test statistic (4,000 simulations per point).

### Reliability-regularised subtyping

Half-length estimates carry twice the error variance of full-length estimates, so the full-length measurement-error covariance in component space follows from the split halves as

[EQ] Σ_e = Cov( Z_A − Z_B ) / 4,     Σ_θ = Cov( Z ) − Σ_e,     (15)

both shrunk towards their scaled identity by 5%. Clustering was then repeated in the error-whitened space Z Σ_e^{−1/2}, which equalises noise across directions; the corresponding discriminant is the leading solution of the generalised eigenproblem

[EQ] Σ_θ v = λ Σ_e v.     (16)

Because this construction optimises the same quantity that reliability measures, it was evaluated strictly out of fold: the whitening and the clustering were fitted on one half of the discovery sample and the reliability evaluated on the other, and vice versa.

### Attempted estimation of the between-session state term

Within-session halves share arousal, head position and physiological state, so
the zero-interval reliability they give is an upper bound on true between-session
reliability, and the developmental component inferred from it is correspondingly
an upper bound. We therefore attempted to estimate the reversible between-session
term from the Consortium for Reliability and Reproducibility[@zuo2014], the only
open resource with repeat resting-state scans at intervals spanning minutes to
years. Connectomes were obtained for the 363 individuals of 13 sites who had two
sessions in the released CC200 derivative set; the 361 individuals of the 12 sites
contributing at least eight participants entered the fit, with published mean
retest intervals from 30 min to 516 days, and the attenuation of a multivariate
connectivity score was fitted as r(dt) = rho_trait + rho_state exp(-dt/tau_state).

The analysis was gated in advance on a bridge test, because the released
connectomes are magnitude-valued rather than signed: the same magnitude transform
was applied to our own data and the reliability and between-wave attenuation
recomputed. The bridge failed and the attempt was abandoned; the outcome is
reported in the Results because the attempt is the obvious one to make.

### Statistics

Agreement was quantified by Cohen's κ with percentile bootstrap confidence intervals (10,000–20,000 resamples). Correlations are Pearson unless stated, with Fisher intervals; because between-collection differences in noise amplitude are shared by both halves of a session and therefore inflate a correlation computed across pooled collections, all reliability estimates are Fisher-z pooled within collection. Score reliabilities at half length were converted to full length by equation (13). Consistency was also summarised by the two-way mixed single-measure intraclass correlation[@shrout1979,mcgraw1996]. Individual-level change was assessed by the reliable change index[@jacobson1991], z = (s_2 − s_1) / [σ_e √2] with σ_e = √(1 − ρ):

[EQ] z_i = ( s_i(2) − s_i(1) ) / sqrt( 2 (1 − ρ) ).     (17)

Whether the score distribution was two-humped was tested out of sample with Hartigan's dip test[@hartigan1985], Gaussian-mixture BIC and Sarle's bimodality coefficient[@pfister2013], with the discriminant fitted on one half of the discovery sample and the distribution modelled on the other.

Connectome identifiability was quantified after removing the grand mean connectome of the longitudinal collection, by the correlation of an individual's two connectomes (self-similarity), the corresponding between-individual correlations, the differential identifiability[@amico2018], and identification accuracy, the proportion of participants whose wave-1 connectome is most similar to their own wave-2 connectome[@finn2015], tested by permutation (2,000 permutations).

### Software and reproducibility

Analyses used Python 3.13 with NumPy 2.5.3[@harris2020], SciPy 1.18.1[@virtanen2020], scikit-learn 1.9.1[@pedregosa2011], pandas 3.0.5, nibabel 5.4.2, statsmodels 0.15.0, diptest 0.12.0 and Matplotlib 3.11.2. Every random procedure used a fixed seed (20261024). All code, including the download scripts, is available as described in the Data Availability Statement; the closed-form results of equations (6)–(9) are accompanied by a Monte-Carlo self-test that runs in under a minute without any data. Every reference cited here was resolved programmatically against Crossref and PubMed, and the retrieved metadata are archived with the code.

## Results

### Equation (7) reproduces simulated agreement exactly, and the two limits bracket it

Direct simulation of the measurement model, including an end-to-end variant in which k-means was re-run independently at each occasion, matched the closed form to within 0.005 κ units across reliabilities from 0.1 to 0.9 and across the full range of ω (Figure 1b). The ceiling is steep and unforgiving. For subtypes that cut a continuum, equation (8), reliability of 0.31 is needed for κ to reach the conventional threshold for fair agreement, 0.59 for moderate agreement and 0.81 for substantial agreement[@landis1977]; for a true dichotomy the same targets require 0.26, 0.45 and 0.60 (Figure 1a). Because a single connectivity edge in these data has a reliability of 0.34, no subtyping scheme that leans on individual edges can produce better than fair label agreement even if its subtypes are immutable traits.

[PLACE] [Figure 1 near here]

[TAB] **Table 1. Characteristics of the analysed sample.** Values are mean ± SD (range) unless stated. The discovery sample comprises cross-sectional autistic sessions only; the longitudinal participants were held out of all model fitting. Retained data are seconds surviving scrubbing at FD < 0.3 mm before duration matching.

| Characteristic | Autistic, cross-sectional (discovery) | Non-autistic, cross-sectional | Longitudinal, wave 1 | Longitudinal, wave 2 |
|---|---|---|---|---|
| Sessions, n | 378 | 478 | 12 | 12 |
| Collections, n | 16 | 14 | 1 | 1 |
| Autistic, n (%) | 378 (100) | 0 (0) | 6 (50) | 6 (50) |
| Age, years | 15.5 ± 9.2 (5.1–57.0) | 15.6 ± 9.3 (5.9–64.0) | 14.3 (11.4–17.8) | 16.1 (13.4–19.5) |
| Male, % | 86 | 68 | 75 | 75 |
| Full-scale IQ | 106 ± 17 (n = 351) | 115 ± 12 (n = 432) | 105 ± 13 | — |
| Mean framewise displacement, mm | 0.111 ± 0.029 | 0.107 ± 0.030 | 0.148 ± 0.021 | 0.132 ± 0.030 |
| Retained data, s | 369 ± 168 | 412 ± 195 | 254 ± 24 | 257 ± 36 |
| Inter-scan interval, years | — | — | 1.76 (1.58–2.04) | |


### The two-subtype solution is the stable one and reproduces the published hypo–hyper contrast weakly

Among the 884 sessions passing quality control from 17 collections, the discovery sample comprised 378 cross-sectional autistic sessions (Table 1). Cluster-number selection favoured k = 2 unambiguously: resampling adjusted Rand index 0.726 and proportion of ambiguous clustering 0.292, against 0.375 and 0.729 at k = 3 and monotonically worse thereafter (Figure 2a). The solution split the sample 156/222. Subtype 2 had the higher mean connectivity, in the direction reported for the hyperconnected subtype[@rasero2023], but the difference was small (Δ = 0.0015 in Fisher-z units, Cohen's *d* = 0.24, *t* = 2.26, *P* = 0.025) and the subtype score correlated only *r* = 0.147 with mean connectivity, indicating that the partition is not simply a global connectivity contrast. The discriminant loaded most strongly on within-default-mode edges and on default-mode couplings with the cingulo-opercular network, the hippocampus and the dorsal attention network (Figure 2d). As in the 657-individual consensus-clustering study[@rasero2023], the subtypes were not distinguishable behaviourally: the score was unrelated to ADOS-2 severity (*r* = 0.019, *P* = 0.80, *n* = 186), SRS total (*r* = 0.006, *P* = 0.92, *n* = 310), full-scale IQ (*r* = −0.048, *P* = 0.37) or age (*r* = −0.078, *P* = 0.13).

### Edge reliability matches the published meta-analytic value, and the multivariate score more than doubles it

Median within-session edge reliability, corrected to full length, was 0.337 (interquartile range of the raw half–half correlations 0.156–0.257; median intraclass correlation 0.335). This is close to the meta-analytic edge-level estimate of 0.29, 95% CI 0.23–0.36[@noble2019], obtained from independent data and different pipelines, and provides an external check that the derivatives analysed here are neither unusually clean nor unusually noisy (Figure 2c). The subtype score, being a weighted composite of 61,776 edges[@cronbach1951], was 2.09 times more reliable than a median edge, ρ = 0.705 by contiguous halves and 0.837 by interleaved halves — an instance of the general observation that multivariate functional-connectivity measures are more reliable than univariate ones[@noble2017]. Reliability rose with matched duration as Spearman–Brown predicts (Figure 2e), from 0.614 at 90 s to 0.765 at 180 s.

[PLACE] [Figure 2 near here]

### Observed within-session agreement falls inside the predicted bracket in four independent tests

The decisive internal test asks whether the ceiling predicts agreement that is actually observed when the same scan is split in two, a comparison in which no true change can have occurred. With contiguous halves, observed κ was 0.419, 95% CI 0.323–0.508, against a predicted bracket of 0.366 (continuum) to 0.526 (dichotomy). With interleaved halves, observed κ was 0.530, 95% CI 0.441–0.615, against 0.511 to 0.794. In the independent ABIDE I sample — a different cohort, a different preprocessing pipeline and a different parcellation, with 468 autistic participants across 19 sites — observed κ was 0.399, 95% CI 0.305–0.490, against a predicted continuum value of 0.395, and 0.494, 95% CI 0.412–0.572, with global signal regression, against 0.405 (Table 2, Figure 3a). In all four tests the observed value lay inside the bracket, and in the two tests whose reliability estimate is least biased it lay within 0.02 of the continuum prediction. Agreement in these data is therefore quantitatively explained by measurement error alone.

Consistent with the continuum reading, the subtype score showed no out-of-sample evidence of being two-humped: Hartigan's dip test gave *P* = 0.99, the Gaussian-mixture BIC difference was −0.4, and Sarle's bimodality coefficient was 0.416, below the 0.555 reference value (Figure 2b). The method-of-moments estimates of ω were correspondingly unstable across split schemes (0.69 contiguous, 0.42 interleaved), as expected when the parameter is weakly identified; we therefore carry both bounds through every subsequent analysis rather than committing to a point estimate.

[PLACE] [Figure 3 near here]

[TAB] **Table 2. Observed within-session label agreement against the predicted stability ceiling.** No true change can have occurred between the two halves of a single scan, so observed agreement should equal the ceiling evaluated at the measured reliability. The bracket runs from the continuum limit, equation (8), to the dichotomy limit, equation (9); ω (fitted) is the method-of-moments categoricity that reproduces the observed value. In all four tests the observed value falls inside the predicted bracket. κ confidence intervals are percentile bootstrap (10,000 resamples). GSR, global signal regression.

| Dataset and pipeline | Parcellation | Split | n | Reliability at half length | Observed κ (95% CI) | Predicted, ω = 0 | Predicted, ω = 1 | ω (fitted) |
|---|---|---|---|---|---|---|---|---|
| ABIDE II, DCAN | Gordon, 352 | contiguous | 378 | 0.544 | 0.419 (0.323–0.508) | 0.366 | 0.526 | 0.69 |
| ABIDE II, DCAN | Gordon, 352 | interleaved | 378 | 0.720 | 0.530 (0.441–0.615) | 0.511 | 0.794 | 0.42 |
| ABIDE I, C-PAC | CC200, 200 | contiguous, no GSR | 468 | 0.582 | 0.399 (0.305–0.490) | 0.395 | 0.580 | 0.36 |
| ABIDE I, C-PAC | CC200, 200 | contiguous, with GSR | 468 | 0.594 | 0.494 (0.412–0.572) | 0.405 | 0.598 | 0.78 |


### Across 1.6–2.0 years of development, subtype labels agree little more than chance

Twelve participants, six autistic and six non-autistic, had usable duration-matched connectomes at both waves (baseline age 11.4–17.8 years, mean 14.3; interval 1.58–2.04 years, mean 1.76). Five of the twelve changed subtype, giving raw agreement of 58.3% and κ = 0.167, 95% CI −0.33 to 0.67. The continuous score, a far more efficient statistic than the label, correlated *r* = 0.400 between waves, 95% CI −0.23 to 0.79 (intraclass correlation 0.386). Measured in these same participants and the same sessions, the zero-interval reliability of the score was 0.590, giving a ceiling of 0.402 under the continuum model and 0.593 under the dichotomy model, so the Subtype Stability Index was 0.41 (Table 3, Figure 4a,b).

The shortfall is in the direction of genuine reconfiguration, but at this sample size it is not distinguishable from sampling noise. Under a parametric bootstrap of the trait null — latent subtype identity perfectly stable, only measurement error between waves — twelve participants yield κ anywhere in the interval −0.11 to 0.84, and the observed value is not extreme within it (*P* = 0.19 for κ, *P* = 0.17 for the score correlation; Figure 4f). Taking the point estimate at face value implies a decorrelation time of 4.5 years and a half-life of subtype identity of 3.1 years, but that figure is entirely a function of the assumed zero-interval reliability: across the four defensible estimates of ρ_0 the implied half-life ranges from 1.7 to 15.9 years and the trait-null *P* value from 0.002 to 0.42 (Figure 4e, Table 3). At the individual level, no participant changed by more than measurement error would allow — none of the twelve reached a reliable change index of 1.96 (mean |z| = 0.73) — and there was no group-level drift (mean change 0.19 SD, *t*(11) = 0.76, *P* = 0.46). Autistic and non-autistic participants did not differ in the magnitude of change (*U* = 15, *P* = 0.70), though with six per group this comparison is uninformative.

The instability of the estimate itself is the most robust finding. Holding the data fixed and varying only analytic choices, κ between waves ranged from 0.000 to 0.167 across the four parcellations, from 0.167 to 0.500 across four clustering algorithms, and from −0.268 to 0.375 across matched durations, which also change the number of eligible participants from 6 to 16 (Table 3). Any one of these values could be reported as "the" stability of autism connectivity subtypes.

### The same scans identify individuals across development with high accuracy

If subtype labels are unstable because the underlying connectome has reorganised, then individual connectomes should also have become unrecognisable. They had not. Within a session, each participant's two half-length connectomes correlated *r* = 0.186 ± 0.052 after removal of the group mean, and across the 1.76-year interval the same quantity was 0.068 ± 0.056, against −0.043 ± 0.036 for pairs of different individuals (self versus other, *t*(11) = 6.82, *P* = 2.9 × 10⁻⁵). Matching each wave-1 connectome to the most similar wave-2 connectome identified the correct individual in 75% of cases, and 91.7% in the reverse direction, against 8.3% chance (permutation *P* < 5 × 10⁻⁴; median rank of self = 1; within-session identification was 100%). Differential identifiability was 11.1% across waves against 21.3% within session (Figure 4c,d).

The contrast is the central empirical result of this study. In the same participants, the same scans and the same analysis, individual identity survived 1.8 years of adolescent development at 75–92% accuracy while the categorical subtype label retained κ = 0.17. The information that is stable is present in the connectome and is discarded by the labelling step, which compresses 61,776 reliable-in-aggregate measurements into one bit (Figure 5c).

[PLACE] [Figure 4 near here]

[TAB] **Table 3. Intraindividual stability across 1.6–2.0 years, and its dependence on analytic choices.** Panel A gives the primary analysis and its dependence on the assumed zero-interval reliability ρ₀, which is the only quantity that must be estimated rather than measured between waves; P values are parametric-bootstrap tests of the trait null (perfectly stable latent subtype identity) at the realised sample size. Panel B varies one analytic choice at a time on the same data. SSI, Subtype Stability Index, equation (10).

| A. Primary analysis (n = 12, mean interval 1.76 years) | Value |
|---|---|
| Raw agreement between waves | 58.3% (5 of 12 changed subtype) |
| Cohen's κ between waves (95% CI) | 0.167 (−0.33 to 0.67) |
| Score correlation between waves (95% CI) | 0.400 (−0.23 to 0.79) |
| Intraclass correlation of the score | 0.386 |
| Participants exceeding a reliable change index of 1.96 | 0 of 12 (mean absolute index 0.73) |
| Group-level drift in score | 0.19 SD, t(11) = 0.76, P = 0.46 |
| Autistic versus non-autistic absolute change | U = 15, P = 0.70 |

| ρ₀ source | ρ₀ | Ceiling, ω = 0 | SSI | Half-life, years | P (κ) | P (score r) |
|---|---|---|---|---|---|---|
| Same participants, within collection, contiguous halves (primary) | 0.590 | 0.402 | 0.41 | 3.1 | 0.19 | 0.17 |
| Same participants, pooled, contiguous halves | 0.432 | 0.285 | 0.59 | 15.9 | 0.36 | 0.42 |
| Discovery sample, within collection, contiguous halves | 0.743 | 0.533 | 0.31 | 2.0 | 0.06 | 0.02 |
| Discovery sample, interleaved halves | 0.837 | 0.631 | 0.26 | 1.7 | 0.02 | 0.002 |

| B. One analytic choice varied | n pairs | Score ρ | κ between waves | Score r between waves |
|---|---|---|---|---|
| Matched duration 90 s | 16 | 0.614 | 0.375 | 0.487 |
| Matched duration 120 s | 13 | 0.703 | −0.268 | −0.125 |
| Matched duration 150 s (primary) | 12 | 0.743 | 0.167 | 0.400 |
| Matched duration 180 s | 11 | 0.765 | 0.241 | 0.484 |
| Matched duration 240 s | 6 | 0.754 | 0.250 | 0.095 |
| Parcellation: Gordon, 352 (primary) | 12 | 0.743 | 0.167 | 0.400 |
| Parcellation: Glasser, 379 | 12 | 0.719 | 0.000 | −0.011 |
| Parcellation: Power, 94 | 12 | 0.664 | 0.000 | 0.205 |
| Parcellation: M132, 205 | 12 | 0.634 | 0.000 | 0.032 |
| Algorithm: k-means (primary) | 12 | 0.743 | 0.167 | 0.400 |
| Algorithm: Ward | 12 | 0.747 | 0.333 | 0.452 |
| Algorithm: Gaussian mixture | 12 | 0.787 | 0.500 | 0.402 |
| Algorithm: spectral | 12 | 0.744 | 0.333 | 0.460 |
| Components: 20 / 50 / 100 | 12 | 0.744 / 0.743 / 0.744 | 0.167 / 0.167 / 0.167 | 0.401 / 0.400 / 0.409 |
| Nuisance: none / motion / motion + age / motion + age + sex | 12 | 0.746 / 0.743 / 0.745 / 0.745 | 0.000 / 0.167 / 0.167 / 0.167 | 0.262 / 0.400 / 0.426 / 0.430 |
| Clusters: k = 3 / k = 4 | 12 | — | 0.392 / 0.182 | — |


### Clustering in the error-whitened subspace raises the ceiling but changes what is measured

Because the ceiling is a monotone function of reliability, subtyping can be made more repeatable by clustering in the subspace in which measurement error is small. Clustering in the error-whitened space, evaluated strictly out of fold, raised score reliability from 0.705 to 0.936 and within-session agreement from 0.419 to 0.655. The resulting axis was, however, almost orthogonal to the conventional one (cosine −0.04), so it defines a different partition rather than a more reliable version of the published one; and in the held-out longitudinal collection its advantage did not transfer (between-wave *r* = −0.39). Reliability-regularised stratification is therefore promising as a design principle and premature as a replacement, and requires testing in a sample large enough to evaluate transfer.

### The between-session state term cannot be recovered from open repeat-scan data

Taking the absolute value of connectivity in our own data, which reproduces the
feature convention of the released repeat-scan connectomes, cut median edge
reliability from 0.326 to 0.104 and raised the apparent between-wave correlation
in the twelve autism pairs from 0.400 to 0.706 — the magnitude score is dominated
by a stable individual offset in overall connectivity strength rather than by the
subtype contrast, so the two feature spaces do not measure the same thing and the
pre-specified bridge test failed. Independently, the attenuation of the
multivariate score across the 12 repeat-scan sites was not an orderly function of
interval: agreement at 75 days (r = -0.08) was lower than at 516 days (r = 0.50),
and the fitted decay explained only 27% of the variance across sites, implying a
characteristic time of 5.7 days that is an artefact of between-site heterogeneity
in scanner, protocol, sample and scan duration rather than a decorrelation rate.
The decomposition it produced was out of range, attributing 175% of the observed
attenuation to state and a negative share to development.

We therefore report the between-session state term as unestimated rather than
estimated badly. The consequence for the present results is one-directional and
is stated plainly: because some part of the 1.76-year attenuation is reversible
state rather than development, the decorrelation times in Table 3 are lower
bounds and the developmental component an upper bound, which makes our already
non-significant evidence for genuine reconfiguration weaker still, not stronger.
Recovering this term requires preprocessed time series from a repeat-scan cohort,
not the magnitude-valued connectomes currently released.

### Answering the question requires about ten minutes of retained data and several hundred participants

Combining the ceiling with the duration law gives explicit requirements. Under the continuum model, label agreement of 0.4 requires score reliability of 0.59 and 2.5 minutes of retained data per session; agreement of 0.6 requires reliability of 0.81 and 7.4 minutes; agreement of 0.8 requires reliability of 0.95 and 33.7 minutes (Figure 5a, Table 4). These are lower bounds, because Spearman–Brown extrapolation ignores the empirical observation that between-session reliability gains begin to diminish after roughly 9–12 minutes[@birn2013]. Separately, detecting genuine reconfiguration requires sample sizes far beyond what exists: at the observed reliability and interval, 80% power to reject the trait null needs about 60 participants if subtype identity decorrelates with a 2-year characteristic time, about 150 if 5 years, and about 400 if 10 years (Figure 5b). The entire longitudinal evidence base in autism that is reusable without a data-use agreement comprises 38 individuals, of whom 12–16 survive duration matching and quality control — a design with roughly 10–30% power against the alternatives of interest.

[PLACE] [Figure 5 near here]

[TAB] **Table 4. What it would take to answer the question.** Duration requirements invert equation (14) from the measured reliability of the subtype score (ρ = 0.590 at 150 s of retained data) and are lower bounds, because Spearman–Brown extrapolation ignores the empirically observed plateau of between-session reliability beyond roughly 9–12 minutes. Sample sizes give 80% power to reject the trait null at the observed 1.76-year interval, by simulation.

| Target agreement κ | Required score reliability ρ | Retained data per session, min (ω = 0) | Retained data per session, min (ω = 1) |
|---|---|---|---|
| 0.2 | 0.31 | 0.8 | 0.6 |
| 0.4 | 0.59 | 2.5 | 1.5 |
| 0.6 | 0.81 | 7.4 | 3.0 |
| 0.8 | 0.95 | 33.7 | 5.0 |

| True decorrelation half-life | Participants scanned twice for 80% power | Power at n = 12 |
|---|---|---|
| 1.4 years (τ = 2 y) | ≈ 60 | 0.31 |
| 3.5 years (τ = 5 y) | ≈ 150 | 0.15 |
| 6.9 years (τ = 10 y) | ≈ 400 | 0.09 |
| 13.9 years (τ = 20 y) | > 800 | 0.07 |


## Discussion

The developmental instability of autism connectivity subtypes has been treated as an open empirical question about the brain. Our results suggest it is, at present, mostly a question about measurement. A two-cluster assignment is a threshold on a noisy scalar, and the agreement such an assignment can achieve between occasions is bounded in closed form by the reliability of that scalar. The bound predicted observed within-session agreement in two independent samples, two pipelines, two parcellation families and two split schemes, in every case inside the confidence interval and twice within 0.02 of the continuum prediction. Whatever else is true of these subtypes, the amount of label switching seen when nothing has changed is already what the measurement model says it should be.

That reframes the interpretation of switching across development. We observed κ = 0.17 at 1.76 years against an attainable ceiling of 0.40, a shortfall consistent with some true reconfiguration; but with twelve participants the trait null cannot be rejected, and the implied half-life of subtype identity ranges over an order of magnitude depending on which defensible estimate of zero-interval reliability is used. The honest summary is that the open data are compatible with subtypes that are perfectly stable traits and with subtypes that lose half their signal every two years, and cannot distinguish them. Reporting either conclusion from this evidence base would be unwarranted, and the variability we found across parcellations, algorithms and durations — κ from −0.27 to 0.50 on identical data — shows how easily either could be produced.

Against that background, the identifiability result is informative precisely because it does not depend on labels. Individual connectomes remained recognisable across 1.8 years of adolescence at 75–92% accuracy, consistent with evidence that functional network organisation is dominated by stable individual features[@gratton2018,laumann2015]. Stable individual information is therefore present in these very scans; it is the categorical summary that fails to carry it. The implication is not that stratification is hopeless but that the categorical step is the lossy one. A continuous, explicitly reliability-quantified score is both more informative and more reportable than a label, and our reliability-regularised analysis shows that where in the feature space one clusters can matter more for repeatability than which algorithm one uses — though the partition it produced was a different one, and its advantage did not transfer out of sample, so we present it as a design principle rather than a result.

Our findings sit alongside, and help explain, several existing observations. Subtyping solutions derived from different modalities in the same participants agree poorly even when each is internally stable[@wen2025]; connectivity features predictive of autism generalise weakly across sites[@king2019]; and data-driven psychiatric subtypes have repeatedly failed to replicate[@dinga2019]. Equation (7) suggests a common contributor: categorical summaries of unreliable continuous measurements have low expected agreement under any form of resampling, whether that resampling is across scans, across modalities or across samples. The same logic connects this work to the finding that brain-wide association studies require thousands of individuals[@marek2022] — small effects and low reliability impose quantitative limits that no analytic sophistication removes. It is also consistent with the broader taxometric literature, in which the large majority of latent psychopathological variables prove dimensional rather than taxonic when tested by taxometric methods[@meehl1995], with autism among the few domains where categorical evidence has been considered promising[@haslam2012].

Several limitations qualify these conclusions. The longitudinal sample is very small, and we have emphasised rather than minimised what follows from that; it is also restricted to a single collection, to adolescence, and to participants able to tolerate two scanning sessions, so these estimates should not be extrapolated to early childhood, where the developmental reorganisation of interest is most pronounced[@nomi2015,padmanabhan2017]. The zero-interval reliability we use is estimated from within-session halves, which share arousal, head position and physiological state, and therefore overestimates true between-session reliability; the consequence is that our ceiling is, if anything, too generous and our inferred decorrelation too fast. We attempted to measure that between-session term in the only open repeat-scan resource and could not, for the reasons given in the Results, so it remains the largest unquantified quantity in this work. The ω parameter is weakly identified, which is why we report bounds throughout. Our duration calculator assumes Spearman–Brown scaling, which empirical work shows to be optimistic beyond about a quarter of an hour[@birn2013]. Finally, we analysed the two-cluster solution because it is the most replicated and because it alone admits exact treatment; agreement for k > 2 was evaluated by simulation and behaved similarly, but the closed form does not extend to it.

Three predictions follow and are testable with existing or planned resources. First, in any cohort with repeat resting-state scans, within-session label agreement will equal equation (8) evaluated at the measured score reliability, to within sampling error — a prediction that can be checked in a single afternoon in any dataset with enough frames to split. Second, label agreement between waves will increase with retained scan duration along the trajectory of equation (14), not along any trajectory reflecting biological consolidation, up to the point where real reconfiguration begins to dominate. Third, in a cohort of several hundred individuals scanned twice, such as the longitudinal imaging waves of large developmental cohorts[@casey2018] or purpose-built stratification cohorts[@loth2017] — a protocol for which, targeting prospective infant-sibling collections, is deposited with this work — the continuous subtype score will show attenuation beyond that predicted by reliability alone if and only if subtypes genuinely reconfigure; the half-life, if it is finite, is estimable with useful precision at that sample size and not before.

## Conclusions

Categorical stratification of autism by functional connectivity inherits a hard limit from the reliability of the measurement it summarises, and that limit can be written down exactly. At the reliability achievable with the few minutes of resting-state data typical of multisite cohorts, subtypes that are perfectly stable traits would still appear to switch in a large minority of individuals rescanned years later. Observed within-session agreement matches this prediction closely in two independent samples processed with unrelated pipelines. In the only repeat connectomes in autism that are openly reusable, subtype labels agreed poorly across 1.6–2.0 years while the same scans identified individuals with 75–92% accuracy, showing that the developmentally stable information is present in the data and is lost in the labelling. Whether autism connectivity subtypes are traits remains genuinely open; we show that the open evidence base has roughly 10–30% power to settle it, and we specify what would: about ten minutes of retained data per session and several hundred individuals scanned twice. Until then, the field should report reliability-quantified continuous scores rather than categorical subtypes.

## CRediT authorship contribution statement

**[AUTHOR 1]:** Conceptualization, Methodology, Formal analysis, Software, Data curation, Validation, Visualization, Writing – original draft, Writing – review & editing, Supervision. **[AUTHOR 2]:** Methodology, Formal analysis, Validation, Writing – review & editing. **[AUTHOR 3]:** Conceptualization, Investigation, Writing – review & editing. All authors read and approved the final manuscript.

## Ethics Statement

This study analysed only de-identified, publicly available data. The ABIDE I and ABIDE II datasets were collected at the contributing sites with the approval of their respective local institutional review boards and with informed consent or assent from participants and, where applicable, their parents or guardians; both are distributed openly in accordance with HIPAA-compliant de-identification standards. No new data were acquired for this work, and no identifiable information was accessed, so additional ethical approval was not required. We follow community guidance on respectful terminology and use identity-first language.

## Funding

[FUNDING — insert grant numbers and funders, or the statement: "This research did not receive any specific grant from funding agencies in the public, commercial, or not-for-profit sectors."]

## Declaration of Competing Interest

The authors declare that they have no known competing financial interests or personal relationships that could have appeared to influence the work reported in this paper.

## Data Availability Statement

This study used exclusively public data and generates no restricted data. All analysis code, including the scripts that download the primary derivatives, is openly available at [GITHUB URL — insert on submission] and archived with a permanent identifier at [ZENODO DOI — minted from the tagged release]. The repository contains the complete pipeline (`code/01`–`code/13`), the derived result tables and JSON records reported here, the figure-generation script, a pinned environment specification (`requirements.txt`, `environment.yml`), a `Makefile` reproducing the analysis end to end, an MIT licence and a citation file. The machine-verified bibliography, including the Crossref and PubMed metadata retrieved for every citation, is archived as `results/references_verified.json`. A preregistered protocol and ready-to-run implementation for testing the present framework in prospective infant-sibling cohorts held in controlled-access repositories is deposited in the same archive under `preregistration/`; the authors hold no data-use certification for those collections, and the protocol is deposited so that groups that do can execute it unchanged.

Primary data are obtained by the included scripts from their original archives: ABIDE II DCAN derivatives and ABIDE I Preprocessed Connectomes Project derivatives from the International Neuroimaging Data-sharing Initiative S3 bucket (`s3://fcp-indi`, anonymous access), and the ABIDE I and ABIDE II phenotypic tables from the ABIDE distribution pages. No primary imaging data are redistributed here; their use is governed by the terms of those releases.

## Declaration of Generative AI and AI-Assisted Technologies in the Writing Process

During the preparation of this work the authors used a generative artificial-intelligence assistant (Anthropic Claude) to assist with literature retrieval and verification, with the implementation of analysis code, and with language editing of the manuscript. All analyses were specified, inspected and executed by the authors; all outputs, figures and numerical results were reviewed by the authors against the archived code and data; and every citation was verified against Crossref and PubMed records, which are archived with the code. The authors take full responsibility for the content of the publication.


## Figure legends

[FIGCAP] **Figure 1. A categorical subtype assignment has an exact agreement ceiling set by measurement reliability.** **a**, Maximum attainable agreement between two occasions, equation (7), as a function of the reliability of the subtype score, for a latent continuum (ω = 0), an intermediate case and a true dichotomy (ω = 1). Shaded bands mark conventional benchmarks for κ. Dotted vertical lines give the reliability measured here for a single connectivity edge and for the multivariate subtype score. **b**, The closed form reproduces direct simulation of the measurement model to within 0.005 κ units across the full range of reliability and ω. **c**, The ceiling as a function of retained resting-state data per session, obtained by combining equation (7) with Spearman–Brown scaling of the measured reliability; the shaded region spans the two limits. The vertical line marks the 2.5 minutes of retained data analysed here.

[FIGCAP] **Figure 2. The two-subtype solution, and the reliability of what it is computed from.** **a**, Cluster-number selection in 378 cross-sectional autistic sessions: resampling adjusted Rand index (higher is better), proportion of ambiguous clustering (lower is better) and silhouette coefficient, each from 300 subsamples of 80% of participants. **b**, Distribution of the subtype score, with out-of-sample tests of whether it is two-humped. **c**, Distribution of edge-level reliability across 61,776 edges, with the median of this study and the published meta-analytic estimate for resting-state functional connectivity. **d**, Mean absolute discriminant weight by network pair, showing that the partition is driven mainly by default-mode, cingulo-opercular and dorsal-attention couplings rather than by global connectivity. **e**, Reliability of the subtype score at five matched durations, against the Spearman–Brown prediction anchored at 150 s.

[FIGCAP] **Figure 3. The ceiling predicts observed agreement in four independent tests.** **a**, Observed within-session label agreement (point and 95% bootstrap interval) against the predicted bracket (grey bar, from the continuum limit in blue to the dichotomy limit in orange) for two split schemes in ABIDE II and two denoising strategies in ABIDE I, the latter a different cohort, pipeline and parcellation. Every observed value falls inside its predicted bracket. **b**, Score reliability, attainable ceiling and observed agreement across 1.8 years for four parcellations of the same scans.

[FIGCAP] **Figure 4. Subtype labels do not persist across development, but individuals do.** **a**, Subtype score of each of the 12 participants at both waves; dashed lines with open symbols are the five participants who changed subtype. **b**, Observed agreement, score correlation and attainable ceiling at five matched durations, with the number of eligible participants at each. **c**, Connectome similarity after removal of the group mean: the same scan split in half, the same person 1.8 years apart, and different people (mean ± SD). **d**, Identification accuracy, matching each participant's connectome to its own counterpart among all participants, within session and across 1.8 years, against chance. **e**, The implied half-life of subtype identity as a function of the assumed zero-interval reliability; the point marks the value measured in these participants. **f**, Observed agreement against the distribution expected if latent subtype identity were perfectly stable, at the realised sample size (shaded, 95% interval).

[FIGCAP] **Figure 5. What would be needed, and what the labelling step costs.** **a**, Retained resting-state data per session required for the ceiling to reach each target agreement, under the continuum and dichotomy models. **b**, Power to reject the trait null as a function of the number of participants scanned twice, for four assumed decorrelation times, at the reliability and interval observed here. **c**, Individual information surviving 1.8 years in the same participants and the same scans, measured three ways: agreement of the categorical label, correlation of the continuous subtype score, and identification accuracy from the whole connectome.

## References

[REFERENCES]
